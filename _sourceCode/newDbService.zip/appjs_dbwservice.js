var   cServerID     = 0;
var   router        = require('./router.js');
//const cStartup      = new Date(); 
//const csStartup     =   ('0' + cStartup.getFullYear()).slice(-4)  + "-" +
//                        ('0' + (cStartup.getMonth() + 1)).slice(-2)  + "-" +
//                        ('0' + cStartup.getDate()).slice(-2)  + " " +
//                        ('0' + cStartup.getHours()).slice(-2) + ":"  +
//                        ('0' + cStartup.getMinutes()).slice(-2) + ":" +
//                        ('0' + cStartup.getSeconds()).slice(-2);
const vServerConf   = { "parmKafkaServer":"192.168.99.1:9092",
                        "servercode":"DB.WS.01" };
// const cMonitorKafka = false;
// const heartbeats    = require('heartbeats');

// const http          = require('http');
var cors = require('cors');

var   app             = require('express')();
//var   express         = require('express');
//var   path            = require('path');
var   http            = require('http').createServer(app);
app.use(cors());
const WebSocket = require("ws");
// const websocketServer = new WebSocket.Server({ http });
const websocketServer = new WebSocket.Server ({ port: 88, http });
// const websocketServer = new WebSocket.Server ({ noServer: true, http });

// const kafkaproduce  = require("./kafkaproduce");
const fs            = require('fs');
// const { Console } = require('console');
const log_time = function(note) {
    let date_ob     = new Date();
    let date        = ("0" + date_ob.getDate()).slice(-2);
    let month       = ("0" + (date_ob.getMonth() + 1)).slice(-2);
    let year        = date_ob.getFullYear();
    let hours       = ("00" + date_ob.getHours()).slice(-2);
    let minutes     = ("00" + date_ob.getMinutes()).slice(-2);
    let seconds     = ("00" + date_ob.getSeconds()).slice(-2);
    let v_message;

    v_message = year + "-" + month + "-" + date + " " + hours + ":" + minutes + ":" + seconds + " " + note;
    console.log(v_message); 
    let v_filename = '001' + year + month + date + ".log";
    const logfile = fs.createWriteStream(v_filename, { flags: 'a' });
    logfile.write(v_message + "\r\n");
    logfile.close();
}
var   gvConnectionString    = {};
app.use('/', router);

async function loadConfig(aCounter, aModule, result) {
    let lReturn = false;
    var lMessageErr = '';
    var vUsername;
    var vPassword;
    var vHostport;
    var vDbName;
    var lConnectionStringKlinik;

    fs.readFile("./appjs_dbwservice_config.json", "utf8", (err, jsonString) => {
        if (err) {
            log_time("Error reading 'config.json' file from disk");
            log_time(err);
            result(false);
        } else {
            try {
                const fileSetting = JSON.parse(jsonString);
                lMessageErr = "port setting Error !";
                if (fileSetting.port) {
                    lMessageErr = "serverID setting Error !";
                    vServerConf.serverport = fileSetting.port;
                    lReturn = true;
                }
                if ((lReturn) && (fileSetting.serverID != undefined)) {
                    lMessageErr = "envMode " + aModule + " setting Error !";
                    cServerID = parseInt(fileSetting.serverID,10);
                } else { lReturn = false; }

                if ((lReturn) && (fileSetting.envMode) && (fileSetting[aModule])) {
                    const environmentMode = fileSetting[aModule]; 
                    if (environmentMode[fileSetting.envMode]) {
                        lMessageErr = aModule + ".username setting Error !";
                        if (environmentMode[fileSetting.envMode].username) {
                            lMessageErr = aModule + ".password setting Error !";
                            vUsername = environmentMode[fileSetting.envMode].username;
                        } else { lReturn = false; }
                        if ((lReturn) && (environmentMode[fileSetting.envMode].password)) {
                            lMessageErr = aModule + ".hostport setting Error !";
                            vPassword = environmentMode[fileSetting.envMode].password;
                        } else { lReturn = false; }
                        if ((lReturn) && (environmentMode[fileSetting.envMode].hostport)) {
                            lMessageErr = aModule + ".dbName setting Error !";
                            vHostport = environmentMode[fileSetting.envMode].hostport;
                        } else { lReturn = false; }
                        if ((lReturn) && (environmentMode[fileSetting.envMode].dbName)) {
                            vDbName = environmentMode[fileSetting.envMode].dbName;
                        } else { lReturn = false; }
                    } else { lReturn = false; }
                } else { lReturn = false; }
                if (lReturn) {
                    lConnectionStringKlinik = "postgresql://" + vUsername;
                    lConnectionStringKlinik = lConnectionStringKlinik + ":" + vPassword;
                    lConnectionStringKlinik = lConnectionStringKlinik + "@" + vHostport;
                    lConnectionStringKlinik = lConnectionStringKlinik + "/" + vDbName;
                    result({ counter : aCounter, module : aModule, sresult : lConnectionStringKlinik});
                } else {
                    log_time(lMessageErr);
                    result(false);
                }
            } catch (err) {
                log_time("Error parsing JSON string:", err);
                result(false);
            }
        }
    });
}

const gvDatabaseAll = [{ ModuleDb : 'dbPayment', ModulePath : '/localws/payment'}
                    ,{ ModuleDb : 'dbKoperasi', ModulePath : '/localws/koperasi'}
                    ,{ ModuleDb : 'dbKlinik', ModulePath : '/localws/klinik'}
                    ,{ ModuleDb : 'dbAntrian', ModulePath : '/localws/antrian'}
                    ,{ ModuleDb : 'dbApotek', ModulePath : '/localws/apotek'}
                    ,{ ModuleDb : 'dbPemkabSAAPI', ModulePath : '/localws/saapi'}
                    ];
//const gvDatabase  = [{ ModuleDb : 'dbApotek', ModulePath : '/localws/apotek'}];
const gvDatabase  = [{ ModuleDb : 'dbKlinik', ModulePath : '/localws/klinik'}];

function getModuleDb(aPath) {  return gvDatabase.filter( function(gvDatabase){ return gvDatabase.ModulePath == aPath } ); }
async function loadConfigs() {
    var lvCounter = 0;
    var lvCounted = gvDatabase.length;

    for(var i = 0; i < gvDatabase.length; i++) {
        loadConfig(i + 1, gvDatabase[i].ModuleDb, function(data) {
            if (data) {
                gvConnectionString[data.module] = data.sresult;
                console.log('-- gvConnectionString --');
                console.log(JSON.stringify(gvConnectionString));
                log_time(data.module + ' config : ' + data.sresult);
                lvCounter = lvCounter + 1;
                if (lvCounter == lvCounted) {
                    http.listen(vServerConf.serverport, function(){
                        console.log('listening on *:' + vServerConf.serverport);
                    });
                }
            } else { 
                log_time("Error read json config file."); 
            }
        });
    }
}
loadConfigs();

websocketServer.on('connection', (socket) => {
    console.log('client connected.');

    socket.on('message', (data) => {
      websocketServer.clients.forEach(function each(client) {
        if (client !== socket && client.readyState === WebSocket.OPEN) {
          client.send(data.toString());
        }
      });
    });

    socket.on('close', () => {
      console.log('Client disconnected');
    });

  });
