var   cServerID     = 0;
const cStartup      = new Date(); 
const csStartup     =   ('0' + cStartup.getFullYear()).slice(-4)  + "-" +
                        ('0' + (cStartup.getMonth() + 1)).slice(-2)  + "-" +
                        ('0' + cStartup.getDate()).slice(-2)  + " " +
                        ('0' + cStartup.getHours()).slice(-2) + ":"  +
                        ('0' + cStartup.getMinutes()).slice(-2) + ":" +
                        ('0' + cStartup.getSeconds()).slice(-2);
const vServerConf   = { "parmKafkaServer":"192.168.99.1:9092",
                        "servercode":"DB.WS.01" };
const cMonitorKafka = false;
const heartbeats    = require('heartbeats');

// const http          = require('http');
var cors = require('cors');

var   app             = require('express')();
//var   express         = require('express');
//var   path            = require('path');
var   http            = require('http').Server(app);
app.use(cors());

const kafkaproduce  = require("./kafkaproduce");
const fs            = require('fs');
const url           = require('url');
const log_time = function(note) {
    let date_ob     = new Date();
    let date        = ("0" + date_ob.getDate()).slice(-2);
    let month       = ("0" + (date_ob.getMonth() + 1)).slice(-2);
    let year        = date_ob.getFullYear();
    let hours       = ("00" + date_ob.getHours()).slice(-2);
    let minutes     = ("00" + date_ob.getMinutes()).slice(-2);
    let seconds     = ("00" + date_ob.getSeconds()).slice(-2);
    let v_message;

    v_message = year + "-" + month + "-" + date + " " + hours + ":" + minutes + ":" + seconds + " " + note;
    console.log(v_message); 
    let v_filename = '001' + year + month + date + ".log";
    const logfile = fs.createWriteStream(v_filename, { flags: 'a' });
    logfile.write(v_message + "\r\n");
    logfile.close();
}
var   gvConnectionString    = {};

async function loadConfig(aCounter, aModule, result) {
    let lReturn = false;
    var lMessageErr = '';
    var vUsername;
    var vPassword;
    var vHostport;
    var vDbName;
    var lConnectionStringKlinik;

    fs.readFile("./appjs_dbwservice_config.json", "utf8", (err, jsonString) => {
        if (err) {
            log_time("Error reading 'config.json' file from disk");
            log_time(err);
            result(false);
        } else {
            try {
                const fileSetting = JSON.parse(jsonString);
                lMessageErr = "port setting Error !";
                if (fileSetting.port) {
                    lMessageErr = "serverID setting Error !";
                    vServerConf.serverport = fileSetting.port;
                    lReturn = true;
                }
                if ((lReturn) && (fileSetting.serverID != undefined)) {
                    lMessageErr = "envMode " + aModule + " setting Error !";
                    cServerID = parseInt(fileSetting.serverID,10);
                } else { lReturn = false; }

                if ((lReturn) && (fileSetting.envMode) && (fileSetting[aModule])) {
                    const environmentMode = fileSetting[aModule]; 
                    if (environmentMode[fileSetting.envMode]) {
                        lMessageErr = aModule + ".username setting Error !";
                        if (environmentMode[fileSetting.envMode].username) {
                            lMessageErr = aModule + ".password setting Error !";
                            vUsername = environmentMode[fileSetting.envMode].username;
                        } else { lReturn = false; }
                        if ((lReturn) && (environmentMode[fileSetting.envMode].password)) {
                            lMessageErr = aModule + ".hostport setting Error !";
                            vPassword = environmentMode[fileSetting.envMode].password;
                        } else { lReturn = false; }
                        if ((lReturn) && (environmentMode[fileSetting.envMode].hostport)) {
                            lMessageErr = aModule + ".dbName setting Error !";
                            vHostport = environmentMode[fileSetting.envMode].hostport;
                        } else { lReturn = false; }
                        if ((lReturn) && (environmentMode[fileSetting.envMode].dbName)) {
                            vDbName = environmentMode[fileSetting.envMode].dbName;
                        } else { lReturn = false; }
                    } else { lReturn = false; }
                } else { lReturn = false; }
                if (lReturn) {
                    lConnectionStringKlinik = "postgresql://" + vUsername;
                    lConnectionStringKlinik = lConnectionStringKlinik + ":" + vPassword;
                    lConnectionStringKlinik = lConnectionStringKlinik + "@" + vHostport;
                    lConnectionStringKlinik = lConnectionStringKlinik + "/" + vDbName;
                    result({ counter : aCounter, module : aModule, sresult : lConnectionStringKlinik});
                } else {
                    log_time(lMessageErr);
                    result(false);
                }
            } catch (err) {
                log_time("Error parsing JSON string:", err);
                result(false);
            }
        }
    });
}

const gvDatabaseAll = [{ ModuleDb : 'dbPayment', ModulePath : '/localws/payment'}
                    ,{ ModuleDb : 'dbKoperasi', ModulePath : '/localws/koperasi'}
                    ,{ ModuleDb : 'dbKlinik', ModulePath : '/localws/klinik'}
                    ,{ ModuleDb : 'dbAntrian', ModulePath : '/localws/antrian'}
                    ,{ ModuleDb : 'dbApotek', ModulePath : '/localws/apotek'}
                    ,{ ModuleDb : 'dbPemkabSAAPI', ModulePath : '/localws/saapi'}
                    ];
//const gvDatabase  = [{ ModuleDb : 'dbApotek', ModulePath : '/localws/apotek'}];
const gvDatabase  = [{ ModuleDb : 'dbKlinik', ModulePath : '/localws/klinik'}];

function getModuleDb(aPath) {  return gvDatabase.filter( function(gvDatabase){ return gvDatabase.ModulePath == aPath } ); }
async function loadConfigs() {
    var lvCounter = 0;
    var lvCounted = gvDatabase.length;

    for(var i = 0; i < gvDatabase.length; i++) {
        loadConfig(i + 1, gvDatabase[i].ModuleDb, function(data) {
            if (data) {
                gvConnectionString[data.module] = data.sresult;
                log_time(data.module + ' config : ' + data.sresult);
                lvCounter = lvCounter + 1;
                if (lvCounter == lvCounted) {
                    if (cServerID >= 1) { 
                        asyncServerDBConfig(); 
                    } else { 
                        asyncListening(); 
                    }
                }
            } else { 
                log_time("Error read json config file."); 
            }
        });
    }
}

loadConfigs();

async function asyncServerDBConfig() {
    const cparm0       = 'server.conf';
    const cparm1       = 'usertoken';
    const cparm2       = '{"method":"server.conf","serverid":"' + cServerID + '"}';

    /*
    // ubah koneksi database setting ...
    // koneksi ini digunakan untuk modul INTERFACE PAYMENT GATEAWAY
    dbqueryrun(cparm0, cparm1, cparm2, function(data) {
        if (parseInt(JSON.parse(data)[0].errstat,10) === 0) {
            vServerConf = JSON.parse(data)[0].data[0];
            log_time("server up with setting : " + JSON.stringify(vServerConf));
            if (cMonitorKafka) { asyncHeartbeats(); }
            asyncListening();
        } else {
            log_time("error calling webservice : ");
            log_time(JSON.stringify(data));
        }
    });
    */
}

// Heartbeats
async function asyncHeartbeats() {
    var heart = heartbeats.createHeart(1000);
    heart.createEvent(5, function(count, last){
        kafkaproduce.serverstatus(vServerConf.parmKafkaServer, vServerConf.servercode, csStartup).catch((err) => { console.error("error in producer: ", err)});
    });
}

const dbqueryrunPre = function(aModule, parm0, parm1, parm2) {
    if ((aModule == 'dbKlinik') || (aModule == 'dbApotek')) {
        if (parm0 == 'user.token') {
            v_sqlquery = "select pklk_usertoken('" + parm1 + "', '" + parm2 + "') as sresult;";
        } else if (parm0 == 'view.admin') {
            v_sqlquery = "select pklk_viewadmin('" + parm1 + "', '" + parm2 + "') as sresult;";
        } else if (parm0 == 'view.user') {
            v_sqlquery = "select pklk_viewuser('" + parm1 + "', '" + parm2 + "') as sresult;";
        } else if (parm0 == 'view.tpendaftaran') {
            v_sqlquery = "select pklk_viewtpendaftaran('" + parm1 + "', '" + parm2 + "') as sresult;";
        } else if (parm0 == 'view.tpelayanan') {
            v_sqlquery = "select pklk_viewtpelayanan('" + parm1 + "', '" + parm2 + "') as sresult;";
        } else if (parm0 == 'view.tpembayaran') {
            v_sqlquery = "select pklk_viewtpembayaran('" + parm1 + "', '" + parm2 + "') as sresult;";
        } else if (parm0 == 'view.mmaster') {
            v_sqlquery = "select pklk_viewmmaster('" + parm1 + "', '" + parm2 + "') as sresult;";
        } else if (parm0 == 'view.cari') {
            v_sqlquery = "select pklk_viewcari('" + parm1 + "', '" + parm2 + "') as sresult;";
        } else if (parm0 == 'view.laporan') {
            v_sqlquery = "select pklk_viewlaporan('" + parm1 + "', '" + parm2 + "') as sresult;";
        } else if (parm0 == 'mobile.user') {
            v_sqlquery = "select pklk_mobileuser('" + parm1 + "', '" + parm2 + "') as sresult;";
        } else if (parm0 == 'int1.cetakan') {
            v_sqlquery = "select pklk_int1cetakan('" + parm1 + "', '" + parm2 + "') as sresult;";
        } else if (parm0 == 'int2.cetakan') {
            v_sqlquery = "select pklk_int2cetakan('" + parm1 + "', '" + parm2 + "') as sresult;";
        } else if (parm0 == 'int3.cetakan') {
            v_sqlquery = "select pklk_int3cetakan('" + parm1 + "', '" + parm2 + "') as sresult;";
        } else if (parm0 == 'lap1.laporan') {
            v_sqlquery = "select pklk_lap1laporan('" + parm1 + "', '" + parm2 + "') as sresult;";
        } else if (parm0 == 'lap2.laporan') {
            v_sqlquery = "select pklk_lap2laporan('" + parm1 + "', '" + parm2 + "') as sresult;";
        } else if (parm0 == 'lap3.laporan') {
            v_sqlquery = "select pklk_lap3laporan('" + parm1 + "', '" + parm2 + "') as sresult;";
        } else {
            log_time('Module ' + aModule + ', parm0 ' + parm0 + ', tidak dikenal');
            return false;
        }
    } else if (aModule == 'dbAntrian') {
        v_sqlquery = "select antr_elceantrian('" + parm1 + "', '" + parm2 + "') as sresult;";
    } else if (aModule == 'dbPayment') {
        if (parm0 == 'server.conf') {
            v_sqlquery = "select paym_serverconf('" + parm1 + "', '" + parm2 + "') as sresult;";
        } else if (parm0 == 'server.trxlog') {
            v_sqlquery = "select paym_servertrxlog('" + parm1 + "', '" + parm2 + "') as sresult;";
        } else if (parm0 == 'user.token') {
            v_sqlquery = "select paym_usertoken('" + parm1 + "', '" + parm2 + "') as sresult;";
        } else if (parm0 == 'dashboard.admin') {
            v_sqlquery = "select paym_dashboardadmin('" + parm1 + "', '" + parm2 + "') as sresult;";
        } else if (parm0 == 'dashboard.agen') {
            v_sqlquery = "select paym_dashboardagen('" + parm1 + "', '" + parm2 + "') as sresult;";
        } else {
            log_time('Module ' + aModule + ', parm0 ' + parm0 + ', tidak dikenal');
            return false;
        }
    } else if (aModule == 'dbKoperasi') {
        if (parm0 == 'user.token') {
            v_sqlquery = "select pkop_usertoken('" + parm1 + "', '" + parm2 + "') as sresult;";
        } else if (parm0 == 'dashboard.admin') {
            v_sqlquery = "select pkop_dashboardadmin('" + parm1 + "', '" + parm2 + "') as sresult;";
        } else if (parm0 == 'dashboard.anggota') {
            v_sqlquery = "select pkop_dashboardanggota('" + parm1 + "', '" + parm2 + "') as sresult;";
        } else if (parm0 == 'mobile.anggota') {
            v_sqlquery = "select pkop_mobileanggota('" + parm1 + "', '" + parm2 + "') as sresult;";
        } else {
            log_time('Module ' + aModule + ', parm0 ' + parm0 + ', tidak dikenal');
            return false;
        }
    } else if (aModule == 'dbPointOfSales') {
        if (parm0 == 'user.token') {
            v_sqlquery = "select ppos_susertoken('" + parm1 + "', '" + parm2 + "') as sresult;";
        } else if (parm0 == 'view.user') {
            v_sqlquery = "select ppos_suser('" + parm1 + "', '" + parm2 + "') as sresult;";
        } else if (parm0 == 'view.admin') {
            v_sqlquery = "select ppos_madmin('" + parm1 + "', '" + parm2 + "') as sresult;";
        } else if (parm0 == 'view.tpendaftaran') {
            v_sqlquery = "select ppos_tpendaftaran('" + parm1 + "', '" + parm2 + "') as sresult;";
        } else if (parm0 == 'view.tpelayanan') {
            v_sqlquery = "select ppos_tpelayanan('" + parm1 + "', '" + parm2 + "') as sresult;";
        } else if (parm0 == 'view.tkasir') {
            v_sqlquery = "select ppos_tkasir('" + parm1 + "', '" + parm2 + "') as sresult;";
        } else if (parm0 == 'view.tpembayaran') {
            v_sqlquery = "select ppos_tpembayaran('" + parm1 + "', '" + parm2 + "') as sresult;";
        } else if (parm0 == 'view.mmaster') {
            v_sqlquery = "select ppos_mmaster('" + parm1 + "', '" + parm2 + "') as sresult;";
        } else if (parm0 == 'view.cari') {
            v_sqlquery = "select ppos_viewcari('" + parm1 + "', '" + parm2 + "') as sresult;";
        } else if (parm0 == 'view.laporan') {
            v_sqlquery = "select ppos_viewlaporan('" + parm1 + "', '" + parm2 + "') as sresult;";
        } else if (parm0 == 'mobile.user') {
            v_sqlquery = "select ppos_mobileuser('" + parm1 + "', '" + parm2 + "') as sresult;";
        } else if (parm0 == 'int1.cetakan') {
            v_sqlquery = "select ppos_int1cetakan('" + parm1 + "', '" + parm2 + "') as sresult;";
        } else if (parm0 == 'int2.cetakan') {
            v_sqlquery = "select ppos_int2cetakan('" + parm1 + "', '" + parm2 + "') as sresult;";
        } else if (parm0 == 'int3.cetakan') {
            v_sqlquery = "select ppos_int3cetakan('" + parm1 + "', '" + parm2 + "') as sresult;";
        } else if (parm0 == 'lap1.laporan') {
            v_sqlquery = "select ppos_lap1laporan('" + parm1 + "', '" + parm2 + "') as sresult;";
        } else if (parm0 == 'lap2.laporan') {
            v_sqlquery = "select ppos_lap2laporan('" + parm1 + "', '" + parm2 + "') as sresult;";
        } else if (parm0 == 'lap3.laporan') {
            v_sqlquery = "select ppos_lap3laporan('" + parm1 + "', '" + parm2 + "') as sresult;";
        } else {
            log_time('Module ' + aModule + ', parm0 ' + parm0 + ', tidak dikenal');
            return false;
        }
    } else if (aModule == 'dbSAAPI') {
        if (parm0 == 'user.token') {
            v_sqlquery = "select pkab_saapi_usertoken('" + parm1 + "', '" + parm2 + "') as sresult;";
        } else if (parm0 == 'public.daftar') {
            v_sqlquery = "select pkab_saapi_pendaftaran('" + parm1 + "', '" + parm2 + "') as sresult;";
        } else if (parm0 == 'trxs.view') {
            v_sqlquery = "select pkab_saapi_trxs('" + parm1 + "', '" + parm2 + "') as sresult;";
        } else if (parm0 == 'trxs.update') {
            v_sqlquery = "select pkab_saapi_trxs('" + parm1 + "', '" + parm2 + "') as sresult;";
        } else {
            log_time('Module ' + aModule + ', parm0 ' + parm0 + ', tidak dikenal');
            return false;
        }
    } else {
        log_time('Module ' + aModule + ', tidak dikenal');
        return false;
    }
    return v_sqlquery;
}

async function dbqueryrun(aQuery, aConnectionString, result) {
    const   { Pool }            = require('pg');
    const   connectionString    = aConnectionString;
    const   pool                = new Pool({connectionString,});
    var     sresult             = '[{"errstat":"99998","errmsg":"Server DB Connection Error","rowno":0,"data":[]}]';

    log_time(aQuery)
    ;(async () => {
        const client = await pool.connect()
        var res;
        try {
            res = await client.query(aQuery);
            log_time('done : ' + aQuery.substring(0, 100) + '...')
            result(res.rows[0].sresult);
        } finally {
            // Make sure to release the client before any error handling,
            // just in case the error handling itself throws an error.
            client.release();
        }
        })().catch(err => {
            //log_time("----------------------------- result ----------------------------- ");
            //log_time(res.rows[0])
            log_time("----------------------------- error ----------------------------- ");
            log_time(err.stack);
            result(sresult);
    })
};

// Server runQuery
async function asyncServerRunQuery(aModuleDb, aSQLQuery, res) {
    const cModuleDb = aModuleDb;
    const lvHeadersResp = {
        "Access-Control-Allow-Headers": "Content-Type, Authorization",
        "Access-Control-Allow-Origin": "*", //req.headers.origin, //or the specific origin you want to give access to,
        "Access-Control-Allow-Credentials": true
    };
    const clSQLQuery = aSQLQuery;
    const cConnectionString = gvConnectionString[cModuleDb[0].ModuleDb];
    if (clSQLQuery) {
        log_time(cModuleDb[0].ModuleDb + ' query : ');
        dbqueryrun(clSQLQuery, cConnectionString, function(data) {
            // JSON.parse harusnya di try catch, untuk error handling salah parse
            var v_jsonarray = JSON.parse(data);
            res.writeHead(200, lvHeadersResp);
            res.write(JSON.stringify(v_jsonarray[0]));
            res.end();
        });
    } else {
        var lvReturnstring = '[{"errstat":"99998","errmsg":"' + cModuleDb[0].ModuleDb + ' error on modulename or parameter","rowno":0,"data":[]}]';
        log_time(lvReturnstring);
        res.write(lvReturnstring);
        res.end();
    }
}

// Server Listening
async function asyncListening() {
    const lvServerListening = http.createServer((req,res) => {
        const headers = {
            'Access-Control-Allow-Origin': '*', /* @dev First, read about security */
            "Access-Control-Allow-Methods": 'POST, GET, PUT, DELETE, OPTIONS',
            'Access-Control-Max-Age': 2592000, // 30 days
            /** add other headers as per requirement */
          };
          /*const lvHeadersResp = {
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            "Access-Control-Allow-Headers": "Content-Type",
            "Access-Control-Allow-Origin": req.headers.origin, //req.headers.origin, //or the specific origin you want to give access to,
            "Access-Control-Allow-Credentials": true,
            "Access-Control-Allow-Methods": 'POST, GET, PUT, DELETE, OPTIONS'
        };*/

        const pathName = url.parse(req.url,true).pathname;
        var lvQueryObject, lvDataPOSTRequest;
        var lvParam0, lvParam1, lvParam2, lvParam3;
        var lvReturnstring = '[{"errstat":"99990","errmsg":"service tidak dikenal.","rowno":0,"data":[]}]';
        var vNotCompleteRespond = true;

        // module
        const cModuleDb = getModuleDb(pathName);
        if (cModuleDb.length != 1) { 
            if (pathName == '/favicon.ico') {
                vNotCompleteRespond = false;
                res.write('ok');
                res.end();
            } else {
                vNotCompleteRespond = false;
                log_time('respon pathname "' + pathName + '" tidak dikenal ke : ' + req.socket.remoteAddress);
                res.write(lvReturnstring);
                res.end();
            }
        }

        // parameter
        if (vNotCompleteRespond) {
            console.log('REQUEST mode recieve ...' + req.method);
            if (req.method == 'POST') {
                req.on('data', function(data) {
                    console.log('DATA recieve ...');
                    lvDataPOSTRequest = '' + data;
                    lvQueryObject = url.parse(lvDataPOSTRequest,true).query;
                    if (lvQueryObject.parm0) {
                        if (lvQueryObject.parm0) { lvParam0 = lvQueryObject.parm0; }
                        if (lvQueryObject.parm1) { lvParam1 = lvQueryObject.parm1; }
                        if (lvQueryObject.parm2) { lvParam2 = lvQueryObject.parm2; }
                        if (lvQueryObject.parm3) { lvParam3 = lvQueryObject.parm3; }
                        const aSQLQueryPOST = dbqueryrunPre(cModuleDb[0].ModuleDb, lvParam0, lvParam1, lvParam2);
                        asyncServerRunQuery(cModuleDb, aSQLQueryPOST, res);
                    } else {
                        vNotCompleteRespond = false;
                        lvReturnstring = '[{"errstat":"00000","errmsg":"parameter tidak dikenal.","rowno":0,"data":[]}]';
                        res.write(lvReturnstring);
                        res.end();
                    }
                })
            } else if (req.method == 'OPTIONS') {
                    console.log(req.headers.origin);
                    res.writeHead(204, headers);
                    res.write('ok');
                    res.end();
            } else {
                lvQueryObject = url.parse(req.url,true).query;
                if (lvQueryObject.parm0) {
                    if (lvQueryObject.parm0) { lvParam0 = lvQueryObject.parm0; }
                    if (lvQueryObject.parm1) { lvParam1 = lvQueryObject.parm1; }
                    if (lvQueryObject.parm2) { lvParam2 = lvQueryObject.parm2; }
                    if (lvQueryObject.parm3) { lvParam3 = lvQueryObject.parm3; }
                    const aSQLQuery = dbqueryrunPre(cModuleDb[0].ModuleDb, lvParam0, lvParam1, lvParam2);
                    asyncServerRunQuery(cModuleDb, aSQLQuery, res);
                } else {
                    vNotCompleteRespond = false;
                    lvReturnstring = '[{"errstat":"00000","errmsg":"parameter tidak dikenal.","rowno":0,"data":[]}]';
                    res.write(lvReturnstring);
                    res.end();
                }
            }
        }
    });

    lvServerListening.listen(vServerConf.serverport, () => {
        log_time('server is listening on port ' + vServerConf.serverport);
    });

    lvServerListening.on('error', function (e) {
        log_time(e);
    });
}
