# Setting Firewall
> firewall-cmd --permanent --add-port=6868/tcp
> firewall-cmd --reload

# config sample = appjs_dbwservice_config.json
{
    "port": 64068,
    "serverID": 0,
    "envMode":"api.kesehatan.app",
    "dbKlinik": {
        "api.kesehatan.app" : {
            "username" : "postgres",
            "password" : "password",
            "hostport" : "192.168.99.1:9989",
            "dbName"   : "JALURKlinik"
        }
    },
    "dbApotek": {
        "api.kesehatan.app" : {
            "username" : "postgres",
            "password" : "password",
            "hostport" : "localhost:9989",
            "dbName"   : "JALURApotek"
        }
    },
    "dbKoperasi": {
        "api.kesehatan.app" : {
            "username" : "postgres",
            "password" : "password",
            "hostport" : "localhost:9989",
            "dbName"   : "JALURKoperasi"
        }
    },
    "dbPemkabSAAPI": {
        "api.kesehatan.app" : {
            "username" : "postgres",
            "password" : "password",
            "hostport" : "localhost:9989",
            "dbName"   : "tangkabSAAPI"
        }
    },
    "dbPayment": {
        "api.kesehatan.app" : {
            "username" : "postgres",
            "password" : "password",
            "hostport" : "localhost:9989",
            "dbName"   : "JALURPay"
        }
    }
}
