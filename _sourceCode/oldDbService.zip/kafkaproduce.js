const { Kafka } = require('kafkajs');
async function kafkaproduce_serverstatus(abroker, aclientId, sStartup) {
    const topic       = "servers.status";
    const brokers     = [abroker];
    const kafka       = new Kafka({ clientId: aclientId, brokers: brokers, waitForLeaders: true }); 
    const producer    = kafka.producer();
    var currentdate   = new Date(); 
    var stanggal      = ('0' + currentdate.getFullYear()).slice(-4)  + "-" +
                        ('0' + (currentdate.getMonth() + 1)).slice(-2)  + "-" +
                        ('0' + currentdate.getDate()).slice(-2)  + " " +
                        ('0' + currentdate.getHours()).slice(-2) + ":"  +
                        ('0' + currentdate.getMinutes()).slice(-2) + ":" +
                        ('0' + currentdate.getSeconds()).slice(-2);

    var     vTimeInterval   = '';
    var     vDatetimetest   = Date.parse(stanggal) - Date.parse(sStartup);
    var     vSecond = true;
    if (parseInt(vDatetimetest / (1000 * 60 * 60 * 24)) > 0) {
        vTimeInterval = vTimeInterval + parseInt(vDatetimetest / (1000 * 60 * 60 * 24)) + 'd';
        vDatetimetest = vDatetimetest - (parseInt(vDatetimetest / (1000 * 60 * 60 * 24)) * (1000 * 60 * 60 * 24))
    };
    if (parseInt(vDatetimetest / (1000 * 60 * 60)) > 0) {
        if (vTimeInterval.length > 0) { vTimeInterval = vTimeInterval + ' '}
        vTimeInterval = vTimeInterval + parseInt(vDatetimetest / (1000 * 60 * 60)) + 'h';
        vDatetimetest = vDatetimetest - (parseInt(vDatetimetest / (1000 * 60 * 60)) * (1000 * 60 * 60))
    };
    if (parseInt(vDatetimetest / (1000 * 60)) > 0) {
        if (vTimeInterval.length > 0) { vTimeInterval = vTimeInterval + ' '; vSecond = false;}
        vTimeInterval = vTimeInterval + parseInt(vDatetimetest / (1000 * 60)) + 'm';
        vDatetimetest = vDatetimetest - (parseInt(vDatetimetest / (1000 * 60)) * (1000 * 60))
    };
    if ((parseInt(vDatetimetest / (1000)) > 0) && vSecond) {
        if (vTimeInterval.length > 0) { vTimeInterval = vTimeInterval + ' '}
        vTimeInterval = vTimeInterval + parseInt(vDatetimetest / (1000)) + 's';
        vDatetimetest = vDatetimetest - (parseInt(vDatetimetest / (1000)) * (1000))
    };

    await producer.connect()
    await producer.send({
    topic: topic,
        messages: [ { key: "server.status", value: '{"name":"' + aclientId + '","lastdate":"' + stanggal + '","startup":"' + vTimeInterval + '","status":"up"}' } ],
    });
    await producer.disconnect();
}

module.exports.serverstatus = kafkaproduce_serverstatus
