<template>
  <nav
    class="navbar navbar-main bg-gradient-secondary navbar-expand-lg px-0 mx-4 shadow-none border-radius-xl"
    v-bind="$attrs"
    id="controlBar"
  >
    <div class="container-fluid">
        <card
          :value="stats.tambah.value"
          :iconClass="stats.tambah.iconClass"
          :iconBackground="stats.tambah.iconBackground"
        ></card>
        <card
          :value="stats.ubah.value"
          :iconClass="stats.ubah.iconClass"
          :iconBackground="stats.ubah.iconBackground"
        ></card>
        <card
          :value="stats.cetak.value"
          :iconClass="stats.cetak.iconClass"
          :iconBackground="stats.cetak.iconBackground"
        ></card>
        <card
          :value="stats.cari.value"
          :iconClass="stats.cari.iconClass"
          :iconBackground="stats.cari.iconBackground"
        ></card>
    </div>
  </nav>
</template>
<script>

import Card from "@/examples/Cards/Card.vue";
import { mapMutations, mapActions } from "vuex";

export default {
  name: "navbar",
  data() {
    return {
      showMenu: false,
      stats: {
        tambah: {
          value: "Tambah",
          iconClass: "ni ni-money-coins",
          iconBackground: "bg-gradient-primary",
        },
        ubah: {
          value: "Ubah",
          iconClass: "ni ni-world",
          iconBackground: "bg-gradient-danger",
        },
        cari: {
          value: "Cari",
          iconClass: "ni ni-paper-diploma",
          iconBackground: "bg-gradient-success",
        },
        cetak: {
          value: "Cetak",
          iconClass: "ni ni-cart",
          iconBackground: "bg-gradient-warning",
        },
      }
    };
  },
  props: ["minNav", "textWhite"],
  created() {
    this.minNav;
  },
  methods: {
    ...mapMutations(["navbarMinimize", "toggleConfigurator"]),
    ...mapActions(["toggleSidebarColor"]),

    toggleSidebar() {
      this.toggleSidebarColor("bg-white");
      this.navbarMinimize();
    }
  },
  components: {
    Card
  },
  computed: {
    currentRouteName() {
      return this.$route.name;
    }
  }
};
</script>
