<template>
  <router-link :to="url" class="nav-link" v-bind="$attrs">
    <div
      class="icon icon-shape icon-sm text-center d-flex align-items-center justify-content-center"
    >
      <slot name="icon"></slot>
    </div>
    <div class="card">
      <div class="bg-white icon icon-shape icon-lg bg-gradient-success shadow text-center border-radius-lg">
        <i class="opacity-10 text-white fas fa-landmark" aria-hidden="true"></i>
      </div>
      <h6 class="mb-0 text-center">Simpan</h6>
  </div>

    <span
      class="nav-link-text"
      :class="this.$store.state.isRTL ? ' me-1' : 'ms-1'"
      >{{ navText }}</span>
  </router-link>
</template>
<script>
export default {
  name: "sidenav-item",
  props: {
    url: {
      type: String,
      required: true
    },
    navText: {
      type: String,
      required: true
    }
  }
};
</script>
