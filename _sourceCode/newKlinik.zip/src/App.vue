<template>
    <div  :class="[this.$store.state.showNavbar ? (this.$store.state.gErrorCode === 0 ? 'errorHide' : 'errorShow') : 'navbarOff']"
        style="z-index: 10; background-color: #33AA99;">
        <hr style="margin: 8px; color: transparent">
        <router-view/>
        <app-footer v-show="this.$store.state.showFooter" />
        <configurator
            :toggle="toggleConfigurator"
            :class="[
              this.$store.state.showConfig ? 'show' : '',
              this.$store.state.hideConfigButton ? 'd-none' : ''
            ]"
        />
        <modalMessage />
    </div>
        <div
            v-show="this.$store.state.layout === 'landing'"
            class="landing-bg h-100 w-100"
            style="z-index: 20; background-color: aquamarine;"
        >
        </div>

        <!-- nav -->
        <!--
        <div  v-show="this.$store.state.showNavbar" 
              style="top: 0; height: 110px; 
              width: 100%; z-index: 20;">
        -->
        <navbar
            :textWhite="'text-white opacity-8'"
            :style="['top: 0; z-index: 20; width: 100%; height: 110px; position: fixed; background-color: aquamarine']"
        />
        <!--
        </div>
        -->
        <div v-show="this.$store.state.showNavbar" style="position: fixed; margin-top: -50px; padding-top: -20px; width: 100%; z-index: 100;">
            <!--
            <Control
              :class="['mx-4']"
              :textWhite="'text-white opacity-8'"
              v-if="this.$store.state.showControl"
            />
            -->
            <hr style="margin: 2px; color: transparent">
            <Error
                :class="[navClasses]"
                :textWhite="'text-white'"
                v-if="this.$store.state.gErrorCode !== 0"
            />
        </div>
</template>
<script>
import Configurator from "@/examples/Configurator.vue";
import Navbar from "@/layout/Navbars/Navbar.vue";
//import Control from "./layout/Controls/index.vue";
import Error from "./layout/Errors/index.vue";
import AppFooter from "@/examples/Footer.vue";
import modalMessage from "@/layout/Modals/modalMessage.vue";
import { mapMutations } from "vuex";

export default {
  name: "App",
  components: {
    Configurator,
    Navbar,
    //Control,
    Error,
    modalMessage,
    AppFooter
  },
  methods: {
    ...mapMutations(["toggleConfigurator", "navbarMinimize"]),
    clickevent() {
      alert('clickevent');
    }
  },
  computed: {
    navClasses() {
      return {
        "position-sticky left-auto top-0 z-index-sticky":
          this.$store.state.isNavFixed && !this.$store.state.darkMode,
        "position-sticky bg-default left-auto top-2 z-index-sticky":
          this.$store.state.isNavFixed && this.$store.state.darkMode,
        "position-absolute top-0 px-0 mx-0 w-100 z-index-2": this.$store.state
          .isAbsolute,
        "px-0 mx-0": !this.$store.state.isAbsolute
      };
    }
  },
  beforeMount() {
    this.$store.state.isTransparent = "bg-transparent";
  }
};
</script>
<style scoped>
.navbarOff {
  padding-top: 0px;
}
.errorShow {
  padding-top: 305px;
}
.errorHide {
  padding-top: 250px;
}
</style>