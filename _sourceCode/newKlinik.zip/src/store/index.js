import { createStore } from "vuex";

export default createStore({
  state: {
    SESSIONaccessToken : '',
    SESSIONusername : '',
    SESSIONuserdesc : '',
    SESSIONuserrole : '',
    gEditMode: false,
    gErrorCode: 0,
    gErrorMsg: '',
    gModalMessage: '',
    gModalSearch: false,
    gControlType: 'controlJualan',
    gTrxCode: '0',
    hideConfigButton: true,
    isPinned: false,
    showConfig: false,
    sidebarType: "bg-white",
    isRTL: false,
    mcolor: "",
    darkMode: false,
    isNavFixed: true,
    isAbsolute: false,
    isNavHorizontal: false,
    showNavs: true,
    showSidenav: false,
    showNavbar: false,
    showControl: false,
    showFooter: false,
    showMain: true,
    layout: "default"
  },
  mutations: {
    setSession(state, n) {
      state.SESSIONaccessToken = n.accessToken
      state.SESSIONusername = n.username
      state.SESSIONuserdesc = n.userdesc
      state.SESSIONuserrole = n.userrole
    },
    logoutSession(state) {
      sessionStorage.clear()
      state.SESSIONaccessToken = ''
      state.SESSIONusername = ''
      state.SESSIONuserdesc = ''
      state.SESSIONuserrole = ''
    },
    toggleConfigurator(state) {
      state.showConfig = !state.showConfig;
    },
    navbarMinimize(state) {
      const sidenav_show = document.querySelector(".g-sidenav-show");

      if (sidenav_show.classList.contains("g-sidenav-hidden")) {
        sidenav_show.classList.remove("g-sidenav-hidden");
        sidenav_show.classList.add("g-sidenav-pinned");
        state.isPinned = true;
      } else {
        sidenav_show.classList.add("g-sidenav-hidden");
        sidenav_show.classList.remove("g-sidenav-pinned");
        state.isPinned = false;
      }
    },
    sidebarType(state, payload) {
      state.sidebarType = payload;
    },
    navbarFixed(state) {
      if (state.isNavFixed === false) {
        state.isNavFixed = true;
      } else {
        state.isNavFixed = false;
      }
    }
  },
  actions: {
    toggleSidebarColor({ commit }, payload) {
      commit("sidebarType", payload);
    },
    loginSession(context, data) {
      sessionStorage.setItem('session', JSON.stringify(data))
      context.commit('setSession', data)
    },
    getSession(context) {
      const session = sessionStorage.getItem('session')
      if (session && typeof session === 'string' && session !== '') {
        const data = JSON.parse(session)
        context.commit('setSession', data)
      }
    },
    logoutSession(context) {
      context.commit('logoutSession')
    }
  },
  getters: {
    getLogin(state) {
      return typeof state.SESSIONaccessToken === 'string' && state.SESSIONaccessToken !== ''
    },
    getToken(state) {
      return state.SESSIONaccessToken
    },
    getUsername(state) {
      return state.SESSIONusername
    },
    getUserdesc(state) {
      return state.SESSIONuserdesc
    },
    getUserrole(state) {
      return state.SESSIONuserrole
    }
  }
});
