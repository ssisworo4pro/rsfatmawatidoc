<template>
    <a class="controlButton" @click="$emit('click-button')" :class="[this.disabled ? 'disabled' : '']" :disabled="this.disabled">
        <div class="card" style="border-radius: 1rem;">
            <div :class="[this.disabled ? 'bg-secondary' : 'bg-gradient-success']" class="px-3 text-center" style="height: 35px; border-radius: 1rem;">
                <hr style="margin: 2px; color: transparent">
                <strong><h6 class="mb-0 text-center" :class="[this.disabled ? 'ColorDisabled' : 'ColorEnabled']">{{ desc }}</h6></strong>
            </div>
        </div>
    </a>
</template>

<script>
    export default {
        name: "ControlItem",
        emits: ['click-button'],
        props: {
            disabled: Boolean,
            name: { type: String, required: true },
            desc: { type: String, required: true }
        }
    };
</script>
<style scoped>
    .ColorEnabled { color: #2717a0; cursor: pointer; }
    .ColorDisabled { color: #cccccc; cursor: not-allowed;}
    .controlButton{ padding: 2px 3px;}
</style>
