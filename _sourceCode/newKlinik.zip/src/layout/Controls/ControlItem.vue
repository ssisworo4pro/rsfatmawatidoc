<template>
    <a class="controlButton" @click="$emit('click-button')" :class="[this.disabled ? 'disabled' : '']" :disabled="this.disabled">
        <div class="card" style="border-radius: 1rem;">
            <div :class="[this.disabled ? 'bg-secondary' : 'bg-gradient-success']" class="icon icon-shape icon-lg text-center" style="width: 90px;">
                <i style="font-size: 1.5rem; top:8px;" :class="[name && `fa fa-${name}`, this.disabled ? 'ColorDisabled' : 'ColorEnabled']" aria-hidden="true"></i>
                <hr style="margin: 2px; color: transparent">
            <strong><h6 class="mb-0 text-center" :class="[this.disabled ? 'ColorDisabled' : 'ColorEnabled']">{{ desc }}</h6></strong>
            </div>
        </div>
    </a>
</template>

<script>
    export default {
        name: "ControlItem",
        emits: ['click-button'],
        props: {
            disabled: Boolean,
            name: { type: String, required: true },
            desc: { type: String, required: true }
        }
    };
</script>
<style scoped>
    .ColorEnabled { color: #2717a0; cursor: pointer; }
    .ColorDisabled { color: #cccccc; cursor: not-allowed;}
    .controlButton{ padding: 2px 3px;}
</style>
