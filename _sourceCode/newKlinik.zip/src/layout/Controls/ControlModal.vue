<template>
    <nav
        class="navbar bg-gradient-secondary navbar-expand-lg shadow-lg border-radius-md"
        v-bind="$attrs"
        id="controlBar"
        style="width:100%; margin: 0;"
    >
        <ControlItem :name="'window-close'" :desc="'Tutup'" @click-button="$emit('click-close')"/>
    </nav>
</template>

<script>
    import ControlItem from "./ControlItem.vue";
    export default {
        name: "navbar",
        emits: ['click-close'],
        components: {
            ControlItem
        }
    };
</script>
