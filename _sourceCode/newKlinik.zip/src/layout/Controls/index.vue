<template>
    <nav
        class="navbar bg-gradient-secondary navbar-expand-lg shadow-lg border-radius-md"
        v-bind="$attrs"
        id="controlBar"
    >
        <ControlItem v-if="this.$store.state.gControlType === 'controlStandar'" :name="'plus'" :desc="'Tambah'" :disabled="this.$store.state.gEditMode" @click-button="toEditMode()"/>
        <ControlItem v-if="this.$store.state.gControlType === 'controlStandar'" :name="'edit'" :desc="'Ubah'"   :disabled="!this.$store.state.gEditMode"  @click-button="toEditMode()"/>
        <ControlItem v-if="this.$store.state.gControlType === 'controlStandar'" :name="'save'" :desc="'Simpan'" :disabled="!this.$store.state.gEditMode"  @click-button="toEditMode()"/>
        <ControlItem v-if="this.$store.state.gControlType === 'controlStandar'" :name="'undo'" :desc="'Batal'" :disabled="!this.$store.state.gEditMode"  @click-button="toReadMode()"/>
        <ControlItem v-if="this.$store.state.gControlType === 'controlStandar'" :name="'trash'" :desc="'Hapus'" :disabled="this.$store.state.gEditMode"  @click-button="toActionSearch()"/>
        <ControlItem v-if="this.$store.state.gControlType === 'controlStandar'" :name="'print'" :desc="'Cetak'" :disabled="this.$store.state.gEditMode"  @click-button="toActionPrint()"/>
        <ControlItem v-if="this.$store.state.gControlType === 'controlJualan'" :name="'search'" :desc="'Cari'" :disabled="!this.$store.state.gEditMode"  @click-button="toActionSearch()"/>
        <ControlItem v-if="this.$store.state.gControlType === 'controlJualan'" :name="'dollar'" :desc="'Bayar'" :disabled="!this.$store.state.gEditMode"  @click-button="toActionSearch()"/>
        <ControlItem v-if="this.$store.state.gControlType === 'controlJualan'" :name="'file'" :desc="'Reset'" :disabled="!this.$store.state.gEditMode"  @click-button="toActionSearch()"/>
        <ControlItem v-if="this.$store.state.gControlType === 'controlJualan'" :name="'arrow-right'" :desc="'Lewati'" :disabled="!this.$store.state.gEditMode"  @click-button="toActionSearch()"/>
    </nav>
</template>

<script>
    import ControlItem from "./ControlItem.vue";
    export default {
        name: "navbar",
        components: {
            ControlItem
        },
        methods: {
            toEditMode() {
                if (!this.$store.state.gEditMode) {
                    this.$store.state.gEditMode = true;
                }
            },
            toReadMode() {
                if (this.$store.state.gEditMode) {
                    this.$store.state.gEditMode = false;
                }
            },
            toActionPrint() {
            },
            toActionSearch() {
                this.$store.state.gModalSearch = true;
            }
        }
    };
</script>
