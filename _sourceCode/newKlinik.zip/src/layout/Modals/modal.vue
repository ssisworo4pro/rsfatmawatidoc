<script>
    import ControlModal from "@/layout/Controls/ControlModal.vue";
    export default {
        emits: ['close'],
        components: {
            ControlModal
        },
        props: {
            show: Boolean,
            modalType: String
        }
    }
</script>

<template>
  <Transition name="modal">
    <div v-if="show" class="modal-mask">
      <div :class="[modalType]" class="modal-container bg-gradient-success">
        <div class="modal-header" style="margin: 0; padding: 5px; width: 100%; color: black; font-size: 1em; font-weight: bold;">
              <slot name="header">
                default header
            </slot>
        </div>

        <div class="modal-body" style="margin: 0; padding: 5px; color: black; font-size: 1em; font-weight: bold;">
            <slot name="body">default body</slot>
        </div>
        <hr style="margin: 2px; color: transparent">
        <ControlModal
          :textWhite="'text-white opacity-8'"
          @click-close="$emit('close');"
        />
      </div>
    </div>
  </Transition>
</template>

<style>
.modalSearch {
  width: 90%;
}

.modalMessage {
  width: 450px;
}

.modal-mask {
  position: fixed;
  z-index: 9998;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.5);
  display: flex;
  transition: opacity 0.3s ease;
}

.modal-container {
  margin: auto;
  padding: 10px 20px;
  background-color: #fff;
  border-radius: 2px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.33);
  transition: all 0.3s ease;
}

.modal-header {
  width: 100%;
  margin-top: 0;
  color: #42b983;
}

.modal-body {
  margin: 10px 0;
  border: 0 solid rgba(0, 0, 0, 0.125);
  border-radius: 0.1rem;
}

.modal-default-button {
  float: right;
}

/*
 * The following styles are auto-applied to elements with
 * transition="modal" when their visibility is toggled
 * by Vue.js.
 *
 * You can easily play with the modal transition by editing
 * these styles.
 */

.modal-enter-from {
  opacity: 0;
}

.modal-leave-to {
  opacity: 0;
}

.modal-enter-from .modal-container,
.modal-leave-to .modal-container {
  -webkit-transform: scale(1.1);
  transform: scale(1.1);
}
</style>