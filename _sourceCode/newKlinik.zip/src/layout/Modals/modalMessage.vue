<template>
    <Teleport to="body">
    <modal :show="(this.$store.state.gModalMessage !== '')" @close="this.$store.state.gModalMessage = ''" :modalType="'modalMessage'">
    <template #header>
        Perhatian !
    </template>
    <template #body>
        {{ this.$store.state.gModalMessage }}
    </template>
    </modal>
    </Teleport>
</template>

<script>
    import Modal from "../../layout/Modals/modal.vue"
    export default {
        components: {
            Modal
        }
    };
</script>
