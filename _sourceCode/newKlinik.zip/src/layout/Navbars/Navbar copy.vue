<template>
    <nav
        class="navbar navbar-main navbar-expand-lg px-0 mx-4 shadow-none border-radius-xl"
        v-bind="$attrs"
        id="navbarBlur"
        data-scroll="true"
    >
        <div class="px-3 py-1 container-fluid">
            <breadcrumbs :currentPage="currentRouteName" textWhite="text-white" />
            <div class="mt-2 collapse navbar-collapse mt-sm-0 me-md-0 me-sm-4" id="navbar">
                <div class="pe-md-3 d-flex align-items-center ms-md-auto">
                </div>
                <ul class="navbar-nav justify-content-end">
                    <!--
                    <li class="nav-item d-flex align-items-center">
                        <router-link
                            :to="{ name: 'Signin' }"
                            class="px-0 nav-link font-weight-bold text-black"
                            target="_blank"
                        >
                            <i class="fa fa-user me-sm-2"></i>
                            <span class="d-sm-inline d-none">Sign In</span>
                        </router-link>
                    </li>
                    -->
                    <!--
                    <li class="nav-item d-xl-none ps-3 d-flex align-items-center">
                        <a
                            href="#"
                            @click="toggleSidebar"
                            class="p-0 nav-link text-white"
                            id="iconNavbarSidenav"
                        >
                            <div class="sidenav-toggler-inner">
                                <i class="sidenav-toggler-line bg-white"></i>
                                <i class="sidenav-toggler-line bg-white"></i>
                                <i class="sidenav-toggler-line bg-white"></i>
                            </div>
                        </a>
                    </li>
                    -->
                    <!--
                    <li class="px-3 nav-item d-flex align-items-center">
                        <a class="p-0 nav-link text-dark" @click="toggleConfigurator">
                            <i class="cursor-pointer fa fa-cog fixed-plugin-button-nav"></i>
                        </a>
                    </li>
                    -->
                    <li class="nav-item dropdown d-flex align-items-center pe-2">
                        <a
                            href="#"
                            class="p-0 nav-link text-dark"
                            :class="[showMenu ? 'show' : '']"
                            id="dropdownMenuButton"
                            data-bs-toggle="dropdown"
                            aria-expanded="false"
                            style="z-index: 3051;"
                            @click="showMenu = !showMenu"
                        >
                            <i class="cursor-pointer fa fa-bell"></i>
                        </a>
                        <ul
                            class="px-2 py-3 dropdown-menu dropdown-menu-end me-sm-n4"
                            :class="showMenu ? 'show' : ''"
                            aria-labelledby="dropdownMenuButton"
                            style="z-index: 2051;"
                        >
                            <li class="mb-2" style="z-index: 2050; ">
                                <a class="dropdown-item border-radius-md" href="javascript:;">
                                    <div class="py-1 d-flex">
                                        <div class="my-auto">
                                            <img
                                              src="../../assets/img/team-2.jpg"
                                              class="avatar avatar-sm me-3"
                                              alt="user image"
                                            />
                                        </div>
                                        <div class="d-flex flex-column justify-content-center">
                                            <h6 class="mb-1 text-sm font-weight-normal">
                                                <span class="font-weight-bold">New message</span> 
                                                from Laur
                                            </h6>
                                            <p class="mb-0 text-xs text-secondary">
                                                <i class="fa fa-clock me-1"></i>
                                                13 minutes ago
                                            </p>
                                        </div>
                                    </div>
                                </a>
                            </li>
                            <li class="mb-2">
                                <a class="dropdown-item border-radius-md" href="javascript:;">
                                    <div class="py-1 d-flex">
                                        <div class="my-auto">
                                            <img
                                                src="../../assets/img/small-logos/logo-spotify.svg"
                                                class="avatar avatar-sm bg-gradient-dark me-3"
                                                alt="logo spotify"
                                            />
                                        </div>
                                        <div class="d-flex flex-column justify-content-center">
                                            <h6 class="mb-1 text-sm font-weight-normal">
                                                <span class="font-weight-bold">New album</span> by Travis Scott
                                            </h6>
                                            <p class="mb-0 text-xs text-secondary">
                                                <i class="fa fa-clock me-1"></i>
                                                1 day
                                            </p>
                                        </div>
                                    </div>
                                </a>
                            </li>
                            <li>
                                <a class="dropdown-item border-radius-md" href="javascript:;">
                                    <div class="py-1 d-flex">
                                        <div class="my-auto avatar avatar-sm bg-gradient-secondary me-3">
                                            <svg
                                                width="12px"
                                                height="12px"
                                                viewBox="0 0 43 36"
                                                version="1.1"
                                                xmlns="http://www.w3.org/2000/svg"
                                                xmlns:xlink="http://www.w3.org/1999/xlink"
                                            >
                                                <title>credit-card</title>
                                                <g
                                                    stroke="none"
                                                    stroke-width="1"
                                                    fill="none"
                                                    fill-rule="evenodd"
                                                >
                                                    <g
                                                        transform="translate(-2169.000000, -745.000000)"
                                                        fill="#FFFFFF"
                                                        fill-rule="nonzero"
                                                    >
                                                        <g transform="translate(1716.000000, 291.000000)">
                                                            <g transform="translate(453.000000, 454.000000)">
                                                                <path
                                                                    class="color-background"
                                                                    d="M43,10.7482083 L43,3.58333333 C43,1.60354167 41.3964583,0 39.4166667,0 L3.58333333,0 C1.60354167,0 0,1.60354167 0,3.58333333 L0,10.7482083 L43,10.7482083 Z"
                                                                    opacity="0.593633743"
                                                                />
                                                                <path
                                                                    class="color-background"
                                                                    d="M0,16.125 L0,32.25 C0,34.2297917 1.60354167,35.8333333 3.58333333,35.8333333 L39.4166667,35.8333333 C41.3964583,35.8333333 43,34.2297917 43,32.25 L43,16.125 L0,16.125 Z M19.7083333,26.875 L7.16666667,26.875 L7.16666667,23.2916667 L19.7083333,23.2916667 L19.7083333,26.875 Z M35.8333333,26.875 L28.6666667,26.875 L28.6666667,23.2916667 L35.8333333,23.2916667 L35.8333333,26.875 Z"
                                                                />
                                                            </g>
                                                        </g>
                                                    </g>
                                                </g>
                                            </svg>
                                        </div>
                                        <div class="d-flex flex-column justify-content-center">
                                            <h6 class="mb-1 text-sm font-weight-normal">
                                                Payment successfully completed
                                            </h6>
                                            <p class="mb-0 text-xs text-secondary">
                                                <i class="fa fa-clock me-1"></i>
                                                2 days
                                            </p>
                                        </div>
                                    </div>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class="dropdown notification-list">
                        <div class="dropdown notification-list nav-pro-img">
                            <a 
                                @click="onClick()"
                                class="dropdown-toggle nav-link arrow-none waves-effect nav-user" data-toggle="dropdown" href="#" role="button" aria-haspopup="false" aria-expanded="false">
                                <img
                                    src="../../assets/img/small-logos/logo-spotify.svg"
                                    class="rounded-circle avatar bg-gradient-dark me-3"
                                    alt="logo spotify"
                                    @click="onClick()"
                                />
                            </a>
                            <div class="dropdown-menu dropdown-menu-right profile-dropdown">
                                <!-- 
                                <a class="dropdown-item" href="#"><i class="mdi mdi-account-circle m-r-5"></i> Profile</a>
                                <a class="dropdown-item" href="#"><i class="mdi mdi-wallet m-r-5"></i> My Wallet</a>
                                <a class="dropdown-item d-block" href="#"><span class="badge badge-success float-right">11</span><i class="mdi mdi-settings m-r-5"></i> Settings</a>
                                <a class="dropdown-item" href="#"><i class="mdi mdi-lock-open-outline m-r-5"></i> Lock screen</a>
                                <div class="dropdown-divider"></div>
                                item-->
                                <div class="dropdown-item">ADMIN</div>
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item" onClick="onModalsFeatureChangeLogin(true);" href="#"><i class="mdi mdi-wallet m-r-5"></i> Ganti Password</a>
                                <a class="dropdown-item text-danger" href="/user/logout"><i class="mdi mdi-power text-danger"></i> Logout</a>
                            </div>                                                                    
                        </div>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
</template>

<script>
    import Breadcrumbs from "../Breadcrumbs.vue";
    export default {
        name: "navbar",
        data() {
            return {
                showMenu: false
            };
        },
        methods: {
            onClick() {
                alert('click');
            }
        },
        components: {
            Breadcrumbs
        },
        computed: {
            currentRouteName() {
                return this.$route.name;
            }
        }
    };
</script>
<style scoped>
.dropdown-item {
    background-color: #ffffff;
    padding: 0.55rem 1.5rem;
}
.dropdown-item {
    display: block;
    width: 100%;
    padding: 0.25rem 1.5rem;
    clear: both;
    font-weight: 400;
    color: #212529;
    text-align: inherit;
    white-space: nowrap;
    background-color: transparent;
    border: 0;
}
.dropdown-menu {
    padding: 4px 0;
    font-size: 13px;
    -webkit-box-shadow: 0 2px 30px rgba(0, 0, 0, 0.08);
    box-shadow: 0 2px 30px rgba(0, 0, 0, 0.08);
    background-color: #ffffff;
    border-color: transparent;
    margin: 0;
}
.dropdown-menu {
    position: absolute;
    top: 100%;
    left: 0;
    z-index: 1000;
    display: none;
    float: left;
    min-width: 10rem;
    padding: 0.5rem 0;
    margin: 0.125rem 0 0;
    font-size: 1rem;
    color: #212529;
    text-align: left;
    list-style: none;
    background-color: #fff;
    background-clip: padding-box;
    border: 1px solid rgba(0,0,0,.15);
    border-radius: 0.25rem;
}

</style>