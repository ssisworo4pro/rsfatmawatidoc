<template>
    <nav aria-label="breadcrumb">
        <h4 class="mb-0 font-weight-bolder text-dark">
            {{ currentPage }}
        </h4>
        <ol class="px-0 pt-1 pb-0 mb-0 bg-transparent breadcrumb me-sm-6 text-dark">
            <li class="text-sm breadcrumb-item">
                <a class="text-dark opacity-8" href="#">Pages</a>
            </li>
            <li class="text-sm breadcrumb-item active text-dark" aria-current="page">
                {{ currentPage }}
            </li>
        </ol>
    </nav>
</template>

<script>
    export default {
        name: "breadcrumbs",
        props: {
            currentPage: {
                required: true
            },
            textWhite: {
                type: String
            }
        }
    };
</script>
