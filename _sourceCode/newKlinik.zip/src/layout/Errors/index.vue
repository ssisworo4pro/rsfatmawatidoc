<template>
    <nav
        class="navbar bg-gradient-dark navbar-expand-lg shadow-lg border-radius-md"
        v-bind="$attrs"
        style="text-align: center; color : yellow"
        id="controlBar"
    >
        <h6 style="width: 100%; text-align: center; color : yellow"><strong>{{ this.$store.state.gErrorMsg }}</strong></h6>
    </nav>
</template>

<script>
    export default {
        name: "errors",
        computed: {
            gridHeight() { return this.$el && this.$el.offsetHeight }
        }
    };
</script>
