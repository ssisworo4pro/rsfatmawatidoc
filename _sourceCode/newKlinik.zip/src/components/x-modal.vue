<template>
    <div>
      <div class="modal modal-open">
        <div class="modal-box relative">
          <label class="btn btn-sm btn-circle absolute right-2 top-2">✕</label>
          <h1>Hey, it works 👏🏽</h1>
        </div>
      </div>
    </div>
  </template>
  