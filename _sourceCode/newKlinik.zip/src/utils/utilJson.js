function arrayTOjsoncount(aArray) {
    var jsonResult = {};
    for (var i=0; i < aArray.length; i++) {
        jsonResult = { ...jsonResult, [i+1] : aArray[i]};
    };
    return jsonResult;
}

function find_in_object(my_object, my_criteria){
    my_object = JSON.parse(JSON.stringify(my_object));
    return my_object.filter(function(obj) {
        return Object.keys(my_criteria).every(function(c) {
            return obj[c] == my_criteria[c];
        });
    });
}

function find_in_object_index(my_object, my_criteria){
    my_object = JSON.parse(JSON.stringify(my_object));
    return my_object.findIndex(function(obj) {
        return Object.keys(my_criteria).every(function(c) {
            return obj[c] == my_criteria[c];
        });
    });
}

export default {
    arrayTOjsoncount,
    find_in_object,
    find_in_object_index
}
