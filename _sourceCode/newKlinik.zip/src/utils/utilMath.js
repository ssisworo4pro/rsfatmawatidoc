function fmathNumberWithCommas(x) {
    return x.toString().replace(/\B(?<!\.\d*)(?=(\d{3})+(?!\d))/g, ",");
}

function fmathNumberWithPoints(x) {
    return x.toString().replace(/\B(?<!\.\d*)(?=(\d{3})+(?!\d))/g, ".");
}

export default {
    fmathNumberWithCommas,
    fmathNumberWithPoints
}
