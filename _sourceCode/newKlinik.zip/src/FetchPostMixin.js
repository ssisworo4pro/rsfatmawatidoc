// FetchPostMixin.js
const REQUEST_IN_PROGRESS = "REQUEST_IN_PROGRESS";
const REQUEST_ERROR = "REQUEST_ERROR";
const REQUEST_SUCCESS = "REQUEST_SUCCESS";

export default {
  data() {
    return {
      requestState: null,
      post: null
    };
  },
  computed: {
    loading() {
      return this.requestState === REQUEST_IN_PROGRESS;
    },
    error() {
      return this.requestState === REQUEST_ERROR;
    }
  },
  methods: {
    async fetchPost(parm) {
        this.post = null;
        this.requestState = REQUEST_IN_PROGRESS;
  
        const requestOptions = {
            method: 'POST',
            headers:    {   'Accept': 'application/json',
                            'Content-Type': 'application/json',
                            'Access-Control-Allow-Origin': '*',
                            'Access-Control-Allow-Headers': 'Content-Type',
                            'Access-Control-Allow-Methods': 'POST, GET, PUT, DELETE, OPTIONS',
                            'Access-Control-Allow-Credentials': 'true'
                        },
            body: parm
        };

        fetch('https://dev-api.kesehatan.app/localws/klinik', requestOptions)
            .then(async response => {
                const data = await response.json();
                // check for error response
                if (!response.ok) {
                    // get error message from body or default to response status
                    this.requestState = REQUEST_ERROR;
                    const error = (data && data.message) || response.status;
                    return Promise.reject(error);
                }
                this.requestState = REQUEST_SUCCESS;
                this.postId = data.id;
        })
        .catch(error => {
            this.requestState = REQUEST_ERROR;
            this.errorMessage = error;
            console.error('There was an error!', error);
        });
    }
  }
};
