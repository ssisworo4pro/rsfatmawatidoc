const serviceAuth = process.env.VUE_APP_AUTH_SERVICE

export default {
    serviceAuth: serviceAuth
}
