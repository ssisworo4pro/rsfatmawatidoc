import axios from 'axios'
import BaseURL from '@/config/constant'

async function selectPost(aToken, aData) {
    // const AuthTkn = '"Bearer ' + aToken + '"';
    const cUrl    = '';
    const headers =  {
                        'Content-Type': 'application/x-www-form-urlencoded',
                        'Access-Control-Allow-Origin': '*',
                        'Access-Control-Allow-Headers': 'Content-Type',
                        'Access-Control-Allow-Methods': 'POST, GET, PUT, DELETE, OPTIONS',
                        'Access-Control-Allow-Credentials': 'true'
                    };
    // "Authorization": AuthTkn};
    var dataResult = await postMethodCall(BaseURL.serviceAuth + cUrl, headers, aData);
    return dataResult;
}
  
async function postMethodCall(url, headers, dataString) {
    var errMessage = 'undefined error CALL POST WEBSERVICES.';
    var sReturn = JSON.parse('{"errstat":"99999","errmsg":"' + errMessage + '","rowno":0,"data":[]}');
    try { 
        const response = await axios.post(url, dataString, { headers: headers });
        //sReturn = JSON.parse('{"errstat":"0","errmsg":"success.","rowno":1,"data":[' + JSON.stringify(response.data) + ']}');
        sReturn = response.data;
    } catch (err) {
        if(err.response){
          errMessage = 'network ok, ' + err.response.status + ' ' + err.response.statusText;
        } else if(err.cause){ 
          errMessage = 'network failure, ' + err.cause;
        } else { 
          console.log('--- undefined error ---');
        }
        sReturn = JSON.parse('{"errstat":"99999","errmsg":"' + errMessage + '","rowno":0,"data":[]}');
    }
    return sReturn;
}
  
export default {
    selectPost
}
