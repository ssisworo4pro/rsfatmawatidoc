import axios from 'axios'
import BaseURL from '@/config/constant'

const aplikasi = axios.create({
  baseURL: BaseURL.serviceAuth,
  withCredentials: false,
  headers: {
    'Accept': 'application/json',
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'POST, GET, PUT, DELETE, OPTIONS',
    'Access-Control-Allow-Credentials': 'true'
  }
})

export default {
    aplikasi
}
