<!--
=========================================================
* Vue Argon Dashboard 2 - v3.0.0
=========================================================

* Product Page: https://creative-tim.com/product/vue-argon-dashboard
* Copyright 2022 Creative Tim (https://www.creative-tim.com)

Coded by www.creative-tim.com

=========================================================

* The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
-->
<template>
  <div
    v-show="this.$store.state.layout === 'landing'"
    class="landing-bg h-100 position-fixed w-100"
    style="background-color: aquamarine;"
  ></div>
  <sidenav
    :custom_class="this.$store.state.mcolor"
    :class="[
      this.$store.state.isTransparent,
      this.$store.state.isRTL ? 'fixed-end' : 'fixed-start'
    ]"
    v-if="this.$store.state.showSidenav"
  />
  <main
    class="main-content position-relative max-height-vh-100 h-100 border-radius-lg"
  >
    <!-- nav -->
    <div style="top: 0; height: 110px; background-color: aquamarine; position: fixed; width: 100%; z-index: 20;">
      <navbar
        :class="[navClasses]"
        :textWhite="
          this.$store.state.isAbsolute ? 'text-white opacity-8' : 'text-white'
        "
        :minNav="navbarMinimize"
        v-if="this.$store.state.showNavbar"
      />
    </div>
    <div style="padding-top: 75px; position: fixed; width: 100%; z-index: 30;">
    <Control
      :class="[navClasses]"
      :textWhite="
        this.$store.state.isAbsolute ? 'text-white opacity-8' : 'text-white'
      "
      :minNav="navbarMinimize"
      v-if="this.$store.state.showNavbar"
    />
    <hr style="margin: 2px; color: transparent">
    <Error
      :class="[navClasses]"
      :textWhite="'text-white'"
      :minNav="navbarMinimize"
      v-if="this.$store.state.gErrorCode !== 0"
    />
  </div>

  <div  class="bg-gradient-success" 
        :class="[this.$store.state.gErrorCode === 0 ? 'errorHide' : 'errorShow']"
        style="z-index: 10;">
    <hr style="margin: 8px; color: transparent">
    <router-view />
    <app-footer v-show="this.$store.state.showFooter" />
    <configurator
      :toggle="toggleConfigurator"
      :class="[
        this.$store.state.showConfig ? 'show' : '',
        this.$store.state.hideConfigButton ? 'd-none' : ''
      ]"
    />
    <modalMessage />
    <modalSearch @pilih="this.searchPilih()"/>
  </div>
  
  </main>
</template>
<script>
import Sidenav from "./examples/Sidenav";
import Configurator from "@/examples/Configurator.vue";
import Navbar from "@/examples/Navbars/Navbar.vue";
import Control from "./layout/Controls/index.vue";
import Error from "./layout/Errors/index.vue";
import AppFooter from "@/examples/Footer.vue";
import modalMessage from "@/layout/Modals/modalMessage.vue";
import modalSearch from "@/layout/Modals/modalSearch.vue";

import { mapMutations } from "vuex";

export default {
  name: "App",
  components: {
    Sidenav,
    Configurator,
    Navbar,
    Control,
    Error,
    modalMessage,
    modalSearch,
    AppFooter
  },
  methods: {
    ...mapMutations(["toggleConfigurator", "navbarMinimize"]),
    searchPilih() {
      alert(this.$store.state.gTrxCode);
    }
  },
  computed: {
    navClasses() {
      return {
        "position-sticky left-auto top-0 z-index-sticky":
          this.$store.state.isNavFixed && !this.$store.state.darkMode,
        "position-sticky bg-default left-auto top-2 z-index-sticky":
          this.$store.state.isNavFixed && this.$store.state.darkMode,
        "position-absolute px-4 mx-0 w-100 z-index-2": this.$store.state
          .isAbsolute,
        "px-0 mx-4": !this.$store.state.isAbsolute
      };
    }
  },
  beforeMount() {
    this.$store.state.isTransparent = "bg-transparent";
  }
};
</script>
<style scoped>
.errorShow {
  padding-top: 305px;
}
.errorHide {
  padding-top: 250px;
}
</style>