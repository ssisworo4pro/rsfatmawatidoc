<template>
    <table class="table table-sm" style="border-spacing: 0; width: 100%;">
    <thead>
        <tr class="bg-dark text-white text-center">
            <th style="width: 5%;">No</th>
            <th style="width: 15%;">Nomor</th>
            <th style="width: 15%;">Tanggal</th>
            <th style="width: 25%;">Jns Penjualan</th>
            <th style="width: 10%;">Tagihan</th>
            <th style="width: 10%;">Bayar</th>
            <th style="width: 10%;">Status</th>
        </tr>
    </thead>
    <tbody :style="{'height': this.bodyTableHeight}">
        <tr v-for="(trxKatalog, index) in trxKatalogs" :key="index" @click="pilih(index)">
            <td class="text-right" style="width: 5%;">{{ index + 1 }}</td>
            <td class="text-center" style="width: 15%;">{{ trxKatalog.no_resep }}</td>
            <td class="text-center" style="width: 15%;">{{ trxKatalog.tgl_resep_desc }}</td>
            <td class="text-center" style="width: 25%;">{{ trxKatalog.jns_resep_desc }}</td>
            <td class="text-right" style="width: 10%;">{{ trxKatalog.nilai_tagihan }}</td>
            <td class="text-right" style="width: 10%;">{{ trxKatalog.nilai_bayar }}</td>
            <td class="text-center" style="width: 10%;">{{ trxKatalog.sts_lunas_desc }}</td>
        </tr>
    </tbody>
    <tfoot>
        <th class="bg-dark text-white text-center" colspan="7">-- 1 data ditemukan --</th>
    </tfoot>

    </table>
</template>

<script>
    import { mapActions, mapGetters } from "vuex";
    import ajaxServices from '@/services/index.js';

    export default {
        mixins: [ajaxServices],
        emits: ['click-pilih'],
        created() {
            this.getSession();
        },
        data() {
            return {
                trxKatalogs: [
                    {   no_urut: 4, no_resep : "R01202212260028", tgl_resep : "26-12-2022 16:55", tgl_resep_desc : "26-12-2022 16:55",
                        nilai_tagihan : "        99,000", nilai_bayar : "        99,000", sts_lunas : "1", sts_lunas_desc : "lunas", 
                        sts_proses_desc : "dr / perincian", jns_resep_desc : "Apotek" }
                ]
            };
        },
        computed: {
            ...mapGetters(["getToken"]),
            bodyTableHeight() {
                // 1034 - 464 = 570
                // 1034 - 849 ===> 185
                // 1034 - 350px
                var vTableBodyHeight = (window.innerHeight - 604) + 'px';
                return vTableBodyHeight;
            }
        },
        mounted() {
            this.GetDataTrx();
        },
        methods : {
            ...mapActions(["getSession"]),
            pilih(index) {
                this.$store.state.gTrxCode = this.trxKatalogs[index].no_resep;
                this.$emit('click-pilih');
            },
            async GetDataTrx() {
                var vparam    = '?parm0=view.cari&parm1=' + this.getToken;
                var datajson  = [{"cariPilihan":"pilihanterbaru"}];
                var datajsons = {"method":"cari.caritlynResepObat","data": datajson };
                vparam        = vparam + '&parm2=' + JSON.stringify(datajsons);
                var result    = await ajaxServices.selectPost(this.getToken, vparam );
                this.dataTrx  = result;
                this.$store.state.gErrorCode = parseInt(this.dataTrx.errstat);
                this.$store.state.gErrorMsg  = this.dataTrx.errmsg;
                if (this.$store.state.gErrorCode === 0) {
                    this.trxKatalogs = result.data;
                }
            }
        }
    };
</script>

<style scoped>
    table ,tr td{
        border:1px solid white;
        margin-bottom: 0;
    }
    table td {
        cursor: pointer;
    }
    tbody {
        display:block;
        overflow-y:scroll;
        overflow-x:hidden;
    }
    thead, tbody tr {
        display:table;
        width:100%;
        table-layout:fixed;/* even columns width , fix width of table too*/
    }
    thead {
        width: calc( 100% - 1em )/* scrollbar is average 1em/16px width, remove it from thead width */
    }
</style>