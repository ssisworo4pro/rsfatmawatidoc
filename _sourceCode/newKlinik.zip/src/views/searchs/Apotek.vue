<template>
    <Teleport to="body">
    <modal :show="(this.$store.state.gModalSearch)" @close="this.$store.state.gModalSearch = false" :modalType="'modalSearch'">
    <template #header>
        <div class="kriteria">
            <ApotekKriteria />
        </div>
        <hr style="margin: 1px; color: transparent">
    </template>
    <template #body>
        <div class="hasilCari">
            <ApotekSearchData />
        </div>
    </template>
    </modal>
    </Teleport>
</template>

<script>
    import Modal from "@/layout/Modals/modal.vue"
    import ApotekKriteria from "@/views/searchs/ApotekKriteria.vue"
    import ApotekSearchData from "@/views/searchs/ApotekSearchData.vue"
    export default {
        components: {
            Modal,
            ApotekKriteria,
            ApotekSearchData
        }
    };
</script>
<style scoped>
    .kriteria {
        padding: 10px 20px;
        background-color: aquamarine;
        border-radius: 0.4rem;
        width: 100%;
    }
    .hasilCari {
        padding: 5px;
        background-color: aquamarine;
        border-radius: 0.4rem;
    }
</style>