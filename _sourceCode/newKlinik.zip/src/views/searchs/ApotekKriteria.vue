<template>
    <div class="row">
        <div class="col-lg-12"><h4 class="mt-0 header-title">Cari Penjualan Obat</h4></div>
        <div class="col-lg-2">
                <input type="radio" id="onSearchKriteria_radio_terbaru" name="onSearchKriteria_radio" checked value="pilihanterbaru">
                <label for="onSearchKriteria_radio_terbaru">&nbsp; 200 data terbaru</label><br>
                <input type="radio" id="onSearchKriteria_radio_tglresep" name="onSearchKriteria_radio" value="pilihantglresep">
                <label for="onSearchKriteria_radio_tglresep">&nbsp; Tanggal Penjualan</label>
        </div>
        <div class="col-lg-7">
            <div class="col-sm-6" id="grp_onSearchKriteria_text" style="display: none;">
                <input class="form-control form-control-sm" type="text" value="" id="onSearchKriteria_text">
            </div>
            <div class="col-sm-6" id="grp_onSearchKriteria_norm" style="display: none;">
                <input class="form-control form-control-sm" type="text" value="" id="onSearchKriteria_norm">
            </div>
            <div class="col-sm-6" id="grp_onSearchKriteria_tanggal" style="display: none;">
                <input class="form-control form-control-sm" type="date" value="2022-01-18" id="onSearchKriteria_tanggal">
            </div>
        </div>
        <div class="col-lg-3">
            <button id="onSearchKriteria_btncari" style="width: 80%; height: 70%;" type="button" class="btn btn-primary vertical-center">Cari</button>
        </div>
        <div class="col-lg-12 error" id="grp_onSearchKriteria_errmsg" style="display: none;">
            Terjadi Kesalahan : error cuy .....
        </div>
    </div>
</template>
