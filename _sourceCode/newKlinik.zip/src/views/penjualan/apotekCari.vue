<template>
                <div id="grpItemLynModaltlynApotekPenjualanShow" style="height: 465px;">
                    <div id="grpItemLynModaltlynApotekPenjualan" style="height: 465px;">
                        <table class="table table-sm table-bordered table-trxs" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                            <tbody>
                                <tr>
                                    <td width="20%">
                                        <input disabled style="height: 39px; font-size: 19px;" class="bg-dark text-white form-control text-center" type="text" value="FILTER">
                                    </td>
                                    <td width="80%">
                                        <input id="filterKatalog" @change="FilterKatalog()" @focus="$event.target.select()" type="text" v-model="filterKatalog" style="height: 39px; font-size: 19px;" class="bg-white text-black form-control text-right">
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                        <div id="grpItemLynModaltlynApotekPenjualanButton" class="container-fluid-scroll scrollable" style="margin-left: 3px;" :style="{'height': this.tableBodyHeight}">
                                <button v-for="(mstKatalog, index) in mstKatalogs" 
                                    :key="index" type="button" @click="pilihKatalog(index)" 
                                    class="btn btn-success btn-billing"
                                    :filter="mstKatalog.nama" 
                                    >
                                    <hr style="margin: 2px; color: transparent">
                                    <h1>{{ mstKatalog.inisial }}</h1>
                                    <hr style="margin: 5px; color: transparent">
                                    <h6>{{ mstKatalog.harga }}<br/>{{ mstKatalog.nama }}</h6>
                                </button>
                        </div>
                    </div>
                    <div id="grpItemRacikanModaltlynApotekPenjualan" style="height: 465px; display : none;">
                        <table class="table table-sm table-bordered table-trxs form-group row" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                            <tbody>
                                <tr>
                                    <td width="20%">
                                        <input disabled style="height: 39px; font-size: 19px;" class="bg-dark text-white form-control text-center" type="text" value="FILTER">
                                    </td>
                                    <td width="80%">
                                        <input onClick="this.select();" onChange="onModaltlynApotekPenjualan_filter(this.value);" style="height: 39px; font-size: 19px;" class="bg-dark text-white form-control text-right" type="text" value="" id="input_filter_racikan" name="input_filter_racikan">
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                        <div id="grpItemRacikanModaltlynApotekPenjualanButton" class="container-fluid-scroll w-auto h-auto h-100" style="margin-left: 3px; height: 440px;">
    
                                    <button id="btnBahan<%- datadrop.key %>" 
                                        filter="<%- datadrop.nama %>" 
                                        type="button" 
                                        class="btn-billing bg-gradient-primary">
                                        <h1>inisial</h1>
                                        <h6>nama</h6>
                                    </button>
    
                        </div>
                    </div>
                </div>
</template>

<script>
    export default {
        expose: ['mstKatalogs'],
        emits: ['barcode'],
        data() {
            return {
                filterKatalog : '', 
                mstKatalogs: [
                    {"key" : "8999999719395", "kode" : "va", "harga" : "        15,000", "harga2" : "             0", "harga3" : "             0", "harga4" : "             0", "hargaqty1" : "             0", "hargaqty2" : "             0", "hargaqty3" : "             0", "hargaqty4" : "             0", "nama" : "vaseline restores", "barcode" : "8999999719395", "stsqty" : "1", "stsqtyadd" : "1", "stspaket" : "0", "stskunci" : "0", "stsedit" : "1", "stshsl" : "0", "stsaturanpakai" : "1", "input_qty" : "1", "inisial" : "vrm", "jnsitem" : 3, "value" : "vaseline restores moisture 100ml"}
                ]
            };
        },
        computed : {
            tableBodyHeight() {
                // 1034 - 734px = 300
                var vTableBodyHeight = (window.innerHeight - 274) + 'px';
                return vTableBodyHeight;
            }
            // v-if="(filterKatalog.length === 0) || (filterKatalog == mstKatalog.nama.substr(0,filterKatalog.length))"
        },
        methods : {
            FilterKatalog() {
                var vFilter = this.filterKatalog.toUpperCase();
                var vButton = document.getElementById("grpItemLynModaltlynApotekPenjualanButton");
                var vFilterText;
                for (var i = 0; i < vButton.childNodes.length; i++) {
                    if (vButton.childNodes[i].tagName == 'BUTTON') {
                        if (vFilter.length == 0) {
                            // show all
                            vButton.childNodes[i].style.display = "";
                        } else {
                            vFilterText = vButton.childNodes[i].getAttribute('filter').toUpperCase();
                            if (vFilter == vFilterText.substr(0,vFilter.length)) {
                                vButton.childNodes[i].style.display = "";
                            } else {
                                vButton.childNodes[i].style.display = "none";
                            }
                        }
                    }
                }
            },
            pilihKatalog(index) {
                this.$emit('barcode',this.mstKatalogs[index].key);
            }
        }
    };
</script>
<style scoped>
.btn-billing {
    background-image: linear-gradient(to bottom right, #8fd3f4, #84fab0);
    padding: 3px 6px; 
    margin-top: 5px; 
    margin-left: 5px; 
    width: 135px; 
    height: 75px;
}

.btn-billing h6 {
    color:black; 
    font-size: 0.8rem;
    margin-bottom: 0.3rem;
    font-weight: 500;
    line-height: 1rem;
}

.btn-billing h1 {
    font-size: 2rem;
    margin-bottom: 0.3rem;
    font-weight: 500;
    line-height: 1.2rem;
}

</style>