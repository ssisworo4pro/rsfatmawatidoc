<template>
<div id="bodyModaltlynApotekPenjualan" class="modal-body">
    <div id="subBodyModaltlynApotekPenjualan" class="row">
        <div id="grp_itempaket" class="row col-sm-12" style="padding: 0px 25px; display: none;">

                    <button id="btnCetak1" type="button" 
                        style="width: 120px; height: 40px; margin: 1px 2px; padding : 0 10px;" 
                        onclick="onModaltlynApotekPenjualan_PaketClick('')" 
                        class="btn btn-dark">
                        Barang 1<br>10.000
                    </button>
                    <button id="btnCetak1" type="button" 
                        style="width: 120px; height: 40px; margin: 1px 2px; padding : 0 10px;" 
                        onclick="onModaltlynApotekPenjualan_PaketClick('')" 
                        class="btn btn-dark">
                        Barang 2<br>20.000
                    </button>
                    <button id="btnCetak1" type="button" 
                        style="width: 120px; height: 40px; margin: 1px 2px; padding : 0 10px;" 
                        onclick="onModaltlynApotekPenjualan_PaketClick('')" 
                        class="btn btn-dark">
                        Barang 3<br>30.000
                    </button>


            </div>
        <div class="col-sm-6">
            <div id="grp_itemtrx">
                <table class="table table-sm table-bordered table-trxs" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                    <tbody>
                        <tr>
                                <th id="ModaltlynApotekPenjualan_rekapTagihan_tarif" style="font-size: 50px; padding-right: 20px;" class="text-right">30.000</th>
                        </tr>
                    </tbody>
                </table>
                <table id="datatable-ModaltlynApotekPenjualan" class="table table-sm table-bordered table-trxs" style="margin : 0 0; padding : 0 0; border-collapse: collapse; border-spacing: 0; width: 100%; ">
                    <thead>
                        <tr>
                            <th style="width:80px">-</th>
                            <th style="width:80px">No</th>
                            <th style="width:70px;">R</th>
                            <th style="width:300px">Uraian</th>
                            <th style="width:120px; display : none;">Hsl</th>
                            <th style="width:30px; display : none;">Pkt</th>
                            <th style="width:30px; display : none;">Lock</th>
                            <th style="width:70px">Qty</th>
                            <th style="width:150px">Tarif</th>
                            <th style="width:300px;">Aturan Pakai</th>
                            <th style="width:80px">+</th>
                            <th style="width:80px">e</th>
                        </tr>
                    </thead>
                    <tbody>

                                <tr>
                                    <td>
                                        <input disabled class="form-control form-control-sm text-right" type="text" value="<%- datarinci.jnsitem %>" id="jnsitem" name="jnsitem" style="display: none;">
                                        <input disabled class="form-control form-control-sm text-right" type="text" value="<%- datarinci.stspaket %>" id="stspaket" name="stspaket" style="display: none;">
                                        <input disabled class="form-control form-control-sm text-right" type="text" value="<%- datarinci.stsqty %>" id="stsqty" name="stsqty" style="display: none;">
                                        <input disabled class="form-control form-control-sm text-right" type="text" value="<%- datarinci.stskunci %>" id="stskunci" name="stskunci" style="display: none;">
                                        <input disabled class="form-control form-control-sm text-right" type="text" value="<%- datarinci.stsedit %>" id="stsedit" name="stsedit" style="display: none;">
                                        <input disabled class="form-control form-control-sm text-right" type="text" value="<%- datarinci.stsaturanpakai %>" id="stsaturanpakai" name="stsaturanpakai" style="display: none;">
                                        <button id="btnKurang" type="button" class="btn btn-danger">-</button>
                                    </td>
                                    <td>
                                        <input disabled class="bg-primary text-white form-control text-right" type="text" value="1" id="no_urut" name="no_urut">
                                        <input disabled class="form-control form-control-sm text-right" type="text" value="" id="no_penjualan" name="no_penjualan" style="display: none;">
                                        <input disabled class="form-control form-control-sm text-right" type="text" value="" id="kd_item" name="kd_item" style="display: none;">
                                        <input disabled class="form-control form-control-sm text-right" type="text" value="" id="tgljam" name="tgljam" style="display: none;">
                                        <input disabled class="form-control form-control-sm text-right" type="text" value="" id="racikan_no" name="racikan_no" style="display: none;">
                                    </td>
                                    <td>
                                        <button class="btn btn-primary text-white text-center"
                                        width="100%"
                                        style="" 
                                        id="btnRacikan" type="button">
                                        1
                                        </button>
                                    </td>
                                    <td>
                                        <input disabled class="bg-primary text-white form-control text-left" type="text" value="obat 1" id="nm_item" name="nm_item">
                                    </td>
                                    <td style="display: none;">
                                        <input class="bg-primary text-white form-control text-right" type="text" value="0" id="nilai_hasil_periksa" name="nilai_hasil_periksa">
                                    </td>
                                    <td class="text-center" style="display: none;">
                                        <div id="checkbox_sts_paket" class="form-check">
                                            <input type="checkbox" class="form-check-input" value='<%- datarinci.sts_paket %>' name="sts_paket" id="sts_paket">
                                        </div>
                                    </td>
                                    <td class="text-center" style="display: none;">
                                        <div id="checkbox_sts_kunci" class="form-check">
                                            <input type="checkbox" class="form-check-input" value='<%- datarinci.sts_kunci %>' name="sts_kunci" id="sts_kunci">
                                        </div>
                                    </td>
                                    <td>
                                        <input disabled class="bg-primary text-white form-control text-right" type="text" value="3" id="qty" name="qty">
                                    </td>
                                    <td>
                                        <input disabled class="bg-primary text-white form-control text-right" type="text" value="10.000" id="tarif_desc" name="tarif_desc">
                                    </td>
                                    <td>
                                        <div id="grp_aturanpakai">
                                            <select id="aturanpakai-1" class="form-control form-control"  name="aturan pakai">
                                                        <option value="1">3x1 sdm</option>
                                            </select>

                                        </div>
                                    </td>
                                    <td>
                                        <button id="btnTambah" type="button" class="btn btn-primary">+</button>
                                    </td>
                                    <td>
                                        <button id="btnTambahEdit" type="button" class="btn btn-primary">+</button>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <input disabled class="form-control form-control-sm text-right" type="text" value="<%- datarinci.jnsitem %>" id="jnsitem" name="jnsitem" style="display: none;">
                                        <input disabled class="form-control form-control-sm text-right" type="text" value="<%- datarinci.stspaket %>" id="stspaket" name="stspaket" style="display: none;">
                                        <input disabled class="form-control form-control-sm text-right" type="text" value="<%- datarinci.stsqty %>" id="stsqty" name="stsqty" style="display: none;">
                                        <input disabled class="form-control form-control-sm text-right" type="text" value="<%- datarinci.stskunci %>" id="stskunci" name="stskunci" style="display: none;">
                                        <input disabled class="form-control form-control-sm text-right" type="text" value="<%- datarinci.stsedit %>" id="stsedit" name="stsedit" style="display: none;">
                                        <input disabled class="form-control form-control-sm text-right" type="text" value="<%- datarinci.stsaturanpakai %>" id="stsaturanpakai" name="stsaturanpakai" style="display: none;">
                                        <button id="btnKurang" type="button" class="btn btn-danger">-</button>
                                    </td>
                                    <td>
                                        <input disabled class="bg-primary text-white form-control text-right" type="text" value="2" id="no_urut" name="no_urut">
                                        <input disabled class="form-control form-control-sm text-right" type="text" value="" id="no_penjualan" name="no_penjualan" style="display: none;">
                                        <input disabled class="form-control form-control-sm text-right" type="text" value="" id="kd_item" name="kd_item" style="display: none;">
                                        <input disabled class="form-control form-control-sm text-right" type="text" value="" id="tgljam" name="tgljam" style="display: none;">
                                        <input disabled class="form-control form-control-sm text-right" type="text" value="" id="racikan_no" name="racikan_no" style="display: none;">
                                    </td>
                                    <td>
                                        <button class="btn btn-primary text-white text-center"
                                        width="100%"
                                        style="" 
                                        id="btnRacikan" type="button">
                                        1
                                        </button>
                                    </td>
                                    <td>
                                        <input disabled class="bg-primary text-white form-control text-left" type="text" value="obat 1" id="nm_item" name="nm_item">
                                    </td>
                                    <td style="display: none;">
                                        <input class="bg-primary text-white form-control text-right" type="text" value="0" id="nilai_hasil_periksa" name="nilai_hasil_periksa">
                                    </td>
                                    <td class="text-center" style="display: none;">
                                        <div id="checkbox_sts_paket" class="form-check">
                                            <input type="checkbox" class="form-check-input" value='<%- datarinci.sts_paket %>' name="sts_paket" id="sts_paket">
                                        </div>
                                    </td>
                                    <td class="text-center" style="display: none;">
                                        <div id="checkbox_sts_kunci" class="form-check">
                                            <input type="checkbox" class="form-check-input" value='<%- datarinci.sts_kunci %>' name="sts_kunci" id="sts_kunci">
                                        </div>
                                    </td>
                                    <td>
                                        <input disabled class="bg-primary text-white form-control text-right" type="text" value="3" id="qty" name="qty">
                                    </td>
                                    <td>
                                        <input disabled class="bg-primary text-white form-control text-right" type="text" value="10.000" id="tarif_desc" name="tarif_desc">
                                    </td>
                                    <td>
                                        <div id="grp_aturanpakai">
                                            <select id="aturanpakai-1" class="form-control form-control"  name="aturan pakai">
                                                        <option value="1">3x1 sdm</option>
                                            </select>

                                        </div>
                                    </td>
                                    <td>
                                        <button id="btnTambah" type="button" class="btn btn-primary">+</button>
                                    </td>
                                    <td>
                                        <button id="btnTambahEdit" type="button" class="btn btn-primary">+</button>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <input disabled class="form-control form-control-sm text-right" type="text" value="<%- datarinci.jnsitem %>" id="jnsitem" name="jnsitem" style="display: none;">
                                        <input disabled class="form-control form-control-sm text-right" type="text" value="<%- datarinci.stspaket %>" id="stspaket" name="stspaket" style="display: none;">
                                        <input disabled class="form-control form-control-sm text-right" type="text" value="<%- datarinci.stsqty %>" id="stsqty" name="stsqty" style="display: none;">
                                        <input disabled class="form-control form-control-sm text-right" type="text" value="<%- datarinci.stskunci %>" id="stskunci" name="stskunci" style="display: none;">
                                        <input disabled class="form-control form-control-sm text-right" type="text" value="<%- datarinci.stsedit %>" id="stsedit" name="stsedit" style="display: none;">
                                        <input disabled class="form-control form-control-sm text-right" type="text" value="<%- datarinci.stsaturanpakai %>" id="stsaturanpakai" name="stsaturanpakai" style="display: none;">
                                        <button id="btnKurang" type="button" class="btn btn-danger">-</button>
                                    </td>
                                    <td>
                                        <input disabled class="bg-primary text-white form-control text-right" type="text" value="3" id="no_urut" name="no_urut">
                                        <input disabled class="form-control form-control-sm text-right" type="text" value="" id="no_penjualan" name="no_penjualan" style="display: none;">
                                        <input disabled class="form-control form-control-sm text-right" type="text" value="" id="kd_item" name="kd_item" style="display: none;">
                                        <input disabled class="form-control form-control-sm text-right" type="text" value="" id="tgljam" name="tgljam" style="display: none;">
                                        <input disabled class="form-control form-control-sm text-right" type="text" value="" id="racikan_no" name="racikan_no" style="display: none;">
                                    </td>
                                    <td>
                                        <button class="btn btn-primary text-white text-center"
                                        width="100%"
                                        style="" 
                                        id="btnRacikan" type="button">
                                        1
                                        </button>
                                    </td>
                                    <td>
                                        <input disabled class="bg-primary text-white form-control text-left" type="text" value="obat 1" id="nm_item" name="nm_item">
                                    </td>
                                    <td style="display: none;">
                                        <input class="bg-primary text-white form-control text-right" type="text" value="0" id="nilai_hasil_periksa" name="nilai_hasil_periksa">
                                    </td>
                                    <td class="text-center" style="display: none;">
                                        <div id="checkbox_sts_paket" class="form-check">
                                            <input type="checkbox" class="form-check-input" value='<%- datarinci.sts_paket %>' name="sts_paket" id="sts_paket">
                                        </div>
                                    </td>
                                    <td class="text-center" style="display: none;">
                                        <div id="checkbox_sts_kunci" class="form-check">
                                            <input type="checkbox" class="form-check-input" value='<%- datarinci.sts_kunci %>' name="sts_kunci" id="sts_kunci">
                                        </div>
                                    </td>
                                    <td>
                                        <input disabled class="bg-primary text-white form-control text-right" type="text" value="3" id="qty" name="qty">
                                    </td>
                                    <td>
                                        <input disabled class="bg-primary text-white form-control text-right" type="text" value="10.000" id="tarif_desc" name="tarif_desc">
                                    </td>
                                    <td>
                                        <div id="grp_aturanpakai">
                                            <select id="aturanpakai-1" class="form-control form-control"  name="aturan pakai">
                                                        <option value="1">3x1 sdm</option>
                                            </select>

                                        </div>
                                    </td>
                                    <td>
                                        <button id="btnTambah" type="button" class="btn btn-primary">+</button>
                                    </td>
                                    <td>
                                        <button id="btnTambahEdit" type="button" class="btn btn-primary">+</button>
                                    </td>
                                </tr>

                    </tbody>
                </table>
                <table class="table table-sm table-bordered table-trxs" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                    <tbody>
                        <tr>
                            <td width="20%">
                                <input disabled style="height: 39px; font-size: 19px;" class="bg-dark text-white form-control text-center" type="text" value="BARCODE">
                            </td>
                            <td width="80%">
                                <input onClick="this.select();" onChange="onModaltlynApotekPenjualan_barcode(this.value);" style="height: 39px; font-size: 19px;" class="bg-dark text-white form-control text-right" type="text" value="112312341" id="sale_input_barcode" name="sale_input_barcode">
                            </td>
                        </tr>
                    </tbody>
                </table>
                <div class="row" style="padding: 0px 25px;">
                    <div class="col-sm-6 text-left" style="margin: 0px 0px; padding : 0 0px;">
                        <button id="btnBayar" type="button" onclick="onModaltlynApotekPenjualan_saleBayar()" class="btn btn-danger btn-action">
                            <h6>BAYAR</h6>
                        </button>
                        <button id="btnCetak" type="button" onclick="onModaltlynApotekPenjualan_saleCetak()" class="btn btn-success btn-action" style="display: none;">
                            <h6>CETAK</h6>
                        </button>
                    </div>
                    <div class="col-sm-6 text-right" style="margin: 0px 0px; padding : 0 0px;">
                        <button type="button" onclick="onModaltlynApotekPenjualan_saleKosongkan()" class="btn btn-danger btn-action">
                            <h6>RESET</h6>
                        </button>
                        <button type="button" onclick="onModaltlynApotekPenjualan_cari()" class="btn btn-success btn-action">
                            <h6>CARI</h6>
                        </button>
                        <button type="button" onclick="onModaltlynApotekPenjualan_saleBayar()" class="btn btn-primary btn-action" style="display: none;">
                            <h6>LEWATI</h6>
                        </button>
                    </div>
                </div>
            </div>
            <div id="grp_itemtrxracikan" style="display: none;">
                <div id="grpItemRacikanModaltlynApotekPenjualanbackx" class="row col-lg-12" style="padding: 0px 25px;">
                    <div style="height: 40px; margin: 1px 2px; padding : 0 10px;">
                        <h4>Input Bahan Racikan</h4>
                    </div>
                </div>
                <table id="datatable-ModaltlynApotekPenjualanRacikan" class="table table-sm table-bordered table-trxs" style="margin : 0 0; padding : 0 0; border-collapse: collapse; border-spacing: 0; width: 100%; ">
                    <thead>
                        <tr>
                            <th style="width:50px">-</th>
                            <th style="width:70px">No</th>
                            <th style="width:300px">Uraian</th>
                            <th style="width:70px">Qty</th>
                            <th style="width:50px">+</th>
                        </tr>
                    </thead>
                    <tbody>

                                <tr>
                                    <td>
                                        <input disabled class="form-control form-control-sm text-right" type="text" value="<%- datarinci.jnsitem %>" id="jnsitem" name="jnsitem" style="display: none;">
                                        <input disabled class="form-control form-control-sm text-right" type="text" value="<%- datarinci.stspaket %>" id="stspaket" name="stspaket" style="display: none;">
                                        <input disabled class="form-control form-control-sm text-right" type="text" value="<%- datarinci.stsqty %>" id="stsqty" name="stsqty" style="display: none;">
                                        <input disabled class="form-control form-control-sm text-right" type="text" value="<%- datarinci.stskunci %>" id="stskunci" name="stskunci" style="display: none;">
                                        <input disabled class="form-control form-control-sm text-right" type="text" value="<%- datarinci.sts_kunci %>" id="sts_kunci" name="sts_kunci" style="display: none;">
                                        <input disabled class="form-control form-control-sm text-right" type="text" value="<%- datarinci.stsedit %>" id="stsedit" name="stsedit" style="display: none;">
                                        <button id="btnKurang" type="button" class="btn btn-danger">-</button>
                                    </td>
                                    <td>
                                        <input disabled class="bg-primary text-white form-control text-right" type="text" value="<%- datarinci.no_urut %>" id="no_urut" name="no_urut">
                                        <input disabled class="form-control form-control-sm text-right" type="text" value="<%- datarinci.no_penjualan %>" id="no_penjualan" name="no_penjualan" style="display: none;">
                                        <input disabled class="form-control form-control-sm text-right" type="text" value="<%- datarinci.kd_item %>" id="kd_item" name="kd_item" style="display: none;">
                                        <input disabled class="form-control form-control-sm text-right" type="text" value="<%- datarinci.tgljam %>" id="tgljam" name="tgljam" style="display: none;">
                                        <input disabled class="form-control form-control-sm text-right" type="text" value="<%- datarinci.racikan_no %>" id="racikan_no" name="racikan_no" style="display: none;">
                                    </td>
                                    <td>
                                        <input disabled class="bg-primary text-white form-control text-left" type="text" value="-- Bahan Racikan : --" id="nm_item" name="nm_item">
                                    </td>
                                    <td>
                                        <input disabled class="bg-primary text-white form-control text-right" type="text" value="" id="qty" name="qty">
                                    </td>
                                    <td>
                                        <button style="<% if ((datarinci.stsqty == '0') || (datarinci.sts_kunci == '1') || (datarinci.stsedit == '0')) { %> display: none; <% } %>" id="btnTambah" type="button" class="btn btn-primary">+</button>
                                    </td>
                                </tr>

                    </tbody>
                </table>
                <table class="table table-sm table-bordered table-trxs" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                    <tbody>
                        <tr>
                            <td width="100%">
                                <input disabled style="height: 39px; font-size: 19px;" class="bg-dark text-white form-control text-center" type="text" value="">
                            </td>
                        </tr>
                    </tbody>
                </table>
                <div class="row col-lg-12" style="padding: 0px 25px;">
                    <div style="height: 70px; margin: 1px 2px; padding : 0 10px;">
                        <button type="button" onclick="onModaltlynApotekPenjualan_updateracikan()" class="btn btn-primary btn-action-lebar">
                            <h6>Update Racikan</h6>
                        </button>
                        <button type="button" onclick="onModaltlynApotekPenjualan_ItemClickRacikanBack()" class="btn btn-danger btn-action-lebar">
                            <h6>Batalkan Racikan</h6>
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-sm-6">
            <div id="grpItemLynModaltlynApotekPenjualanShow" style="height: 465px;">
                <div id="grpItemLynModaltlynApotekPenjualan" style="height: 465px;">
                    <table class="table table-sm table-bordered table-trxs" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                        <tbody>
                            <tr>
                                <td width="20%">
                                    <input disabled style="height: 39px; font-size: 19px;" class="bg-dark text-white form-control text-center" type="text" value="FILTER">
                                </td>
                                <td width="80%">
                                    <input onClick="this.select();" onChange="onModaltlynApotekPenjualan_filter(this.value);" style="height: 39px; font-size: 19px;" class="bg-dark text-white form-control text-right" type="text" value="" id="input_filter" name="input_filter">
                                </td>
                            </tr>
                        </tbody>
                    </table>
                    <div id="grpItemLynModaltlynApotekPenjualanButton" class="container-fluid-scroll" style="margin-left: 3px">

                                <button id="btnItem1" filter="<%- datadrop.nama %>" type="button" onclick="onModaltlynApotekPenjualan_ItemClick('')" 
                                    class="btn btn-primary btn-billing">
                                    <h1>inisial</h1>
                                    <h6>10.000<br>nama</h6>
                                </button>
                                <button id="btnItem1" filter="<%- datadrop.nama %>" type="button" onclick="onModaltlynApotekPenjualan_ItemClick('')" 
                                    class="btn btn-primary btn-billing">
                                    <h1>inisial</h1>
                                    <h6>10.000<br>nama</h6>
                                </button>
                                <button id="btnItem1" filter="<%- datadrop.nama %>" type="button" onclick="onModaltlynApotekPenjualan_ItemClick('')" 
                                    class="btn btn-primary btn-billing">
                                    <h1>inisial</h1>
                                    <h6>10.000<br>nama</h6>
                                </button>
                                <button id="btnItem1" filter="<%- datadrop.nama %>" type="button" onclick="onModaltlynApotekPenjualan_ItemClick('')" 
                                    class="btn btn-primary btn-billing">
                                    <h1>inisial</h1>
                                    <h6>10.000<br>nama</h6>
                                </button>
                                <button id="btnItem1" filter="<%- datadrop.nama %>" type="button" onclick="onModaltlynApotekPenjualan_ItemClick('')" 
                                    class="btn btn-primary btn-billing">
                                    <h1>inisial</h1>
                                    <h6>10.000<br>nama</h6>
                                </button>
                                <button id="btnItem1" filter="<%- datadrop.nama %>" type="button" onclick="onModaltlynApotekPenjualan_ItemClick('')" 
                                    class="btn btn-primary btn-billing">
                                    <h1>inisial</h1>
                                    <h6>10.000<br>nama</h6>
                                </button>
                                <button id="btnItem1" filter="<%- datadrop.nama %>" type="button" onclick="onModaltlynApotekPenjualan_ItemClick('')" 
                                    class="btn btn-primary btn-billing">
                                    <h1>inisial</h1>
                                    <h6>10.000<br>nama</h6>
                                </button>
                                <button id="btnItem1" filter="<%- datadrop.nama %>" type="button" onclick="onModaltlynApotekPenjualan_ItemClick('')" 
                                    class="btn btn-primary btn-billing">
                                    <h1>inisial</h1>
                                    <h6>10.000<br>nama</h6>
                                </button>
                                <button id="btnItem1" filter="<%- datadrop.nama %>" type="button" onclick="onModaltlynApotekPenjualan_ItemClick('')" 
                                    class="btn btn-primary btn-billing">
                                    <h1>inisial</h1>
                                    <h6>10.000<br>nama</h6>
                                </button>
                                <button id="btnItem1" filter="<%- datadrop.nama %>" type="button" onclick="onModaltlynApotekPenjualan_ItemClick('')" 
                                    class="btn btn-primary btn-billing">
                                    <h1>inisial</h1>
                                    <h6>10.000<br>nama</h6>
                                </button>
                                <button id="btnItem1" filter="<%- datadrop.nama %>" type="button" onclick="onModaltlynApotekPenjualan_ItemClick('')" 
                                    class="btn btn-primary btn-billing">
                                    <h1>inisial</h1>
                                    <h6>10.000<br>nama</h6>
                                </button>
                                <button id="btnItem1" filter="<%- datadrop.nama %>" type="button" onclick="onModaltlynApotekPenjualan_ItemClick('')" 
                                    class="btn btn-primary btn-billing">
                                    <h1>inisial</h1>
                                    <h6>10.000<br>nama</h6>
                                </button>
                                <button id="btnItem1" filter="<%- datadrop.nama %>" type="button" onclick="onModaltlynApotekPenjualan_ItemClick('')" 
                                    class="btn btn-primary btn-billing">
                                    <h1>inisial</h1>
                                    <h6>10.000<br>nama</h6>
                                </button>
                                <button id="btnItem1" filter="<%- datadrop.nama %>" type="button" onclick="onModaltlynApotekPenjualan_ItemClick('')" 
                                    class="btn btn-primary btn-billing">
                                    <h1>inisial</h1>
                                    <h6>10.000<br>nama</h6>
                                </button>
                                <button id="btnItem1" filter="<%- datadrop.nama %>" type="button" onclick="onModaltlynApotekPenjualan_ItemClick('')" 
                                    class="btn btn-primary btn-billing">
                                    <h1>inisial</h1>
                                    <h6>10.000<br>nama</h6>
                                </button>
                                <button id="btnItem1" filter="<%- datadrop.nama %>" type="button" onclick="onModaltlynApotekPenjualan_ItemClick('')" 
                                    class="btn btn-primary btn-billing">
                                    <h1>inisial</h1>
                                    <h6>10.000<br>nama</h6>
                                </button>
                                <button id="btnItem1" filter="<%- datadrop.nama %>" type="button" onclick="onModaltlynApotekPenjualan_ItemClick('')" 
                                    class="btn btn-primary btn-billing">
                                    <h1>inisial</h1>
                                    <h6>10.000<br>nama</h6>
                                </button>

                    </div>
                </div>
                <div id="grpItemRacikanModaltlynApotekPenjualan" style="height: 465px; display : none;">
                    <table class="table table-sm table-bordered table-trxs form-group row" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                        <tbody>
                            <tr>
                                <td width="20%">
                                    <input disabled style="height: 39px; font-size: 19px;" class="bg-dark text-white form-control text-center" type="text" value="FILTER">
                                </td>
                                <td width="80%">
                                    <input onClick="this.select();" onChange="onModaltlynApotekPenjualan_filter(this.value);" style="height: 39px; font-size: 19px;" class="bg-dark text-white form-control text-right" type="text" value="" id="input_filter_racikan" name="input_filter_racikan">
                                </td>
                            </tr>
                        </tbody>
                    </table>
                    <div id="grpItemRacikanModaltlynApotekPenjualanButton" class="container-fluid-scroll" style="margin-left: 3px">

                                <button id="btnBahan<%- datadrop.key %>" 
                                    filter="<%- datadrop.nama %>" 
                                    type="button" 
                                    onclick="onModaltlynApotekPenjualan_ItemClickBahan('')" 
                                    class="btn-warning btn-billing">
                                    <h1>inisial</h1>
                                    <h6>nama</h6>
                                </button>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="modal-footer">
    <div class="col-9">
        <div id="modalTrxsRespErrorMessage" style="display: none;">
            <b>
                <div id="modalTrxsRespErrorMessageText" class="card-body">
                    Error Message ... 
                </div>
            </b>
        </div>
    </div>
</div>
</template>
<script>
/*
    var lEditMode               = false;
    var lSisipBaris0UntukTambah = false;
    
    var iHeightTableRack        = 765;
    var iHeightTableTrxs        = 810;
    var iHeightTableButton      = 700;
    var iHeightBody             = 730;
    if (giModals) {
        //iHeightStandarR      = 307;
        iHeightTableRack       = 515;
        iHeightTableTrxs       = 615;
    }
    var iHeightStandarBody      = 640;
    var iHeightStandarTable     = 980;
    if (giModals) { iHeightStandarTable = 500; }
    var iHeightStandarButton    = iHeightStandarTable + 65;

    var aRowEditRacikan         = 0;
    var aModaltlynApotekPenjualan       = 'ModaltlynApotekPenjualan';
    var gStspaketbilling        = '<%- dataDrop.itempaket[0].stspaketbilling %>';
    <% if(dataDrop.itemracikan != null) { %>
        var iItemRacikan            = JSON.parse('<%- JSON.stringify(dataDrop.itemracikan) %>');
    <% } else { %>
        var iItemRacikan      = [{}];
    <% } %>
    <% if(dataDrop.masteraturanpakai != null) { %>
        var iMasterAturanpakai  = JSON.parse('<%- JSON.stringify(dataDrop.masteraturanpakai) %>');
    <% } else { %>
        var iMasterAturanpakai  = [{}];
    <% } %>
    <% if(dataDrop.itempaket != null) { %>
        var iItemPaket              = JSON.parse('<%- JSON.stringify(dataDrop.itempaket) %>');
    <% } else { %>
        var iItemPaket      = [{}];
    <% } %>
    <% if(dataDrop.itempelayanan != null) { %>
        var iItemPelayanan          = JSON.parse('<%- JSON.stringify(dataDrop.itempelayanan) %>');
    <% } else { %>
        var iItemPelayanan      = [{}];
    <% } %>

    if (giModals) { 
        onModaltlynApotekPenjualan_init(); 
        onModaltlynApotekPenjualan_inittable();
    }

    function onCallbackDismiss() {
        ModuleOnTrxRespNormal(false);
        onModaltlynApotekPenjualan_focus();
    }

    function onModaltlynApotekPenjualan_buttonInit() {
        if ($('#gvControlLock').html() == '1') {
            $('#btnBayar')[0].style.display = "none";
            $('#btnCetak')[0].style.display = "";
        } else {
            $('#btnBayar')[0].style.display = "";
            $('#btnCetak')[0].style.display = "none";
        }
    }

    function onCallback(aObj, aData, aDataNew) {
        if (aObj == 'ModalmlynKatalog') {
            // -- callback setelah terjadi update / insert barang
            // jika ID = 0, berarti insert
            if (aDataNew.id_katalog == 0) {
                // -- insert barang baru --
                // insert iItemPelayanan
                let lNewItem = {};
                lNewItem.barcode             = aDataNew.barcode;
                lNewItem.harga               = aDataNew.harga;
                lNewItem.harga2              = aDataNew.harga2;
                lNewItem.harga3              = aDataNew.harga3;
                lNewItem.harga4              = "0";
                lNewItem.hargaqty1           = "0";
                lNewItem.hargaqty2           = aDataNew.harga_qty2;
                lNewItem.hargaqty3           = aDataNew.harga_qty3;
                lNewItem.hargaqty4           = "0";
                let matches                  = aDataNew.nm_katalog.match(/\b(\w)/g);
                lNewItem.inisial             = matches.join('');
                lNewItem.inisial             = lNewItem.inisial.substr(0,3);
                lNewItem.input_qty           = "1";
                lNewItem.jnsitem             = "3";
                lNewItem.key                 = aDataNew.kd_katalog;
                lNewItem.kode                = aDataNew.kd_katalog;
                lNewItem.nama                = aDataNew.nm_katalog;
                lNewItem.stsaturanpakai      = "1";
                lNewItem.stsedit             = "1";
                lNewItem.stshsl              = "0";
                lNewItem.stskunci            = "0";
                lNewItem.stspaket            = "0";
                lNewItem.stsqty              = "1";
                lNewItem.stsqtyadd           = "1";
                lNewItem.value               = aDataNew.nm_katalog;
                iItemPelayanan.push(lNewItem);

                // insert grpItemLynModaltlynApotekPenjualanButton
                let btn = document.createElement("button");
                btn.innerHTML = "<h1>" + lNewItem.inisial + "</h1><h6>" + aDataNew.harga + "<br>" + aDataNew.nm_katalog + "</h6>";
                btn.type = "button";
                btn.name = "formBtn";
                btn.filter= aDataNew.nm_katalog;
                btn.className = "btn btn-secondary btn-billing";
                btn.id = "btnItem" + aDataNew.kd_katalog;
                btn.addEventListener("click", function () {
                    onModaltlynApotekPenjualan_ItemClick(lNewItem.key, lNewItem.value, lNewItem.harga, lNewItem.jnsitem, lNewItem.stsqty, lNewItem.stsqtyadd, lNewItem.stspaket, lNewItem.datadrop, lNewItem.stsedit, lNewItem.input_qty, lNewItem.stshsl, lNewItem.stsaturanpakai);
                });
                document.body.appendChild(btn);
                document.getElementById('grpItemLynModaltlynApotekPenjualanButton').appendChild(btn);

                // insert barang
                onModaltlynApotekPenjualan_barcode(aDataNew.barcode);
            } else {
                // -- update harga --
                // update iItemPelayanan
                let lvIndex = iItemPelayanan.findIndex(x => x.key=== JSON.parse(aData).kode); 
                if (lvIndex >= 0) {
                    iItemPelayanan[lvIndex].barcode         = aDataNew.barcode;
                    iItemPelayanan[lvIndex].harga           = aDataNew.harga; //parseInt((aDataNew.harga).trim().replaceAll('.','').replaceAll(',',''),10);
                    iItemPelayanan[lvIndex].harga2          = aDataNew.harga2; //parseInt((aDataNew.harga2).trim().replaceAll('.','').replaceAll(',',''),10);
                    iItemPelayanan[lvIndex].hargaqty2       = aDataNew.harga_qty2; //parseInt((aDataNew.harga_qty2).trim().replaceAll('.','').replaceAll(',',''),10);
                    iItemPelayanan[lvIndex].harga3          = aDataNew.harga3; //parseInt((aDataNew.harga3).trim().replaceAll('.','').replaceAll(',',''),10);
                    iItemPelayanan[lvIndex].hargaqty3       = aDataNew.harga_qty3; //parseInt((aDataNew.harga_qty3).trim().replaceAll('.','').replaceAll(',',''),10);
                    // update grpItemLynModaltlynApotekPenjualanButton

                    // refresh harga untuk aRow
                    onModaltlynApotekPenjualan_refreshTarifDesc(JSON.parse(aData).row, JSON.parse(aData).kode);
                    onModaltlynApotekPenjualan_HitungTotal();
                }
            }
        } else if (aObj == 'CaritlynResepObat') {
            ModalOnSearchs(false, 'tlynResepObat');
            $('#gvControlisKode1').html(aDataNew.key);
            //$('#gvControlLock').html(aDataNew.sts_lunas);
            onModaltlynApotekPenjualan_loadpartial();
        } else if (aObj == 'ModaltbyrCashMasuk') {
            ModuleOnTrxRespNormal80(false);
            onModaltlynApotekPenjualan_saleKosongkan()
        }
        onModaltlynApotekPenjualan_focus();
    }

    function onModaltlynApotekPenjualan_saleKosongkan() {
        $('#gvControlisKode1').html('0');
        $('#gvControlLock').html('0');
        onModaltlynApotekPenjualan_buttonInit();
        onModaltlynApotekPenjualan_reset();
        onModaltlynApotekPenjualan_focus();
    }

    function onModaltlynApotekPenjualan_cari() {
        ModalOnSearchs(true, 'tlynResepObat');
        //ModuleOnSearch(true, 'cariTlynResepObat', 'htmlKriteria', 'htmlTabledata' );
    }

    function onModaltlynApotekPenjualan_mlynKatalog(aRow = 0, aKdItem = '') {
        var     vParameter;
        var     myjsonarray     = [];

        myjsonarray.push({kd_item : aKdItem });
        vParameter = '&data=' + JSON.stringify(myjsonarray);
        vParameter = vParameter + '&pagetitleurl=' + 'mlynKatalog';
        callAjaxModals(vParameter, function( res ) {
            ModuleOnTrxRespNormal(true);
            $('#modalonTrxsRespNormal').html(res);
            $('#ivModalParams1').html(JSON.stringify({row : aRow, kode : aKdItem}));
        });
    }

    function onModaltlynApotekPenjualan_saleBayar() {
        var     vParameter;
        var     vNoPenjualan;

        let vDataResep = onModaltlynApotekPenjualan_getrowData();
        if (vDataResep[0].no_urut) {
            // simpan
            $(document).find('#modalTrxsRespErrorMessage')[0].style = "display: none;";
            vParameter = '&data=' + JSON.stringify(onModaltlynApotekPenjualan_getrowData('',true));
            vParameter = vParameter + '&pagetitleurl=' + 'tlynapotekpenjualan.save';
            //ModalOnProgress(true);
            callAjaxCrud(vParameter, function( aResult ) {
                //ModalOnProgress(false);
                const res = JSON.parse(aResult);
                if (parseInt(res.errstat, 10) == 0) {
                    vNoPenjualan = res.data[0].no_penjualan;
                    $('#gvControlisKode1').html(vNoPenjualan);
                    onModaltlynApotekPenjualan_loadpartial(true);
                } else {
                    //ModalOnProgress(false);
                    if (giModals) {
                        $(document).find('#modalTrxsRespErrorMessage')[0].style = "";
                        $(document).find('#modalTrxsRespErrorMessageText').html(JSON.stringify(res.errmsg));
                    } else {
                        $(document).find('#errorMessage')[0].style = "";
                        $(document).find('#errorMessageText').html(JSON.stringify(res.errmsg));
                    }
                }
            });
        } else {
            onModaltlynApotekPenjualan_focus();
        }
    }

    function onModaltlynApotekPenjualan_saleBayarCB() {
        var     vParameter;
        var     myjsonarray     = [];
        myjsonarray.push({no_penjualan : $('#gvControlisKode1').html() });
        vParameter = '&data=' + JSON.stringify(myjsonarray);
        vParameter = vParameter + '&pagetitleurl=' + 'tbyrCashMasuk';

        ModalOnProgress(true);
        callAjaxModals(vParameter, function( res ) {
            //$('#modalonTrxsRespNormal80').html(res);
            setInnerHTML($('#' + "modalonTrxsRespNormal80")[0],res);
            ModuleOnTrxRespNormal80(true);
            ModalOnProgress(false);
        });
    }

    function onModaltlynApotekPenjualan_saleCetak() {
        var     vParameter;
        var     myjsonarray     = [];

        myjsonarray.push({no_penjualan : $('#gvControlisKode1').html() });
        vParameter = '&data=' + JSON.stringify(myjsonarray);
        vParameter = vParameter + '&pagetitleurl=' + 'tbyrCashMasuk';

        callAjaxModals(vParameter, function( res ) {
            ModuleOnTrxRespNormal80(true);
            $('#modalonTrxsRespNormal80').html(res);
        });
    }

    function onModaltlynApotekPenjualan_barcode(aBarcode) {
        if ($('#gvControlLock').html() != '1') {
            var vItemPelayanan = find_in_object(iItemPelayanan, {barcode : aBarcode});
            if (vItemPelayanan.length > 0) {
                var vItem = vItemPelayanan[0];
                onModaltlynApotekPenjualan_ItemClick(vItem.key,vItem.value,vItem.harga,vItem.jnsitem,vItem.stsqty,vItem.stsqtyadd,vItem.stspaket,vItem.stskunci,vItem.stsedit,vItem.input_qty,vItem.stshsl,vItem.stsaturanpakai);
                document.getElementById("sale_input_barcode").value = "";
            } else {
                onModaltlynApotekPenjualan_mlynKatalog(0, aBarcode);
            }
        }
        onModaltlynApotekPenjualan_focus();
    }

    function onModaltlynApotekPenjualan_filter(aFilter) {
        var vFilter = aFilter.toUpperCase();
        var vFilterText;
        var vFilterLength = vFilter.length;
        var vButton;
        if (isEditRacikan()) {
            vButton = document.getElementById("grpItemRacikanModaltlynApotekPenjualanButton");
        } else {
            vButton = document.getElementById("grpItemLynModaltlynApotekPenjualanButton");
        }

        for (var i = 0; i < vButton.childNodes.length; i++) {
            if (vButton.childNodes[i].tagName == 'BUTTON') {
                if (vFilter.length == 0) {
                    // show all
                    vButton.childNodes[i].style.display = "";
                } else {
                    vFilterText = vButton.childNodes[i].getAttribute('filter').toUpperCase();
                    if (vFilter == vFilterText.substr(0,vFilter.length)) {
                        vButton.childNodes[i].style.display = "";
                    } else {
                        vButton.childNodes[i].style.display = "none";
                    }
                }
            }
        }
    }

    function onModaltlynApotekPenjualan_filterReset() {
        // do nothing
        //onModaltlynApotekPenjualan_filter('');
        //$(document).find('#input_filter')[0].value = "";
    }
    

    function onModaltlynApotekPenjualan_loadpartial(aCallBackSaleBayar = false) {
        var     vData = [];
        var     vParameter;
        var     vDeleteReason;
        $(document).find('#errorMessage')[0].style = "display: none;";
        $(document).find('#modalTrxsRespErrorMessage')[0].style = "display: none;";
        vData.push({ no_penjualan : $('#gvControlisKode1').html() });
        vParameter = '&data=' + JSON.stringify(vData);
        vParameter = vParameter + '&pagetitleurl=' + 'tlynapotekpenjualan';

        ModalOnProgress(true);
        callAjaxLoads(vParameter, function( aResult ) {
            const res = JSON.parse(aResult);
            if (parseInt(res.errstat, 10) == 0) {
                onModaltlynApotekPenjualan_load(res.datarinci);
                ModalOnProgress(false);
                if (aCallBackSaleBayar) { onModaltlynApotekPenjualan_saleBayarCB(); }
            } else {
                ModalOnProgress(false);
                $(document).find('#errorMessage')[0].style = "";
                $(document).find('#errorMessageText').html(JSON.stringify(res.errmsg));
            }
        });
    }

    function onModaltlynApotekPenjualan_load(aDataLoad) {
        $(document).find('#modalTrxsRespErrorMessage')[0].style = "display: none;";
        onModaltlynApotekPenjualan_reset();
        if (aDataLoad.rincian_tagihan.length > 0) {
            $('#gvControlLock').html(aDataLoad.rincian_tagihan[0].sts_lunas);
        } else {
            $('#gvControlLock').html('0');
        }
        onModaltlynApotekPenjualan_buttonInit();
        for(var i = 0; i < aDataLoad.rincian_tagihan.length; i++) {
            onModaltlynApotekPenjualan_tambah(aDataLoad.rincian_tagihan[i],'',0,true);
        }
    }

    function onModaltlynApotekPenjualan_init() {
        //document.getElementById("bodyModaltlynApotekPenjualan").style.height = (parseInt(gvHeightOfRincian,10) + (iHeightStandarBody - iHeightBody)) + "px";
        //document.getElementById("subBodyModaltlynApotekPenjualan").style.height = (parseInt(gvHeightOfRincian,10) + (iHeightStandarBody - iHeightBody)) + "px";
        //document.getElementById("grpItemLynModaltlynApotekPenjualanShow").style.height = (parseInt(gvHeightOfRincian,10) + (iHeightStandarButton - iHeightTableTrxs)) + "px";
        //document.getElementById("grpItemLynModaltlynApotekPenjualan").style.height = (parseInt(gvHeightOfRincian,10) + (iHeightStandarButton - iHeightTableButton)) + "px";
        document.getElementById("grpItemLynModaltlynApotekPenjualanButton").style.height = (parseInt(gvHeightOfRincian,10) + (iHeightStandarButton - iHeightTableButton)) + "px";
        document.getElementById("grpItemRacikanModaltlynApotekPenjualanButton").style.height = (parseInt(gvHeightOfRincian,10) + (iHeightStandarButton - iHeightTableButton)) + "px";
        //document.getElementById("grpItemRacikanModaltlynApotekPenjualan").style.height = (parseInt(gvHeightOfRincian,10) + (iHeightStandarButton - iHeightTableButton)) + "px";
        //lEditMode = !((!(giModals)) && (($('#gvControlEditMode').html() == '0')));
        lEditMode = true;
        onModaltlynApotekPenjualan_ItemClickRacikanBack();
        onModaltlynApotekPenjualan_inittable();
        onModaltlynApotekPenjualan_focus();
    }

    function onModaltlynApotekPenjualan_focus() {
        document.getElementById("sale_input_barcode").focus();
        document.getElementById("sale_input_barcode").click();
    }

    function onModaltlynApotekPenjualan_inittable() {
        datatablemodule('datatable-' + aModaltlynApotekPenjualan, (parseInt(gvHeightOfRincian,10) + (iHeightStandarTable - iHeightTableTrxs )));
        //onModaltlynApotekPenjualan_ItemClickRacikan(0);
        //datatablemodule('datatable-' + aModaltlynApotekPenjualan + 'Racikan', (parseInt(gvHeightOfRincian,10) + (iHeightStandarTable - iHeightStandarR)));
        onModaltlynApotekPenjualan_ItemClickRacikanBack();
    }

    function onModaltlynApotekPenjualan_reset(aRacikan = '') {
        var root = document.getElementById('datatable-' + aModaltlynApotekPenjualan + aRacikan).getElementsByTagName('tbody')[0];
        if ($(document).find('#datatable-' + aModaltlynApotekPenjualan + aRacikan).DataTable().data().count() >= 1) {
            var mytbl = document.getElementById('datatable-' + aModaltlynApotekPenjualan + aRacikan);
            mytbl.getElementsByTagName("tbody")[0].innerHTML = ''; 
            $(document).find('#datatable-' + aModaltlynApotekPenjualan + aRacikan).empty();
        }
        $(document).find('#datatable-' + aModaltlynApotekPenjualan + aRacikan).DataTable().destroy();
        if (aRacikan == '') {
            datatablemodule('datatable-' + aModaltlynApotekPenjualan + aRacikan, (parseInt(gvHeightOfRincian,10) + (iHeightStandarTable - iHeightTableTrxs)));
            onModaltlynApotekPenjualan_HitungTotal();
        } else {
            datatablemodule('datatable-' + aModaltlynApotekPenjualan + aRacikan, (parseInt(gvHeightOfRincian,10) + (iHeightStandarTable - iHeightTableRack)));
        }
    }

    <% if(dataRinci.rincian_tagihan != null) { %>
        <% dataRinci.rincian_tagihan.forEach(function(datarinci, index) { %>
            <% if(parseInt(datarinci.no_urut,10) > 2) { %>
    onModaltlynApotekPenjualan_SetListener(parseInt(<%- datarinci.no_urut %>,10) - 1, <%- JSON.stringify(dataRinci.rincian_tagihan[index]) %>);
            <% } %>
        <% }) %>
    <% } %>

    function onModaltlynApotekPenjualan_PaketClick(aKdPaket, aNmPaket, aHargaDesc) {
        var root = document.getElementById('datatable-' + aModaltlynApotekPenjualan).getElementsByTagName('tbody')[0];
        var rows = root.getElementsByTagName('tr');
        var row = rows[0];
        var vQty = 0;
        var vTarifDesc;
        var vTarifUnit = 0;
        const cKdPaket = aKdPaket;
        for (var j = 0; m = row.childNodes[j]; ++j) {
            for (var i = 0; n = m.childNodes[i]; ++i) {
                if (n.tagName == 'INPUT' && n.type == 'text') {
                    if (n.id == 'qty') {
                        n.value = 1;
                    } else if (n.id == 'nm_item') {
                        n.value = aNmPaket;
                    } else if (n.id == 'kd_item') {
                        n.value = cKdPaket;
                    } else if (n.id == 'tarif_desc') {
                        vTarifDesc = aHargaDesc.trim();
                        vTarifDesc = vTarifDesc.replaceAll('.','');
                        vTarifDesc = vTarifDesc.replaceAll(',','');
                        n.value = fmathNumberWithCommas(vTarifDesc);
                    }
                }
            }
        } 
        onModaltlynApotekPenjualan_UpdateStsPaket(cKdPaket);
        onModaltlynApotekPenjualan_HitungTotal();
    }

    function onModaltlynApotekPenjualan_refreshTarifDesc(aRow, aKdItem) {
        var root = document.getElementById('datatable-' + aModaltlynApotekPenjualan).getElementsByTagName('tbody')[0];
        var rows = root.getElementsByTagName('tr');
        var row = rows[aRow];
        var vTarifDesc;
        var vQty;
        for (var j = 0; m = row.childNodes[j]; ++j) {
            for (var i = 0; n = m.childNodes[i]; ++i) {
                if (n.tagName == 'INPUT' && n.type == 'text') {
                    if (n.id == 'qty') {
                        vQty = n.value;
                        let vTarifUnit = onModaltlynApotekPenjualan_GetTarifItem(aRow, vQty, aKdItem);
                        vTarifDesc = vTarifUnit * vQty;
                    } else if (n.id == 'tarif_desc') {
                        //vTarifDesc = vTarifDesc.trim();
                        //vTarifDesc = vTarifDesc.replaceAll('.','');
                        //vTarifDesc = vTarifDesc.replaceAll(',','');
                        n.value = fmathNumberWithCommas(vTarifDesc);
                    }
                }
            }
        } 
    }

    function onModaltlynApotekPenjualan_UpdateStsPaket(aKdPaket) {
        var root = document.getElementById('datatable-' + aModaltlynApotekPenjualan).getElementsByTagName('tbody')[0];
        var rows = root.getElementsByTagName('tr');
        var row = rows[0];
        var vRowCounter = 1;
        var vRowCounted = rows.length;
        var vStspaket = '0';
        var vItemPaket = find_in_object(iItemPaket, {key : aKdPaket});
        var vJnsitem = '0';
        var vNoUrut = '0';

        if (vRowCounted > (vRowCounter + 1)) {
            while (vRowCounter < (vRowCounted - 1)){
                vRowCounter = vRowCounter + 1;
                row = rows[vRowCounter];
                for (var j = 0; m = row.childNodes[j]; ++j) {
                    for (var i = 0; n = m.childNodes[i]; ++i) {
                        if (n.tagName == 'INPUT' && n.type == 'text') {
                            if (n.id == 'sts_paket') {
                                if (parseInt(vItemPaket[0].include_obat,10) == 0) {
                                //if (parseInt(aKdPaket,10) == 0) {
                                    n.value = '0';
                                } else {
                                    n.value = ((vStspaket == '1') ? '1' : '0');
                                }
                            } else if (n.id == 'jnsitem') {
                                vJnsitem = n.value;
                            } else if (n.id == 'no_urut') {
                                vNoUrut = n.value;
                            } else if (n.id == 'stspaket') {
                                vStspaket = n.value;
                            } else if (n.id == 'tarif_desc') {
                                //if ((parseInt(aKdPaket,10) != 0) && (vStspaket == '1')) {
                                if ((parseInt(vItemPaket[0].include_obat,10) == 1) && (vStspaket == '1')) {
                                    n.style = "display: none;";
                                } else {
                                    if ((vJnsitem == '7') || (vJnsitem == '8')) {
                                        n.style = "display: none;";
                                    } else {
                                        n.style = "";
                                    }
                                }
                            }
                        } else if (n.tagName == 'DIV') {
                            if (n.id == 'checkbox_sts_paket') {
                                if (n.childNodes[0]) {
                                    for (var k = 0; l = n.childNodes[k]; ++k) {
                                        if (l.tagName == 'INPUT' && l.type == 'checkbox') {
                                            if (parseInt(vItemPaket[0].include_obat,10) == 0) {
                                            //if (parseInt(aKdPaket,10) == 0) {
                                                l.value = '0';
                                                l.checked = false;
                                            } else {
                                                l.value = vStspaket;
                                                l.checked = vStspaket == '1';
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }  
            }
        }
    }

    function onModaltlynApotekPenjualan_UpdateEfekHapusTengah(aRow, aBahanRacikan = '') {
        var root = document.getElementById('datatable-' + aModaltlynApotekPenjualan + aBahanRacikan).getElementsByTagName('tbody')[0];
        var rows = root.getElementsByTagName('tr');
        var vRowCounter = aRow - 1;
        var vRowCounted = rows.length;
        var aData = onModaltlynApotekPenjualan_getrowData(aBahanRacikan, true);
        if (vRowCounted > (vRowCounter + 1)) {
            while (vRowCounter < (vRowCounted - 1)){
                vRowCounter = vRowCounter + 1;
                onModaltlynApotekPenjualan_SetListener(vRowCounter, aData[vRowCounter], aBahanRacikan);
            }
        }
    }

    function onModaltlynApotekPenjualan_getrowData(aBahanRacikan = '', aSimpan = false) {
        var     myjsonarray     = [];
        var     myjson          = {};
        var     vTableColumn;
        var     inputdata;

        $(document).find('#datatable-' + aModaltlynApotekPenjualan + aBahanRacikan).find('tbody').find('tr').each(function() {
            vTableColumn    = $(this).find('td');
            myjson          = {};
            for(var j = 0; j < vTableColumn.length; j++) {
                inputdata = vTableColumn[j].getElementsByTagName('input');
                for(var i = 0; i < inputdata.length; i++) {
                    if (inputdata[i].name) {
                        if ( inputdata[i].type == 'checkbox') {
                            if (inputdata[i].checked) {
                                myjson[inputdata[i].name] = '1';
                            } else {
                                myjson[inputdata[i].name] = '0';
                            }
                        //} else if (inputdata[i].name == 'no_penjualan') {
                          //  if ($('#gvControlisKode1').html() == '0') {
                           //     myjson[inputdata[i].name] = inputdata[i].value;
                           // } else {
                            //    myjson[inputdata[i].name] = $('#gvControlisKode1').html();
                           // }
                        } else {
                            myjson[inputdata[i].name] = inputdata[i].value;
                        }
                    }
                }
            }
            if (aSimpan) {
                if ( myjson['stsaturanpakai'] == '1') {
                    myjson['aturanpakai'] = $('#aturanpakai-' + myjson['no_urut']).select2('val');
                } else {
                    myjson['aturanpakai'] = [];
                }
            }
            myjsonarray.push(myjson);
        });
        return myjsonarray;
    }

    function onModaltlynApotekPenjualan_updateracikan() {
        var root = document.getElementById('datatable-' + aModaltlynApotekPenjualan).getElementsByTagName('tbody')[0];
        var rows = root.getElementsByTagName('tr');
        var vDataJsonGet    = [];
        var vDataJsonSend   = [];
        vDataJsonGet        = onModaltlynApotekPenjualan_getrowData('Racikan');
        for (var i = 0; i < vDataJsonGet.length; i++) {
            vDataJsonGet[i].jnsitem = 7;
            vDataJsonSend.push(vDataJsonGet[i]);
        }

        var vContDelete = true;
        var row;
        var aRow = aRowEditRacikan + 1;
        do {
            if (root.getElementsByTagName('tr').length > aRow) {
                vJnsitem = onModaltlynApotekPenjualan_GetCurrentJnsItem(aRow);
                if ((vJnsitem == 7) || (vJnsitem == 8)) {
                    row = root.getElementsByTagName('tr')[aRow];
                    row.remove();
                    onModaltlynApotekPenjualan_UpdateEfekHapusTengah(aRow);
                } else { vContDelete = false; }
            } else { vContDelete = false; }
        } while (vContDelete)

        if ( rows.length == aRowEditRacikan + 1) { aRowEditRacikan = 0; }
        onModaltlynApotekPenjualan_TambahItemRacikan(vDataJsonSend, aRowEditRacikan);
        onModaltlynApotekPenjualan_ItemClickRacikanBack();
    }

    function onModaltlynApotekPenjualan_UpdateTotal(aData) {
        var vTarif  = $('#ModaltlynApotekPenjualan_rekapTagihan_tarif').html();
        vTarif      = vTarif.trim();
        vTarif      = vTarif.replaceAll('.','');
        vTarif      = vTarif.replaceAll(',','');
        if (aData.tarifori == 0) {
            vTarif      = parseInt(vTarif,10) + parseInt(aData.tarif,10);
        } else {
            vTarif      = parseInt(vTarif,10) - (parseInt(aData.tarifori,10) * parseInt(aData.qtyori,10));
            vTarif      = vTarif + (parseInt(aData.tarif,10) * parseInt(aData.qty,10));
        }
        $('#ModaltlynApotekPenjualan_rekapTagihan_tarif').html(fmathNumberWithCommas(vTarif));
    }

    function onModaltlynApotekPenjualan_HitungTotal() {
        var root = document.getElementById('datatable-' + aModaltlynApotekPenjualan).getElementsByTagName('tbody')[0];
        var rows = root.getElementsByTagName('tr');
        var vKdPaket = onModaltlynApotekPenjualan_GetCurrentPaket();
        var vRowCounter = 0;
        var vRowCounted = rows.length;
        var vTotalTarif = 0;

        while (vRowCounter < vRowCounted) {
            vTotalTarif = vTotalTarif + onModaltlynApotekPenjualan_GetTarif(vKdPaket, vRowCounter);
            vRowCounter = vRowCounter + 1;
        }
        $('#ModaltlynApotekPenjualan_rekapTagihan_tarif').html(fmathNumberWithCommas(vTotalTarif));
    } 

    function onModaltlynApotekPenjualan_SetRowFocus(aRow, aBahanRacikan = '') {
        var root = document.getElementById('datatable-' + aModaltlynApotekPenjualan + aBahanRacikan).getElementsByTagName('tbody')[0];
        var rows = root.getElementsByTagName('tr');
        var row = rows[aRow];
        row.addEventListener("click", function () { 
            $(this).addClass('selected').siblings().removeClass('selected');
            $(this).focus();
            onModaltlynApotekPenjualan_focus();
            root.scrollBy({ 
                top: root.offsetHeight,
                behavior: 'smooth' 
            });
            $('datatable-' + aModaltlynApotekPenjualan + aBahanRacikan).DataTable({
                drawCallback : function () {
                    var api = this.api();
                    api.row(aRow).scrollTo();
                }
            });
        });
        row.click();
    }

    function onModaltlynApotekPenjualan_SetListener(aRow, aData, aBahanRacikan = '') {
        var root = document.getElementById('datatable-' + aModaltlynApotekPenjualan + aBahanRacikan).getElementsByTagName('tbody')[0];
        var rows = root.getElementsByTagName('tr');
        var row = rows[aRow];
        var elclone;
        var vStsqty = '0';
        var vStskunci = '0';
        var vStsedit = '0';

        onModaltlynApotekPenjualan_SetRowFocus(aRow, aBahanRacikan);
        for (var j = 0; m = row.childNodes[j]; j++) {
            if (m.hasChildNodes()) {
                for (var i = 0; n = m.childNodes[i]; i++) {
                    if (n.tagName == 'INPUT' && n.type == 'text') {
                        if (n.id == 'no_urut') {
                            aData.no_urut = aRow + 1;
                            n.value = aRow + 1;
                            if ((aData.jnsitem == '7') || (aData.jnsitem == '8')) {
                                n.style = "display: none;";
                            } else {
                                n.style = "";
                            }
                        } else if (n.id == 'stsqty') {
                            vStsqty = n.value;
                        } else if (n.id == 'stsedit') {
                            vStsedit = n.value;
                        } else if (n.id == 'stskunci') {
                            vStskunci = n.value;
                        } else if (n.id == 'tarif_desc') {
                            if ((aData.jnsitem == '7') || (aData.jnsitem == '8')) {
                                n.style = "display: none;";
                            } else {
                                n.style = "";
                            }
                        } else if (n.id == 'nilai_hasil_periksa') {
                            if ((aData.jnsitem == '7') || (aData.jnsitem == '8')) {
                                n.style = "display: none;";
                            }
                        }
                    } else if (n.tagName == 'BUTTON') {
                        if (n.id == 'btnTambah') {
                            if ((vStsqty == "1") && (vStsedit == "1") && (aData.sts_kunci == '0')) {
                                elclone = n.cloneNode(true);
                                elclone.addEventListener("click", function () {
                                    onModaltlynApotekPenjualan_ItemClickTambah(aRow, aBahanRacikan);
                                });
                                elclone.style = "";
                                n.parentNode.replaceChild(elclone, n);
                            } else {
                                n.style = "display: none;";
                            }
                        } else if (n.id == 'btnTambahEdit') {
                            if ((vStsedit == "1") && (aData.sts_kunci == '0')) {
                                elclone = n.cloneNode(true);
                                elclone.addEventListener("click", function () { 
                                    onModaltlynApotekPenjualan_ItemClickTambahEdit(aRow, aData.kd_item);
                                });
                                elclone.style = "";
                                n.parentNode.replaceChild(elclone, n);
                            } else {
                                n.style = "display: none;";
                            }
                        } else if (n.id == 'btnKurang') {
                            if ((vStsedit == "1") && (aData.sts_kunci == '0')) {
                                elclone = n.cloneNode(true);
                                elclone.addEventListener("click", function () { 
                                    onModaltlynApotekPenjualan_ItemClickKurang(aRow, aBahanRacikan);
                                });
                                elclone.style = "";
                                n.parentNode.replaceChild(elclone, n);
                            } else {
                                n.style = "display: none;";
                            }
                        } else if (n.id == 'btnRacikan') {
                            if (aData.jnsitem == '5') {
                                n.style = "";
                                n.textContent = "Ra";
                                elclone = n.cloneNode(true);
                                elclone.addEventListener("click", function () { 
                                    onModaltlynApotekPenjualan_ItemClickRacikan(aRow);
                                });
                                elclone.style = "";
                                n.parentNode.replaceChild(elclone, n);
                            } else if (aData.jnsitem == '6') {
                                n.style = "";
                                n.textContent = "Rs";
                            } else if ((aData.jnsitem == '7') || (aData.jnsitem == '8')) {
                                n.style = "display: none;";
                                n.textContent = "Rs";
                            } else {
                                n.style = "display: none;";
                            }
                        }
                    } else if (n.tagName == 'DIV') {
                        if (n.id == 'checkbox_sts_paket') {
                            if (n.childNodes[0]) {
                                for (var k = 0; l = n.childNodes[k]; ++k) {
                                    if (l.tagName == 'INPUT' && l.type == 'checkbox') {
                                        if (l.id == 'sts_paket') {
                                            elclone = l.cloneNode(true);
                                            elclone.addEventListener("click", function () {
                                                onModaltlynApotekPenjualan_CheckboxStsPaket(aRow, this.checked);
                                            });
                                            elclone.style = "";
                                            elclone.disabled = (gStspaketbilling == '0')
                                            if ((aData.jnsitem == '7') || (aData.jnsitem == '8')) {
                                                elclone.style = "display : none;";
                                            }
                                            l.parentNode.replaceChild(elclone, l);
                                        }
                                    }
                                }
                            }
                        } else if (n.id == 'checkbox_sts_kunci') {
                            if (n.childNodes[0]) {
                                for (var k = 0; l = n.childNodes[k]; ++k) {
                                    if (l.tagName == 'INPUT' && l.type == 'checkbox') {
                                        if (l.id == 'sts_kunci') {
                                            if ((aData.jnsitem == '7') || (aData.jnsitem == '8')) {
                                                l.style = "display: none;";
                                            } else {
                                                l.style = "";
                                            }
                                        }
                                    }
                                }
                            }
                        } else if (n.id == 'grp_aturanpakai') {
                            for (var k = 0; x = n.childNodes[k]; k++) {
                                if (n.childNodes[k].tagName == 'SELECT') {
                                    var elclone = n.childNodes[k].cloneNode(true);
                                    elclone.id = 'aturanpakai-' + aData.no_urut;
                                    while (n.hasChildNodes()) {
                                        n.removeChild(n.firstChild);
                                    }
                                    n.appendChild(elclone);
                                    $('#' + elclone.id).select2();
                                    $('#' + elclone.id).val(aData.aturanpakai).trigger('change');
                                    if (aData.stsaturanpakai == '0') {
                                        n.style = "display : none;";
                                    } else {
                                        n.style = "";
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }  
    }

    function find_in_object(my_object, my_criteria){
        return my_object.filter(function(obj) {
            return Object.keys(my_criteria).every(function(c) {
                return obj[c] == my_criteria[c];
            });
        });
    }

    function onModaltlynApotekPenjualan_ItemClickBahan(aKey, aValue, aHarga, aJnsitem, aStsqty, aStsqtyadd, aStspaket, aStskunci, aStsedit, aInputQty) {
        var vDataLoad = {};
        var vCek = 0;

        if (aStsqtyadd == '1') { vCek = onModaltlynApotekPenjualan_ItemClickCek(aKey, aJnsitem, 'Racikan'); }
        if (vCek == 0) {
            vDataLoad.nm_item = aValue;
            vDataLoad.no_urut = '1';
            vDataLoad.kd_item = aKey;
            vDataLoad.no_penjualan = '<%- dataDtls[0].no_penjualan %>';
            if (!(giModals)) { vDataLoad.no_penjualan = $('#gvControlisKode1').html(); }
            vDataLoad.jnsitem = aJnsitem;
            vDataLoad.stsqty = '1'; //aStsqty;
            vDataLoad.stspaket = aStspaket;
            vDataLoad.stskunci = '0'; //aStskunci;
            vDataLoad.sts_kunci = '0';
            vDataLoad.stsedit = '1'; //aStsedit;
            vDataLoad.tgljam = '';
            vDataLoad.kd_paket = onModaltlynApotekPenjualan_GetCurrentPaket();
            vDataLoad.qty = parseInt(aInputQty,10);
            vDataLoad.tarif_desc = ((aHarga.trim()).replaceAll('.','')).replaceAll(',','') * vDataLoad.qty;
            vDataLoad.tarif_desc = vDataLoad.tarif_desc.toString(); 
            vDataLoad.row = 0;
            onModaltlynApotekPenjualan_tambah(vDataLoad, 'Racikan');
        } else {
            onModaltlynApotekPenjualan_ItemClickTambah(vCek - 1, 'Racikan');
        }
    }

    function onModaltlynApotekPenjualan_ItemClick(aKey, aValue, aHarga, aJnsitem, aStsqty, aStsqtyadd, aStspaket, aStskunci, aStsedit, aInputQty, aStshsl, aStsaturanpakai) {
        if ($('#gvControlLock').html() != '1') {
            var vDataLoad = {};
            var vCek = 0;

            if (aStsqtyadd == '1') { vCek = onModaltlynApotekPenjualan_ItemClickCek(aKey, aJnsitem); }
            if (vCek == 0) {
                vDataLoad.nm_item = aValue;
                vDataLoad.no_urut = '1';
                vDataLoad.kd_item = aKey;
                vDataLoad.no_penjualan = '<%- dataDtls[0].no_penjualan %>';
                if (!(giModals)) { vDataLoad.no_penjualan = $('#gvControlisKode1').html(); }
                vDataLoad.jnsitem = aJnsitem;
                vDataLoad.stsqty = aStsqty;
                vDataLoad.stspaket = aStspaket;
                vDataLoad.stskunci = aStskunci;
                vDataLoad.sts_kunci = '0';
                vDataLoad.stsedit = aStsedit;
                vDataLoad.stshsl = aStshsl;
                vDataLoad.stsaturanpakai = aStsaturanpakai;
                vDataLoad.nilai_hasil_periksa = '';
                var vMasterAturanpakai = find_in_object(iMasterAturanpakai, {kd_katalog : aKey});
                if (vMasterAturanpakai.length > 0) {
                    vDataLoad.aturanpakai = [];
                    if (vMasterAturanpakai[0].kd_aturan1 != '') { vDataLoad.aturanpakai.push(vMasterAturanpakai[0].kd_aturan1); }
                    if (vMasterAturanpakai[0].kd_aturan2 != '') { vDataLoad.aturanpakai.push(vMasterAturanpakai[0].kd_aturan2); }
                    if (vMasterAturanpakai[0].kd_aturan3 != '') { vDataLoad.aturanpakai.push(vMasterAturanpakai[0].kd_aturan3); }
                    if (vMasterAturanpakai[0].kd_aturan4 != '') { vDataLoad.aturanpakai.push(vMasterAturanpakai[0].kd_aturan4); }
                    if (vMasterAturanpakai[0].kd_aturan5 != '') { vDataLoad.aturanpakai.push(vMasterAturanpakai[0].kd_aturan5); }
                }

                vDataLoad.tgljam = '';
                vDataLoad.kd_paket = onModaltlynApotekPenjualan_GetCurrentPaket();
                vDataLoad.qty = parseInt(aInputQty,10);
                vDataLoad.tarif_desc = ((aHarga.trim()).replaceAll('.','')).replaceAll(',','') * vDataLoad.qty;
                vDataLoad.tarif_desc = vDataLoad.tarif_desc.toString(); 
                vDataLoad.row = 0;
                onModaltlynApotekPenjualan_tambah(vDataLoad);
            } else {
                onModaltlynApotekPenjualan_ItemClickTambah(vCek - 1);
            }
            if ((aJnsitem == 5) || (aJnsitem == 6)) {
                var vItemRacikan = find_in_object(iItemRacikan, {kd_katalog : aKey});
                onModaltlynApotekPenjualan_TambahItemRacikan(vItemRacikan);
            }
        }
    }

    function onModaltlynApotekPenjualan_TambahItemRacikan(aItemRacikan, aMulaiBarisKe = 0) {
        var vDataLoad = {};
        var vMulaiBarisKe = aMulaiBarisKe;
        for(let i = 0; i < aItemRacikan.length; i++) {
            vDataLoad.nm_item = aItemRacikan[i].nm_item;
            vDataLoad.no_urut = '1';
            vDataLoad.kd_item = aItemRacikan[i].kd_item;
            vDataLoad.no_penjualan = '<%- dataDtls[0].no_penjualan %>';
            if (!(giModals)) { vDataLoad.no_penjualan = $('#gvControlisKode1').html(); }
            vDataLoad.jnsitem = aItemRacikan[i].jnsitem;
            vDataLoad.stsqty = '0'; 
            vDataLoad.stspaket = '0';
            vDataLoad.stskunci = '0';
            vDataLoad.sts_kunci = '0';
            vDataLoad.stshsl = '0';
            vDataLoad.stsaturanpakai = '0';
            vDataLoad.stsedit = '0'; 
            vDataLoad.tgljam = '';
            vDataLoad.kd_paket = onModaltlynApotekPenjualan_GetCurrentPaket();
            vDataLoad.qty = parseInt(aItemRacikan[i].qty,10);
            vDataLoad.tarif_desc = '0';
            vDataLoad.row = 0;
            if (vMulaiBarisKe != 0) { vMulaiBarisKe = vMulaiBarisKe + 1; }
            onModaltlynApotekPenjualan_tambah(vDataLoad, '', vMulaiBarisKe);
        }
    }

    function onModaltlynApotekPenjualan_ItemClickCek(aKdItem, aJnsitem, aBahanRacikan = '') {
        var root = document.getElementById('datatable-' + aModaltlynApotekPenjualan + aBahanRacikan).getElementsByTagName('tbody')[0];
        var rows = root.getElementsByTagName('tr');
        var row;
        var vFounded = false;
        var vKdItem  = '';
        var vJnsitem = 0;
        var vRowCounter = 0;
        var vRowCounted = rows.length;
        aJnsitem = parseInt(aJnsitem,10);

        var vTarif  = $('#ModaltlynApotekPenjualan_rekapTagihan_tarif').html();
        vTarif      = vTarif.trim();
        vTarif      = vTarif.replaceAll('.','');
        vTarif      = vTarif.replaceAll(',','');
        if (parseInt(vTarif,10) > 0) {
            if (vRowCounted > 0) {
                while (!(vFounded) && (vRowCounter < vRowCounted)){
                    row = rows[vRowCounter];
                    for (var j = 0; m = row.childNodes[j]; ++j) {
                            for (var i = 0; n = m.childNodes[i]; ++i) {
                                if (n.tagName == 'INPUT' && n.type == 'text') {
                                    if (n.id == 'kd_item') {
                                        vKdItem = n.value;
                                        if ((vKdItem == aKdItem)) {
                                            vFounded = true;
                                        }
                                    }
                                }
                            }
                    }  
                    vRowCounter = vRowCounter + 1;
                }
            }
        }
        if (!(vFounded)) { vRowCounter = 0; }
        return vRowCounter;
    }

    function onModaltlynApotekPenjualan_GetTarifItem(aRow, aQty, aKdItem) {
        var vTarifUnit = 0;
        var vItemPelayanan = find_in_object(iItemPelayanan, {key : aKdItem});
        if (vItemPelayanan.length > 0) {
            var vItem = vItemPelayanan[0];
            vTarifUnit = (((vItem.harga).trim()).replaceAll('.','')).replaceAll(',','');
            if (parseInt(vItem.hargaqty2,10) > 0) {
                if (aQty >= parseInt(vItem.hargaqty2,10)) { 
                    vTarifUnit = (((vItem.harga2).trim()).replaceAll('.','')).replaceAll(',','');
                }
            }
            if (parseInt(vItem.hargaqty3,10) > 0) {
                if (aQty >= parseInt(vItem.hargaqty3,10)) { 
                    vTarifUnit = (((vItem.harga3).trim()).replaceAll('.','')).replaceAll(',','');
                }
            }
            if (parseInt(vItem.hargaqty4,10) > 0) {
                if (aQty >= parseInt(vItem.hargaqty4,10)) { 
                    vTarifUnit = (((vItem.harga4).trim()).replaceAll('.','')).replaceAll(',','');
                }
            }
        } else {
            console.log('Error');
            alert('error');
        }
        return vTarifUnit;
    }

    function onModaltlynApotekPenjualan_ItemClickTambahEdit(aRow, aKdItem) {
        onModaltlynApotekPenjualan_mlynKatalog(aRow, aKdItem);
    }

    function onModaltlynApotekPenjualan_ItemClickTambah(aRow, aBahanRacikan = '') {
        if ($('#gvControlLock').html() != '1') {
            if (lEditMode) {
                var root = document.getElementById('datatable-' + aModaltlynApotekPenjualan + aBahanRacikan).getElementsByTagName('tbody')[0];
                var rows = root.getElementsByTagName('tr');
                var row = rows[aRow];
                var vQty = 0;
                var vKdItem;
                var vTarifDesc;
                var vSts_paket = '0';
                for (var j = 0; m = row.childNodes[j]; ++j) {
                    for (var i = 0; n = m.childNodes[i]; ++i) {
                        if (n.tagName == 'INPUT' && n.type == 'text') {
                            if (n.id == 'qty') {
                                vQty = parseInt(n.value,10);
                                n.value = parseInt(n.value,10) + 1;
                            } else if (n.id == 'kd_item') {
                                vKdItem = n.value;
                            } else if (n.id == 'tarif_desc') {
                                vTarifDesc = (((n.value).trim()).replaceAll('.','')).replaceAll(',','');
                                
                                // vTarifUnit = vTarifDesc / vQty;
                                var vTarifUnit      = onModaltlynApotekPenjualan_GetTarifItem(aRow, vQty + 1, vKdItem);
                                var vTarifUnitOri   = onModaltlynApotekPenjualan_GetTarifItem(aRow, vQty, vKdItem);
                                vTarifDesc          = vTarifUnit * vQty;

                                n.value = fmathNumberWithCommas(parseInt(vTarifDesc,10) + parseInt(vTarifUnit,10));
                                if (vSts_paket == '0') {
                                    onModaltlynApotekPenjualan_UpdateTotal({ qty : vQty + 1, qtyori : vQty, tarifori : vTarifUnitOri, tarif : vTarifUnit });
                                } else {
                                    onModaltlynApotekPenjualan_UpdateTotal({ qty : vQty + 1, qtyori : vQty, tarifori : vTarifUnitOri, tarif : 0 });
                                }
                            }
                        } else if (n.tagName == 'DIV') {
                            if (n.id == 'checkbox_sts_paket') {
                                if (n.childNodes[0]) {
                                    for (var k = 0; l = n.childNodes[k]; ++k) {
                                        if (l.tagName == 'INPUT' && l.type == 'checkbox') {
                                            if (l.id == 'sts_paket') {
                                                if (l.checked) { vSts_paket = '1' } else { vSts_paket = '0' }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            onModaltlynApotekPenjualan_SetRowFocus(aRow, aBahanRacikan);
        }
    } 

    function onModaltlynApotekPenjualan_GetCurrentPaket() {
        var root = document.getElementById('datatable-' + aModaltlynApotekPenjualan).getElementsByTagName('tbody')[0];
        var rows = root.getElementsByTagName('tr');
        var vRowPaket = rows[0];
        var vKd_Item = '';
        for (var j = 0; m = vRowPaket.childNodes[j]; ++j) {
            for (var i = 0; n = m.childNodes[i]; ++i) {
                if (n.tagName == 'INPUT' && n.type == 'text') {
                    if (n.id == 'kd_item') {
                        vKd_Item = n.value;
                        vKd_Item = parseInt(vKd_Item,10)
                    }
                }
            }
        } 
        return vKd_Item;
    }

    function onModaltlynApotekPenjualan_GetCurrentKdItem(aRow = 0) {
        var root = document.getElementById('datatable-' + aModaltlynApotekPenjualan).getElementsByTagName('tbody')[0];
        var rows = root.getElementsByTagName('tr');
        var vRowPaket = rows[aRow];
        var vKd_Item = '';
        for (var j = 0; m = vRowPaket.childNodes[j]; ++j) {
            for (var i = 0; n = m.childNodes[i]; ++i) {
                if (n.tagName == 'INPUT' && n.type == 'text') {
                    if (n.id == 'kd_item') {
                        vKd_Item = n.value;
                        //vKd_Item = parseInt(vKd_Item,10)
                    }
                }
            }
        } 
        return vKd_Item;
    }

    function onModaltlynApotekPenjualan_GetCurrentJnsItem(aRow) {
        var root = document.getElementById('datatable-' + aModaltlynApotekPenjualan).getElementsByTagName('tbody')[0];
        var rows = root.getElementsByTagName('tr');
        var vRowPaket = rows[aRow];
        var vKd_Item = '';
        for (var j = 0; m = vRowPaket.childNodes[j]; ++j) {
            for (var i = 0; n = m.childNodes[i]; ++i) {
                if (n.tagName == 'INPUT' && n.type == 'text') {
                    if (n.id == 'jnsitem') {
                        vKd_Item = n.value;
                        vKd_Item = parseInt(vKd_Item,10)
                    }
                }
            }
        } 
        return vKd_Item;
    }

    function onModaltlynApotekPenjualan_CheckboxStsPaket(aRow, aValue) {
        var root = document.getElementById('datatable-' + aModaltlynApotekPenjualan).getElementsByTagName('tbody')[0];
        var rows = root.getElementsByTagName('tr');
        var row = rows[aRow];
        var vQty = 0;
        var vTarifDesc;
        var vTarifUnit = 0;
        var vKd_Item = onModaltlynApotekPenjualan_GetCurrentPaket();
        if (vKd_Item != 0) {
            for (var j = 0; m = row.childNodes[j]; ++j) {
                for (var i = 0; n = m.childNodes[i]; ++i) {
                    if (n.tagName == 'INPUT' && n.type == 'text') {
                        if (n.id == 'tarif_desc') {
                            if (aValue) {
                                n.style = "display: none;";
                                onModaltlynApotekPenjualan_UpdateTotal({ qty : 0, tarifori : 0, tarif :  parseInt(((n.value).replaceAll('.','')).replaceAll(',',''),10) * -1 });
                            } else {
                                n.style = "";
                                onModaltlynApotekPenjualan_UpdateTotal({ qty : 0, tarifori : 0, tarif :  parseInt(((n.value).replaceAll('.','')).replaceAll(',',''),10) });
                            }
                        }
                    }
                }
            }  
        }
    } 

    function onModaltlynApotekPenjualan_GetTarif(aKdPaket, aRow) {
        var root        = document.getElementById('datatable-' + aModaltlynApotekPenjualan).getElementsByTagName('tbody')[0];
        var rows        = root.getElementsByTagName('tr');
        var row         = rows[aRow];
        var vTarif      = 0;
        var vStsPaket   = false;
        for (var j = 0; m = row.childNodes[j]; ++j) {
            for (var i = 0; n = m.childNodes[i]; ++i) {
                if (n.tagName == 'INPUT' && n.type == 'text') {
                    if (n.id == 'tarif_desc') {
                        if ((vStsPaket) && ( aKdPaket != 0)) {
                            vTarif = 0;
                        } else {
                            vTarif = parseInt(((n.value).replaceAll(',','')).replaceAll('.',''),10);
                        }
                    }
                } else if (n.tagName == 'DIV') {
                    if (n.id == 'checkbox_sts_paket') {
                        if (n.childNodes[0]) {
                            for (var k = 0; l = n.childNodes[k]; ++k) {
                                if (l.tagName == 'INPUT' && l.type == 'checkbox') {
                                    if (l.id == 'sts_paket') {
                                        vStsPaket = l.checked;
                                    }
                                }
                            }
                        }
                    }
                }
            } 
        }
        return (vTarif);
    }

    function onModaltlynApotekPenjualan_ItemClickRacikan(aRow) {
        if (lEditMode) {
            aRowEditRacikan = aRow;
            document.getElementById("grpItemLynModaltlynApotekPenjualan").style.display = "none";
            document.getElementById('grpItemRacikanModaltlynApotekPenjualan').style.display = "";
            document.getElementById('grp_itempaket').style = "padding: 0px 25px; display: none;";
            //document.getElementById('grpItemRacikanModaltlynApotekPenjualanback').style = "";
            //document.getElementById('grpItemRacikanModaltlynApotekPenjualanbackx').style = "padding: 0px 25px;";
            document.getElementById('grp_itemtrx').style = "display: none;";
            document.getElementById('grp_itemtrxracikan').style = "";
            //document.getElementById('grp_button_saveclose').style = "display: none;";

            var root = document.getElementById('datatable-' + aModaltlynApotekPenjualan).getElementsByTagName('tbody')[0];
            var rows = root.getElementsByTagName('tr');
            var vDataJsonGet    = [];
            var vDataJsonSend   = [];
            vDataJsonGet        = onModaltlynApotekPenjualan_getrowData();
            for (var i = aRow + 1; i < vDataJsonGet.length; i++) {
                if ((vDataJsonGet[i].jnsitem == 7) || (vDataJsonGet[i].jnsitem == 8)) {
                    vDataJsonSend.push(vDataJsonGet[i]);
                } else { i = vDataJsonGet.length; }
            }
            var rootracikan = document.getElementById('datatable-' + aModaltlynApotekPenjualan + 'Racikan').getElementsByTagName('tbody')[0];

            onModaltlynApotekPenjualan_reset('Racikan');
            for (var i = 0; i < vDataJsonSend.length; i++) {
                vDataJsonSend[i].jnsitem = 5;
                vDataJsonSend[i].stsqty = '1';
                vDataJsonSend[i].stsedit = '1';
                vDataJsonSend[i].no_urut = i + 1;
                onModaltlynApotekPenjualan_tambah(vDataJsonSend[i], 'Racikan');
            }
            onModaltlynApotekPenjualan_filterReset();
        }
    }

    function isEditRacikan(aControl) {
        if (aControl != undefined) {
            if (aControl) {
                document.getElementById("grpItemLynModaltlynApotekPenjualan").style.display = "none";
                document.getElementById("grpItemRacikanModaltlynApotekPenjualan").style.display = "";
            } else {
                document.getElementById("grpItemLynModaltlynApotekPenjualan").style.display = "";
                document.getElementById("grpItemRacikanModaltlynApotekPenjualan").style.display = "none";
            }
        } else {
            return  document.getElementById("grpItemRacikanModaltlynApotekPenjualan").style.display == "";
        }
    }

    function onModaltlynApotekPenjualan_ItemClickRacikanBack() {
        document.getElementById("grpItemRacikanModaltlynApotekPenjualan").style.display = "none";
        document.getElementById("grpItemLynModaltlynApotekPenjualan").style.display = "";
        document.getElementById('grp_itempaket').style = "padding: 0px 25px; display: none;";
        document.getElementById('grp_itemtrx').style = "";
        document.getElementById('grp_itemtrxracikan').style = "display: none;";
        //document.getElementById('grp_button_saveclose').style = "";
        if (!(giModals)) {
            //document.getElementById('grp_button_saveclose').style = "display: none;";
        }
        if (lEditMode) {
            document.getElementById("grpItemLynModaltlynApotekPenjualan").style.display = "";
            document.getElementById('grpItemRacikanModaltlynApotekPenjualan').style.display = "none";
        } else {
            document.getElementById("grpItemLynModaltlynApotekPenjualan").style.display = "none";
            document.getElementById('grpItemRacikanModaltlynApotekPenjualan').style.display = "none";
        }
        onModaltlynApotekPenjualan_filterReset();
    }

    function onModaltlynApotekPenjualan_ItemClickKurang(aRow, aBahanRacikan) {
        if ($('#gvControlLock').html() != '1') {
            if (lEditMode) {
                var root = document.getElementById('datatable-' + aModaltlynApotekPenjualan + aBahanRacikan).getElementsByTagName('tbody')[0];
                var rows = root.getElementsByTagName('tr');
                var row = rows[aRow];
                var vQty = 0;
                var vKdItem;
                var vTarifDesc;
                var vRowDeleted = false;
                var vSts_paket = '0';
                for (var j = 0; m = row.childNodes[j]; ++j) {
                    for (var i = 0; n = m.childNodes[i]; ++i) {
                        if (n.tagName == 'INPUT' && n.type == 'text') {
                            if (n.id == 'qty') {
                                vQty = parseInt(n.value,10);
                                if (vQty > 1) { 
                                    n.value = parseInt(n.value,10) - 1; 
                                } else if (vQty == 1) {
                                    vRowDeleted = true;
                                }
                            } else if (n.id == 'kd_item') {
                                vKdItem = n.value;
                            } else if (n.id == 'tarif_desc') {
                                if (vQty > 1) { 
                                    vTarifDesc = n.value;
                                    vTarifDesc = vTarifDesc.replaceAll('.','');
                                    vTarifDesc = vTarifDesc.replaceAll(',','');
                                    
                                    //vTarifUnit = vTarifDesc / vQty;
                                    var vTarifUnit      = onModaltlynApotekPenjualan_GetTarifItem(aRow, vQty - 1, vKdItem);
                                    var vTarifUnitOri   = onModaltlynApotekPenjualan_GetTarifItem(aRow, vQty, vKdItem);
                                    vTarifDesc          = vTarifUnit * vQty;

                                    n.value = fmathNumberWithCommas(parseInt(vTarifDesc,10) - parseInt(vTarifUnit,10));
                                    if (vSts_paket == '0') {
                                        onModaltlynApotekPenjualan_UpdateTotal({ qty : vQty - 1, qtyori : vQty, tarifori : vTarifUnitOri, tarif : vTarifUnit });
                                    } else {
                                        onModaltlynApotekPenjualan_UpdateTotal({ qty : vQty - 1, qtyori : vQty, tarifori : vTarifUnitOri, tarif : 0 });
                                    }
                                } else if (vQty == 1) {
                                    vTarifDesc = n.value;
                                    vTarifDesc = vTarifDesc.replaceAll('.','');
                                    vTarifDesc = vTarifDesc.replaceAll(',','');
                                    
                                    //vTarifUnit = vTarifDesc / vQty;
                                    var vTarifUnit      = onModaltlynApotekPenjualan_GetTarifItem(aRow, vQty - 1, vKdItem);
                                    var vTarifUnitOri   = onModaltlynApotekPenjualan_GetTarifItem(aRow, vQty, vKdItem);
                                    vTarifDesc          = vTarifUnit * vQty;

                                    if (vSts_paket == '0') {
                                        onModaltlynApotekPenjualan_UpdateTotal({ qty : vQty - 1, qtyori : vQty, tarifori : vTarifUnitOri, tarif : vTarifUnit });
                                    } else {
                                        onModaltlynApotekPenjualan_UpdateTotal({ qty : vQty - 1, qtyori : vQty, tarifori : vTarifUnitOri, tarif : 0 });
                                    }
                                }
                            }
                        } else if (n.tagName == 'DIV') {
                            if (n.id == 'checkbox_sts_paket') {
                                if (n.childNodes[0]) {
                                    for (var k = 0; l = n.childNodes[k]; ++k) {
                                        if (l.tagName == 'INPUT' && l.type == 'checkbox') {
                                            if (l.id == 'sts_paket') {
                                                if (l.checked) { vSts_paket = '1' } else { vSts_paket = '0' }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                if (vRowDeleted) {
                    var vJnsitem = onModaltlynApotekPenjualan_GetCurrentJnsItem(aRow);
                    var vContDelete = true;
                    row.remove();
                    onModaltlynApotekPenjualan_UpdateEfekHapusTengah(aRow, aBahanRacikan);
                    if (aBahanRacikan == '') {
                        if ((vJnsitem == 5) || (vJnsitem == 6)) {
                            do {
                                if (root.getElementsByTagName('tr').length > aRow) {
                                    vJnsitem = onModaltlynApotekPenjualan_GetCurrentJnsItem(aRow);
                                    if ((vJnsitem == 7) || (vJnsitem == 8)) {
                                        row = root.getElementsByTagName('tr')[aRow];
                                        row.remove();
                                        onModaltlynApotekPenjualan_UpdateEfekHapusTengah(aRow);
                                    } else { vContDelete = false; }
                                } else { vContDelete = false; }
                            } while (vContDelete)
                        }
                    }
                    if (document.getElementById('datatable-' + aModaltlynApotekPenjualan + aBahanRacikan).getElementsByTagName('tbody')[0].getElementsByTagName('tr').length == 0) {
                        onModaltlynApotekPenjualan_reset(aBahanRacikan);
                    }
                }
            }
            onModaltlynApotekPenjualan_focus();
        }
    } 

    function onModaltlynApotekPenjualan_tambah(aData, aBahanRacikan = '', aRow = 0, aLoad = false) {
        var vItemPaket = find_in_object(iItemPaket, {key : aData.kd_paket});
        if (vItemPaket.length == 0) {
            vItemPaket.push({include_obat : '0'});
        }
        var root = document.getElementById('datatable-' + aModaltlynApotekPenjualan + aBahanRacikan).getElementsByTagName('tbody')[0];

        if ($(document).find('#datatable-' + aModaltlynApotekPenjualan + aBahanRacikan).DataTable().data().count() == 0) {
            if (aBahanRacikan == '') {
                $(document).find('#datatable-' + aModaltlynApotekPenjualan + aBahanRacikan).DataTable().destroy();
                var cCloneHtml = '';
                var row = root.insertRow(0);
                var cell1 = row.insertCell(0);
                var cell2 = row.insertCell(1);
                var cell3 = row.insertCell(2);
                var cell4 = row.insertCell(3);
                var cell5 = row.insertCell(4);
                var cell6 = row.insertCell(5);
                var cell7 = row.insertCell(6);
                var cell8 = row.insertCell(7);
                var cell9 = row.insertCell(8);
                var cell10 = row.insertCell(9);
                var cell11 = row.insertCell(10);
                var cell12 = row.insertCell(11);
                        
                cell1.style.width="80px";
                cell2.style.width="80px";
                cell3.style.width="70px";
                cell4.style.width="300px";
                cell5.style.width="120px";
                cell6.style.width="30px";
                cell7.style.width="30px";
                cell8.style.width="70px";
                cell9.style.width="150px";
                cell10.style.width="300px";
                cell11.style.width="80px";

                cCloneHtml = '';
                cCloneHtml = cCloneHtml + '<input disabled class="form-control form-control-sm text-right" type="text" value="' + aData.jnsitem + '" id="jnsitem" name="jnsitem" style="display: none;">';
                cCloneHtml = cCloneHtml + '<input disabled class="form-control form-control-sm text-right" type="text" value="' + aData.stspaket + '" id="stspaket" name="stspaket" style="display: none;">';
                cCloneHtml = cCloneHtml + '<input disabled class="form-control form-control-sm text-right" type="text" value="' + aData.stsqty + '" id="stsqty" name="stsqty" style="display: none;">';
                cCloneHtml = cCloneHtml + '<input disabled class="form-control form-control-sm text-right" type="text" value="' + aData.stskunci + '" id="stskunci" name="stskunci" style="display: none;">';
                cCloneHtml = cCloneHtml + '<input disabled class="form-control form-control-sm text-right" type="text" value="' + aData.stsedit + '" id="stsedit" name="stsedit" style="display: none;">';
                cCloneHtml = cCloneHtml + '<input disabled class="form-control form-control-sm text-right" type="text" value="' + aData.stsaturanpakai + '" id="stsaturanpakai" name="stsaturanpakai" style="display: none;">';
                cCloneHtml = cCloneHtml + '<button style="';
                if ((aData.jnsitem == '0') || (aData.sts_kunci == '0') || (aData.stsedit == '0')) {
                    cCloneHtml = cCloneHtml + 'display: none;';
                }
                cCloneHtml = cCloneHtml + '"';
                cCloneHtml = cCloneHtml + ' id="btnKurang" type="button" class="btn btn-danger">-</button>';
                cell1.innerHTML = cCloneHtml;
                
                cCloneHtml = '';
                cCloneHtml = cCloneHtml + '<input disabled class="';
                if (aData.jnsitem == '1') {
                    cCloneHtml = cCloneHtml + 'bg-primary';
                } else if (aData.jnsitem == '2') {
                    cCloneHtml = cCloneHtml + 'bg-danger';
                } else if (aData.jnsitem == '3') {
                    cCloneHtml = cCloneHtml + 'bg-secondary';
                } else if (aData.jnsitem == '4') {
                    cCloneHtml = cCloneHtml + 'bg-info';
                } else if (aData.jnsitem == '5') {
                    cCloneHtml = cCloneHtml + 'bg-warning';
                } else if (aData.jnsitem == '6') {
                    cCloneHtml = cCloneHtml + 'bg-success';
                } else if (aData.jnsitem == '7') {
                    cCloneHtml = cCloneHtml + 'bg-warning';
                } else if (aData.jnsitem == '8') {
                    cCloneHtml = cCloneHtml + 'bg-success';
                } else {
                    cCloneHtml = cCloneHtml + 'bg-dark';
                }
                cCloneHtml = cCloneHtml + ' text-white form-control text-right" type="text" value="' + aData.no_urut + '" id="no_urut" name="no_urut">';
                cCloneHtml = cCloneHtml + '<input disabled class="form-control form-control-sm text-right" type="text" value="' + aData.no_penjualan + '" id="no_penjualan" name="no_penjualan" style="display: none;">';
                cCloneHtml = cCloneHtml + '<input disabled class="form-control form-control-sm text-right" type="text" value="' + aData.kd_item + '" id="kd_item" name="kd_item" style="display: none;">';
                cCloneHtml = cCloneHtml + '<input disabled class="form-control form-control-sm text-right" type="text" value="' + aData.tgljam + '" id="tgljam" name="tgljam" style="display: none;">';
                cCloneHtml = cCloneHtml + '<input disabled class="form-control form-control-sm text-right" type="text" value="' + aData.racikan_no + '" id="racikan_no" name="racikan_no" style="display: none;">';
                cell2.innerHTML = cCloneHtml;

                cCloneHtml = '';
                cCloneHtml = cCloneHtml + '<button class="btn ';
                if (aData.jnsitem == '1') {
                    cCloneHtml = cCloneHtml + 'btn-primary';
                } else if (aData.jnsitem == '2') {
                    cCloneHtml = cCloneHtml + 'btn-danger';
                } else if (aData.jnsitem == '3') {
                    cCloneHtml = cCloneHtml + 'btn-secondary';
                } else if (aData.jnsitem == '4') {
                    cCloneHtml = cCloneHtml + 'btn-info';
                } else if (aData.jnsitem == '5') {
                    cCloneHtml = cCloneHtml + 'btn-warning';
                } else if (aData.jnsitem == '6') {
                    cCloneHtml = cCloneHtml + 'btn-success';
                } else if (aData.jnsitem == '7') {
                    cCloneHtml = cCloneHtml + 'btn-warning';
                } else if (aData.jnsitem == '8') {
                    cCloneHtml = cCloneHtml + 'btn-success';
                } else {
                    cCloneHtml = cCloneHtml + 'btn-dark';
                }
                cCloneHtml = cCloneHtml + ' text-white text-center" width="100%" ';
                cCloneHtml = cCloneHtml + ' style="';
                if ((aData.jnsitem == '0') || (aData.sts_kunci == '0') || (aData.stsedit == '0')) {
                    cCloneHtml = cCloneHtml + 'display: none;';
                }
                cCloneHtml = cCloneHtml + '" id="btnRacikan" type="button">1</button>';
                cell3.innerHTML = cCloneHtml;
                <% if(dataDtls[0].billing_showlist4 != '1') { %> 
                    cell3.style = "display : none;";
                <% } %>

                cCloneHtml = '';
                cCloneHtml = cCloneHtml + '<input disabled class="';
                if (aData.jnsitem == '1') {
                    cCloneHtml = cCloneHtml + 'bg-primary';
                } else if (aData.jnsitem == '2') {
                    cCloneHtml = cCloneHtml + 'bg-danger';
                } else if (aData.jnsitem == '3') {
                    cCloneHtml = cCloneHtml + 'bg-secondary';
                } else if (aData.jnsitem == '4') {
                    cCloneHtml = cCloneHtml + 'bg-info';
                } else if (aData.jnsitem == '5') {
                    cCloneHtml = cCloneHtml + 'bg-warning';
                } else if (aData.jnsitem == '6') {
                    cCloneHtml = cCloneHtml + 'bg-success';
                } else if (aData.jnsitem == '7') {
                    cCloneHtml = cCloneHtml + 'bg-warning';
                } else if (aData.jnsitem == '8') {
                    cCloneHtml = cCloneHtml + 'bg-success';
                } else {
                    cCloneHtml = cCloneHtml + 'bg-dark';
                }
                cCloneHtml = cCloneHtml + ' text-white form-control text-left" type="text" value="' + aData.nm_item + '" id="nm_item" name="nm_item">';
                cell4.innerHTML = cCloneHtml;

                cCloneHtml = '';
                cCloneHtml = cCloneHtml + '<input class="';
                if (aData.jnsitem == '1') {
                    cCloneHtml = cCloneHtml + 'bg-primary';
                } else if (aData.jnsitem == '2') {
                    cCloneHtml = cCloneHtml + 'bg-danger';
                } else if (aData.jnsitem == '3') {
                    cCloneHtml = cCloneHtml + 'bg-secondary';
                } else if (aData.jnsitem == '4') {
                    cCloneHtml = cCloneHtml + 'bg-info';
                } else if (aData.jnsitem == '5') {
                    cCloneHtml = cCloneHtml + 'bg-warning';
                } else if (aData.jnsitem == '6') {
                    cCloneHtml = cCloneHtml + 'bg-success';
                } else if (aData.jnsitem == '7') {
                    cCloneHtml = cCloneHtml + 'bg-warning';
                } else if (aData.jnsitem == '8') {
                    cCloneHtml = cCloneHtml + 'bg-success';
                } else {
                    cCloneHtml = cCloneHtml + 'bg-dark';
                }
                cCloneHtml = cCloneHtml + ' text-white form-control text-left" type="text" value="' + aData.nm_item + '" id="nm_item" name="nm_item">';
                cCloneHtml = cCloneHtml + ' text-white form-control text-right" type="text" value="' + aData.nilai_hasil_periksa + '" id="nilai_hasil_periksa" name="nilai_hasil_periksa" ';
                cCloneHtml = cCloneHtml + ' style="';
                if ((aData.jnsitem == '0') || (aData.sts_kunci == '0') || (aData.stsedit == '0')) {
                    cCloneHtml = cCloneHtml + 'display: none;';
                }
                cCloneHtml = cCloneHtml + ' ">';
                cell5.innerHTML = cCloneHtml;
                <% if(dataDtls[0].billing_showlist1 != '1') { %> 
                    cell5.style = "display : none;";
                <% } %>

                cCloneHtml = '';
                cCloneHtml = cCloneHtml + '<div id="checkbox_sts_paket" class="form-check">';
                cCloneHtml = cCloneHtml + '<input type="checkbox" class="form-check-input" value="' + aData.sts_paket + '" name="sts_paket" id="sts_paket"';
                cCloneHtml = cCloneHtml + ' style="';
                if ((aData.jnsitem == '0') || (aData.jnsitem == '7')) {
                    cCloneHtml = cCloneHtml + 'display: none;';
                }
                cCloneHtml = cCloneHtml + '" ';
                if (aData.sts_paket == '1') {
                    cCloneHtml = cCloneHtml + 'checked';
                }
                cCloneHtml = cCloneHtml + '></div>';
                cell6.innerHTML = cCloneHtml;
                cell6.classList.add('text-center');
                cell6.style = "display : none;";

                cCloneHtml = '';
                cCloneHtml = cCloneHtml + '<div id="checkbox_sts_kunci" class="form-check">';
                cCloneHtml = cCloneHtml + '<input type="checkbox" class="form-check-input" value="' + aData.sts_kunci + '" name="sts_kunci" id="sts_kunci"';
                if ((aData.stskunci == '0') || (aData.stsedit == '0')) {
                    cCloneHtml = cCloneHtml + ' disabled ';
                }
                cCloneHtml = cCloneHtml + '" ';
                if (aData.sts_kunci == '1') {
                    cCloneHtml = cCloneHtml + ' checked ';
                }
                cCloneHtml = cCloneHtml + '></div>';
                cell7.innerHTML = cCloneHtml;
                cell7.classList.add('text-center');
                cell7.style = "display : none;";

                cCloneHtml = '';
                cCloneHtml = cCloneHtml + '<input disabled class="';
                if (aData.jnsitem == '1') {
                    cCloneHtml = cCloneHtml + 'bg-primary';
                } else if (aData.jnsitem == '2') {
                    cCloneHtml = cCloneHtml + 'bg-danger';
                } else if (aData.jnsitem == '3') {
                    cCloneHtml = cCloneHtml + 'bg-secondary';
                } else if (aData.jnsitem == '4') {
                    cCloneHtml = cCloneHtml + 'bg-info';
                } else if (aData.jnsitem == '5') {
                    cCloneHtml = cCloneHtml + 'bg-warning';
                } else if (aData.jnsitem == '6') {
                    cCloneHtml = cCloneHtml + 'bg-success';
                } else if (aData.jnsitem == '7') {
                    cCloneHtml = cCloneHtml + 'bg-warning';
                } else if (aData.jnsitem == '8') {
                    cCloneHtml = cCloneHtml + 'bg-success';
                } else {
                    cCloneHtml = cCloneHtml + 'bg-dark';
                }
                cCloneHtml = cCloneHtml + ' text-white form-control text-right" type="text" value="' + aData.qty + '" id="qty" name="qty">';
                cell8.innerHTML = cCloneHtml;

                cCloneHtml = '';
                cCloneHtml = cCloneHtml + '<input disabled class="';
                if (aData.jnsitem == '1') {
                    cCloneHtml = cCloneHtml + 'bg-primary';
                } else if (aData.jnsitem == '2') {
                    cCloneHtml = cCloneHtml + 'bg-danger';
                } else if (aData.jnsitem == '3') {
                    cCloneHtml = cCloneHtml + 'bg-secondary';
                } else if (aData.jnsitem == '4') {
                    cCloneHtml = cCloneHtml + 'bg-info';
                } else if (aData.jnsitem == '5') {
                    cCloneHtml = cCloneHtml + 'bg-warning';
                } else if (aData.jnsitem == '6') {
                    cCloneHtml = cCloneHtml + 'bg-success';
                } else if (aData.jnsitem == '7') {
                    cCloneHtml = cCloneHtml + 'bg-warning';
                } else if (aData.jnsitem == '8') {
                    cCloneHtml = cCloneHtml + 'bg-success';
                } else {
                    cCloneHtml = cCloneHtml + 'bg-dark';
                }
                cCloneHtml = cCloneHtml + ' text-white form-control text-right" type="text" value="' + aData.tarif_desc + '" id="tarif_desc" name="tarif_desc"';
                cCloneHtml = cCloneHtml + ' style="';
                if (aData.sts_paket != '0') {
                    cCloneHtml = cCloneHtml + 'display: none;';
                }
                cCloneHtml = cCloneHtml + '"> ';
                cell9.innerHTML = cCloneHtml;

                cCloneHtml = '';
                cCloneHtml = cCloneHtml + '<div id="grp_aturanpakai"';
                cCloneHtml = cCloneHtml + ' style="';
                if (aData.stsaturanpakai == '0') {
                    cCloneHtml = cCloneHtml + 'display: none;';
                }
                cCloneHtml = cCloneHtml + ' padding: 0;">';
                cCloneHtml = cCloneHtml + '<select id="aturanpakai-' + aData.no_urut + '" class="select2-purple" multiple="multiple">';
                <% if(dataDrop.dddwaturanpakai != null) { %>
                    <% dataDrop.dddwaturanpakai.forEach(function(datadrop, index) { %>
                        cCloneHtml = cCloneHtml + '<option value="<%- datadrop.key %>"><%- datadrop.value %> </option>';
                    <% }) %>
                <% } %>
                cCloneHtml = cCloneHtml + ' </select>';
                cCloneHtml = cCloneHtml + ' </div>';
                cell10.innerHTML = cCloneHtml;
                <% if(dataDtls[0].billing_showlist2 != '1') { %> 
                    cell10.style = "display : none;";
                <% } %>

                cCloneHtml = '';
                cCloneHtml = cCloneHtml + '<button style="'; 
                if ((aData.stsqty == '0') || (aData.sts_kunci == '1') || (aData.stsedit == '0')) {
                    cCloneHtml = cCloneHtml + 'display: none;';
                }
                cCloneHtml = cCloneHtml + '" id="btnTambah" type="button" class="btn btn-primary">+</button>';
                cell11.innerHTML = cCloneHtml;

                cCloneHtml = '';
                cCloneHtml = cCloneHtml + '<button style="'; 
                if ((aData.stsqty == '0') || (aData.sts_kunci == '1') || (aData.stsedit == '0')) {
                    cCloneHtml = cCloneHtml + 'display: none;';
                }
                cCloneHtml = cCloneHtml + '" id="btnTambahEdit" type="button" class="btn btn-success">e</button>';
                cell12.innerHTML = cCloneHtml;

                if (aBahanRacikan == "") {
                    datatablemodule('datatable-' + aModaltlynApotekPenjualan + aBahanRacikan, (parseInt(gvHeightOfRincian,10) + (iHeightStandarTable - iHeightTableTrxs)));
                } else {
                    datatablemodule('datatable-' + aModaltlynApotekPenjualan + aBahanRacikan, (parseInt(gvHeightOfRincian,10) + (iHeightStandarTable - iHeightTableRack)));
                }
                onModaltlynApotekPenjualan_SetListener(0, aData, aBahanRacikan);
                if ((parseInt(vItemPaket[0].include_obat,10) == 1) && (aData.stspaket == '1')) {
                    //onModaltlynApotekPenjualan_UpdateTotal({ qty : aData.qty, tarif : 0 });
                    onModaltlynApotekPenjualan_UpdateTotal({ qty : aData.qty, qtyori : aData.qty, tarifori : 0, tarif :  parseInt(((aData.tarif_desc).replaceAll('.','')).replaceAll(',',''),10) });
                } else {
                    onModaltlynApotekPenjualan_UpdateTotal({ qty : aData.qty, qtyori : aData.qty, tarifori : 0, tarif :  parseInt(((aData.tarif_desc).replaceAll('.','')).replaceAll(',',''),10) });
                }
            } else {

                $(document).find('#datatable-' + aModaltlynApotekPenjualan + aBahanRacikan).DataTable().destroy();
                var cCloneHtml = '';
                var row = root.insertRow(0);
                var cell1 = row.insertCell(0);
                var cell2 = row.insertCell(1);
                var cell3 = row.insertCell(2);
                var cell4 = row.insertCell(3);
                var cell5 = row.insertCell(4);
                
                cell1.style.width="50px";
                cell2.style.width="70px";
                cell3.style.width="300px";
                cell4.style.width="70px";
                cell5.style.width="50px";

                cCloneHtml = '';
                cCloneHtml = cCloneHtml + '<input disabled class="form-control form-control-sm text-right" type="text" value="' + aData.jnsitem + '" id="jnsitem" name="jnsitem" style="display: none;">';
                cCloneHtml = cCloneHtml + '<input disabled class="form-control form-control-sm text-right" type="text" value="' + aData.stspaket + '" id="stspaket" name="stspaket" style="display: none;">';
                cCloneHtml = cCloneHtml + '<input disabled class="form-control form-control-sm text-right" type="text" value="' + aData.stsqty + '" id="stsqty" name="stsqty" style="display: none;">';
                cCloneHtml = cCloneHtml + '<input disabled class="form-control form-control-sm text-right" type="text" value="' + aData.stskunci + '" id="stskunci" name="stskunci" style="display: none;">';
                cCloneHtml = cCloneHtml + '<input disabled class="form-control form-control-sm text-right" type="text" value="' + aData.sts_kunci + '" id="sts_kunci" name="sts_kunci" style="display: none;">';
                cCloneHtml = cCloneHtml + '<input disabled class="form-control form-control-sm text-right" type="text" value="' + aData.stsedit + '" id="stsedit" name="stsedit" style="display: none;">';
                cCloneHtml = cCloneHtml + '<button style="';
                //if ((aData.jnsitem == '0') || (aData.sts_kunci == '0') || (aData.stsedit == '0')) {
                //    cCloneHtml = cCloneHtml + 'display: none;';
                //}
                cCloneHtml = cCloneHtml + '"';
                cCloneHtml = cCloneHtml + ' id="btnKurang" type="button" class="btn btn-danger">-</button>';
                cell1.innerHTML = cCloneHtml;

                cCloneHtml = '';
                cCloneHtml = cCloneHtml + '<input disabled class="';
                if (aData.jnsitem == '1') {
                    cCloneHtml = cCloneHtml + 'bg-primary';
                } else if (aData.jnsitem == '2') {
                    cCloneHtml = cCloneHtml + 'bg-danger';
                } else if (aData.jnsitem == '3') {
                    cCloneHtml = cCloneHtml + 'bg-secondary';
                } else if (aData.jnsitem == '4') {
                    cCloneHtml = cCloneHtml + 'bg-info';
                } else if (aData.jnsitem == '5') {
                    cCloneHtml = cCloneHtml + 'bg-warning';
                } else if (aData.jnsitem == '6') {
                    cCloneHtml = cCloneHtml + 'bg-success';
                } else if (aData.jnsitem == '7') {
                    cCloneHtml = cCloneHtml + 'bg-warning';
                } else if (aData.jnsitem == '8') {
                    cCloneHtml = cCloneHtml + 'bg-success';
                } else {
                    cCloneHtml = cCloneHtml + 'bg-dark';
                }
                cCloneHtml = cCloneHtml + ' text-white form-control text-right" type="text" value="' + aData.no_urut + '" id="no_urut" name="no_urut">';
                cCloneHtml = cCloneHtml + '<input disabled class="form-control form-control-sm text-right" type="text" value="' + aData.no_penjualan + '" id="no_penjualan" name="no_penjualan" style="display: none;">';
                cCloneHtml = cCloneHtml + '<input disabled class="form-control form-control-sm text-right" type="text" value="' + aData.kd_item + '" id="kd_item" name="kd_item" style="display: none;">';
                cCloneHtml = cCloneHtml + '<input disabled class="form-control form-control-sm text-right" type="text" value="' + aData.tgljam + '" id="tgljam" name="tgljam" style="display: none;">';
                cCloneHtml = cCloneHtml + '<input disabled class="form-control form-control-sm text-right" type="text" value="' + aData.racikan_no + '" id="racikan_no" name="racikan_no" style="display: none;">';
                cell2.innerHTML = cCloneHtml;

                cCloneHtml = '';
                cCloneHtml = cCloneHtml + '<input disabled class="';
                if (aData.jnsitem == '1') {
                    cCloneHtml = cCloneHtml + 'bg-primary';
                } else if (aData.jnsitem == '2') {
                    cCloneHtml = cCloneHtml + 'bg-danger';
                } else if (aData.jnsitem == '3') {
                    cCloneHtml = cCloneHtml + 'bg-secondary';
                } else if (aData.jnsitem == '4') {
                    cCloneHtml = cCloneHtml + 'bg-info';
                } else if (aData.jnsitem == '5') {
                    cCloneHtml = cCloneHtml + 'bg-warning';
                } else if (aData.jnsitem == '6') {
                    cCloneHtml = cCloneHtml + 'bg-success';
                } else if (aData.jnsitem == '7') {
                    cCloneHtml = cCloneHtml + 'bg-warning';
                } else if (aData.jnsitem == '8') {
                    cCloneHtml = cCloneHtml + 'bg-success';
                } else {
                    cCloneHtml = cCloneHtml + 'bg-dark';
                }
                cCloneHtml = cCloneHtml + ' text-white form-control text-left" type="text" value="' + aData.nm_item + '" id="nm_item" name="nm_item">';
                cell3.innerHTML = cCloneHtml;

                cCloneHtml = '';
                cCloneHtml = cCloneHtml + '<input disabled class="';
                if (aData.jnsitem == '1') {
                    cCloneHtml = cCloneHtml + 'bg-primary';
                } else if (aData.jnsitem == '2') {
                    cCloneHtml = cCloneHtml + 'bg-danger';
                } else if (aData.jnsitem == '3') {
                    cCloneHtml = cCloneHtml + 'bg-secondary';
                } else if (aData.jnsitem == '4') {
                    cCloneHtml = cCloneHtml + 'bg-info';
                } else if (aData.jnsitem == '5') {
                    cCloneHtml = cCloneHtml + 'bg-warning';
                } else if (aData.jnsitem == '6') {
                    cCloneHtml = cCloneHtml + 'bg-success';
                } else if (aData.jnsitem == '7') {
                    cCloneHtml = cCloneHtml + 'bg-warning';
                } else if (aData.jnsitem == '8') {
                    cCloneHtml = cCloneHtml + 'bg-success';
                } else {
                    cCloneHtml = cCloneHtml + 'bg-dark';
                }
                cCloneHtml = cCloneHtml + ' text-white form-control text-right" type="text" value="' + aData.qty + '" id="qty" name="qty">';
                cell4.innerHTML = cCloneHtml;

                cCloneHtml = '';
                cCloneHtml = cCloneHtml + '<button style="'; 
                if ((aData.stsqty == '0') || (aData.sts_kunci == '1') || (aData.stsedit == '0')) {
                    cCloneHtml = cCloneHtml + 'display: none;';
                }
                cCloneHtml = cCloneHtml + '" id="btnTambah" type="button" class="btn btn-primary">+</button>';
                cell5.innerHTML = cCloneHtml;
                if (aBahanRacikan == "") {
                    datatablemodule('datatable-' + aModaltlynApotekPenjualan + aBahanRacikan, (parseInt(gvHeightOfRincian,10) + (iHeightStandarTable - iHeightTableTrxs)));
                } else {
                    datatablemodule('datatable-' + aModaltlynApotekPenjualan + aBahanRacikan, (parseInt(gvHeightOfRincian,10) + (iHeightStandarTable - iHeightTableRack)));
                }
                onModaltlynApotekPenjualan_SetListener(0, aData, aBahanRacikan);
            }
        } else {
            var rows = root.getElementsByTagName('tr');
            var vBarisKe; 
            var vRowLength = rows.length;

            vBarisKe = aRow;
            if (aRow == 0) { aData.no_urut = vRowLength + 1; }
            var clone = onModaltlynApotekPenjualanCloneEl(rows[vBarisKe]);
            onModaltlynApotekPenjualanCleanUpInputs(clone, aData);
            if (aRow == 0) {
                if (aLoad) {
                    root.appendChild(clone);
                    onModaltlynApotekPenjualan_SetListener(vRowLength, aData, aBahanRacikan);
                } else {
                    if (lSisipBaris0UntukTambah) {
                        root.insertBefore(clone, rows[vBarisKe]);
                        onModaltlynApotekPenjualan_SetListener(1, aData, aBahanRacikan);
                        onModaltlynApotekPenjualan_UpdateEfekHapusTengah(vBarisKe);
                        onModaltlynApotekPenjualan_SetRowFocus(0, aBahanRacikan);
                    } else {
                        root.appendChild(clone);
                        onModaltlynApotekPenjualan_SetListener(vRowLength, aData, aBahanRacikan);
                    }
                }
            } else {
                root.insertBefore(clone, rows[vBarisKe]);
                onModaltlynApotekPenjualan_SetListener(vBarisKe, aData, aBahanRacikan);
                onModaltlynApotekPenjualan_UpdateEfekHapusTengah(vBarisKe + 1);
            }
            
            if (aBahanRacikan == '') {
                if ((parseInt(vItemPaket[0].include_obat,10) == 1) && (aData.stspaket == '1')) {
                    onModaltlynApotekPenjualan_UpdateTotal({ qty : aData.qty, qtyori : aData.qty, tarifori : 0, tarif : 0 });
                } else {
                    onModaltlynApotekPenjualan_UpdateTotal({ qty : aData.qty, qtyori : aData.qty, tarifori : 0, tarif :  parseInt(((aData.tarif_desc).replaceAll('.','')).replaceAll(',',''),10) });
                }
            }
        }
        onModaltlynApotekPenjualan_focus();
    }
    function onModaltlynApotekPenjualanCloneEl(el) {
        var clo = el.cloneNode(true);
        return clo;
    }
    function onModaltlynApotekPenjualanCleanUpInputs(obj, aData) {
        var elclone;
        var vItemPaket = find_in_object(iItemPaket, {key : aData.kd_paket});
        if (vItemPaket.length == 0) { vItemPaket.push({include_obat : '0'}); }

        for (var i = 0; n = obj.childNodes[i]; ++i) {
            if (n.tagName == 'BUTTON') {
                if (n.id == 'btnRacikan') {
                    n.classList.remove("bg-primary");
                    n.classList.remove("bg-danger");
                    n.classList.remove("bg-secondary");
                    n.classList.remove("bg-info");
                    n.classList.remove("bg-warning");
                    n.classList.remove("bg-success");
                    n.classList.remove("bg-dark");
                    if (aData.jnsitem == 1) {
                        n.classList.add("bg-primary");
                    } else if (aData.jnsitem == 2) {
                        n.classList.add("bg-danger");
                    } else if (aData.jnsitem == 3) {
                        n.classList.add("bg-secondary");
                    } else if (aData.jnsitem == 4) {
                        n.classList.add("bg-info");
                    } else if ((aData.jnsitem == 5) || (aData.jnsitem == 7)) {
                        n.classList.add("bg-warning");
                    } else if ((aData.jnsitem == 6) || (aData.jnsitem == 8)) {
                        n.classList.add("bg-success");
                    } else {
                        n.classList.add("bg-dark");
                    }
                }
            } else if (n.tagName == 'INPUT' && n.type == 'text') {
                if (n.id == 'no_urut') {
                    n.value = parseInt(n.value,10) + 1;
                    n.classList.remove("bg-primary");
                    n.classList.remove("bg-danger");
                    n.classList.remove("bg-secondary");
                    n.classList.remove("bg-info");
                    n.classList.remove("bg-warning");
                    n.classList.remove("bg-success");
                    n.classList.remove("bg-dark");
                    if (aData.jnsitem == 1) {
                        n.classList.add("bg-primary");
                    } else if (aData.jnsitem == 2) {
                        n.classList.add("bg-danger");
                    } else if (aData.jnsitem == 3) {
                        n.classList.add("bg-secondary");
                    } else if (aData.jnsitem == 4) {
                        n.classList.add("bg-info");
                    } else if ((aData.jnsitem == 5) || (aData.jnsitem == 7)) {
                        n.classList.add("bg-warning");
                    } else if ((aData.jnsitem == 6) || (aData.jnsitem == 8)) {
                        n.classList.add("bg-success");
                    } else {
                        n.classList.add("bg-dark");
                    }
                } else if (n.id == 'jumlah') {
                    n.value = aData[n.id];
                    if (aData.flag_newrows == '1') {
                        n.disabled = false;
                    } else {
                        n.disabled = true;
                    }
                } else if (n.id == 'tarif_desc') {
                    n.value = aData[n.id];
                    if ((aData.stspaket == '1') && (parseInt(vItemPaket[0].include_obat,10) == 1)) {
                    //if ((aData.stspaket == '1') && ( aData.kd_paket != '0')) {
                        n.style = "display: none;";
                    } else {
                        n.style = "";
                    }
                    n.classList.remove("bg-primary");
                    n.classList.remove("bg-danger");
                    n.classList.remove("bg-secondary");
                    n.classList.remove("bg-info");
                    n.classList.remove("bg-warning");
                    n.classList.remove("bg-success");
                    n.classList.remove("bg-dark");
                    if (aData.jnsitem == 1) {
                        n.classList.add("bg-primary");
                    } else if (aData.jnsitem == 2) {
                        n.classList.add("bg-danger");
                    } else if (aData.jnsitem == 3) {
                        n.classList.add("bg-secondary");
                    } else if (aData.jnsitem == 4) {
                        n.classList.add("bg-info");
                    } else if ((aData.jnsitem == 5) || (aData.jnsitem == 7)) {
                        n.classList.add("bg-warning");
                    } else if ((aData.jnsitem == 6) || (aData.jnsitem == 8)) {
                        n.classList.add("bg-success");
                    } else {
                        n.classList.add("bg-dark");
                    }
                } else if (n.id == 'nilai_hasil_periksa') {
                    n.value = aData[n.id];
                    if ((aData.stshsl == '0')) {
                        n.style = "display: none;";
                    } else {
                        n.style = "";
                    }
                    n.classList.remove("bg-primary");
                    n.classList.remove("bg-danger");
                    n.classList.remove("bg-secondary");
                    n.classList.remove("bg-info");
                    n.classList.remove("bg-warning");
                    n.classList.remove("bg-success");
                    n.classList.remove("bg-dark");
                    if (aData.jnsitem == 1) {
                        n.classList.add("bg-primary");
                    } else if (aData.jnsitem == 2) {
                        n.classList.add("bg-danger");
                    } else if (aData.jnsitem == 3) {
                        n.classList.add("bg-secondary");
                    } else if (aData.jnsitem == 4) {
                        n.classList.add("bg-info");
                    } else if ((aData.jnsitem == 5) || (aData.jnsitem == 7)) {
                        n.classList.add("bg-warning");
                    } else if ((aData.jnsitem == 6) || (aData.jnsitem == 8)) {
                        n.classList.add("bg-success");
                    } else {
                        n.classList.add("bg-dark");
                    }
                } else {
                    n.value = aData[n.id];
                    n.classList.remove("bg-primary");
                    n.classList.remove("bg-danger");
                    n.classList.remove("bg-secondary");
                    n.classList.remove("bg-info");
                    n.classList.remove("bg-warning");
                    n.classList.remove("bg-success");
                    n.classList.remove("bg-dark");
                    if (aData.jnsitem == 1) {
                        n.classList.add("bg-primary");
                    } else if (aData.jnsitem == 2) {
                        n.classList.add("bg-danger");
                    } else if (aData.jnsitem == 3) {
                        n.classList.add("bg-secondary");
                    } else if (aData.jnsitem == 4) {
                        n.classList.add("bg-info");
                    } else if ((aData.jnsitem == 5) || (aData.jnsitem == 7)) {
                        n.classList.add("bg-warning");
                    } else if ((aData.jnsitem == 6) || (aData.jnsitem == 8)) {
                        n.classList.add("bg-success");
                    } else {
                        n.classList.add("bg-dark");
                    }
                }
            } else if (n.tagName == 'INPUT' && n.type == 'checkbox') {
                if (n.id == 'sts_paket') {
                    if ((aData.stspaket == '1') && (parseInt(vItemPaket[0].include_obat,10) == 1)) {
                    //if ((aData.stspaket == '1') && ( aData.kd_paket != '0')) {
                        n.checked = true;
                    } else {
                        n.checked = false;
                    }
                } else if (n.id == 'sts_kunci') {
                    if ((aData.stskunci == '1') && (aData.stsedit == '1')) {
                        n.disabled = false;
                    } else {
                        n.disabled = true;
                    }
                    n.checked = aData.stskunci == '1';
                }
            } else if (n.childNodes[0]) {
                onModaltlynApotekPenjualanCleanUpInputs(n, aData);
            }
        }  
    }
*/
</script>
