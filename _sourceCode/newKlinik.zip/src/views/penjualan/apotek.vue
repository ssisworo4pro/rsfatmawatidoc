<template>
    <div class="py-4 container-fluid">
      <div class="row">
        <div class="col-lg-12">
          <!-- line chart -->
              <div class="row">
                <div class="col-lg-6 col-md-12">
                  <div class="card" style="padding: 10px;" :style="{'height': this.cardHeight}">
                    <ApotekJual @change-katalog="SetDataMst" ref="refApotekJual"/>
                  </div>
                </div>
                <div class="col-lg-6 col-md-12">
                  <div class="card" style="padding: 10px;" :style="{'height': this.cardHeight}">
                    <ApotekCari @barcode="SetBarcode" ref="refApotekCari"/>
                  </div>
                </div>
              </div>
              <!--
              <hr style="margin: 3px; color: transparent">
              <div class="card">
                  <Pendaftaran />
              </div>
              -->
        </div>
      </div>
    </div>
    <modalSearch @pilih="GetDataTrx()"/>
  </template>
  <script>
  //import Pendaftaran from "../pendaftaran/pendaftaran.vue";
  //import ApotekJualan from "./apotekJualan.vue";
  import modalSearch from "@/layout/Modals/modalSearch.vue";
  import ApotekJual from "./apotekJual.vue";
  import ApotekCari from "./apotekCari.vue";
  // import { ref } from 'vue';
  // const refApotekJual = ref(0);

  export default {
    name: "dashboard-default",
    data() {
      return {
        stats: {
          iEditMode: false
        },
        baseurl : process.env.VUE_APP_AUTH_SERVICE,
        connection: null
      };
    },
    created: function() {
        console.log("Starting connection to WebSocket Server")
        this.connection = new WebSocket("ws://localhost:88")
        this.connection.onmessage = function(event) {
            console.log(event);
        }
        this.connection.onopen = function(event) {
            console.log(event)
            console.log("Successfully connected to the echo websocket server...")
        }
    },
    mounted() {
      this.$store.state.showNavbar = true;
      this.$store.state.showControl = true;
    },
    components: {
      //Pendaftaran,
      //ApotekJualan,
      modalSearch,
      ApotekJual,
      ApotekCari
    },    
    methods: {
      SetBarcode(kodeBarcode) {
          this.$refs.refApotekJual.InputBarcodePublic(kodeBarcode);
      },
      GetDataTrx() {
        this.$refs.refApotekJual.GetDataTrx();
      },
      SetDataMst() {
        this.$refs.refApotekCari.mstKatalogs = this.$refs.refApotekJual.mstKatalogs;
      }
    },
    computed: {
      cardHeight() {
            // 1034 - 464 = 570
            // 1034 - 849 ===> 185
            var vTableBodyHeight = (window.innerHeight - 185) + 'px';
            return vTableBodyHeight;
        }
    }
  };
  </script>
  