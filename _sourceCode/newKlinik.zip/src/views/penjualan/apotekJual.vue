<template>
    <table class="table table-sm table-bordered table-trxs" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
            <tbody>
                <tr>
                    <td width="15%">
                        <input disabled style="height: 39px; font-size: 19px;" class="bg-dark text-white form-control text-center" type="text" value="ID">
                    </td>
                    <td width="35%">
                        <input id="inputPelanggan" @change="InputPelanggan()" @focus="$event.target.select()" type="text" v-model="inputs.PelangganId" style="height: 39px; font-size: 19px;" class="bg-white text-black form-control text-right">
                    </td>
                    <td width="50%" rowspan="2" colspan="2">
                        <div v-html="TotalHarga" style="line-height:67px; height: 87px; font-size: 49px; vertical-align: middle;" class="bg-dark text-white text-center form-control">
                        </div>
                    </td>
                </tr>
                <tr>
                    <td>
                        <input disabled style="height: 39px; font-size: 19px;" class="bg-dark text-white form-control text-center" type="text" value="Nama">
                    </td>
                    <td>
                        <input disabled type="text" v-model="inputs.PelangganNama" style="height: 39px; font-size: 19px;" class="bg-dark text-white form-control">
                    </td>
                </tr>
                <tr>
                    <td>
                        <input disabled style="height: 39px; font-size: 19px;" class="bg-dark text-white form-control text-center" type="text" value="Alamat">
                    </td>
                    <td colspan="2">
                        <input disabled type="text" v-model="inputs.PelangganAlamat" style="height: 39px; font-size: 19px;" class="bg-dark text-white form-control">
                    </td>
                    <td>
                        <div class="bg-dark text-white text-center form-control">
                            {{ this.$store.state.gTrxCode }}
                        </div>
                    </td>
                </tr>
            </tbody>
        </table>
        <table id="datatable-ModaltlynApotekPenjualan" class="table align-items-center table-sm table-bordered table-trxs" style="margin : 0 0; padding : 0 0; border-collapse: collapse; border-spacing: 0; width: 100%;">
        <thead class="theadscroll">
            <tr class="bg-dark text-white">
                <th style="width:5%;">-</th>
                <th style="width:7%;">No</th>
                <th style="width:5%; display : none;">R</th>
                <th style="width:25%;">Uraian</th>
                <th style="width:5%; display : none;">Hsl</th>
                <th style="width:5%; display : none;">Pkt</th>
                <th style="width:5%; display : none;">Lock</th>
                <th style="width:8%;">Qty</th>
                <th style="width:14%;">Tarif</th>
                <th style="width:20%; display : none;">Aturan Pakai</th>
                <th style="width:5%;">+</th>
                <th style="width:5%;">e</th>
            </tr>
        </thead>
        <tbody class="scrollable"
        :style="{'height': this.tableBodyHeight}"
        >
        <tr v-for="(trxKatalog, index) in trxKatalogs" :key="index">
            <td style="width:5%">
                <button @click="ButtonKurang(index)" id="btnKurang" type="button" class="btn btn-danger">-</button>
            </td>
            <td style="width:7%">
                <input disabled class="bg-dark text-white form-control text-right" type="text" :value="index + 1" id="no_urut" name="no_urut">
            </td>
            <td style="width: 5%; display: none;">
                <button class="btn btn-success text-white text-center"
                width="100%"
                style="" 
                id="btnRacikan" type="button">
                R
                </button>
            </td>
            <td style="width: 25%">
                <input disabled class="bg-dark text-white form-control text-left" type="text" v-model="trxKatalog.nm_item" id="nm_item" name="nm_item">
            </td>

            <td style="display: none;">
                <input class="bg-dark text-white form-control text-right" type="text" value="0" id="nilai_hasil_periksa" name="nilai_hasil_periksa">
            </td>
            <td class="text-center" style="display: none;">
                <div id="checkbox_sts_paket" class="form-check">
                    <input type="checkbox" class="form-check-input" value='<%- datarinci.sts_paket %>' name="sts_paket" id="sts_paket">
                </div>
            </td>
            <td class="text-center" style="display: none;">
                <div id="checkbox_sts_kunci" class="form-check">
                    <input type="checkbox" class="form-check-input" value='<%- datarinci.sts_kunci %>' name="sts_kunci" id="sts_kunci">
                </div>
            </td>

            <td style="width: 8%">
                <input disabled class="bg-dark text-white form-control text-right" type="text" :value="trxKatalog.qty" id="qty" name="qty">
            </td>
            <td style="width: 14%">
                <input disabled class="bg-dark text-white form-control text-right" type="text" :value="trxKatalog.tarif_desc" id="tarif_desc" name="tarif_desc">
            </td>
            <td style="width: 20%; display : none;">
                <div id="grp_aturanpakai">
                    <select id="aturanpakai-1" class="form-control form-control"  name="aturan pakai">
                        <option value="1">{{ index }}</option>
                    </select>
                </div>
            </td>
            <td style="width: 5%">
                <button @click="ButtonTambah(index)" type="button" class="btn btn-primary">+</button>
            </td>
            <td style="width: 5%">
                <button id="btnTambahEdit" type="button" class="btn btn-success">e</button>
            </td>
        </tr>
      </tbody>
    </table>
    <table class="table table-sm table-bordered table-trxs" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
        <tbody>
            <tr>
                <td width="20%">
                    <input disabled style="height: 39px; font-size: 19px;" class="bg-dark text-white form-control text-center" type="text" value="BARCODE">
                </td>
                <td width="80%">
                    <input id="inputsBarcode" @change="InputBarcode()" @focus="$event.target.select()" type="text" v-model="inputs.Barcode" style="height: 39px; font-size: 19px;" class="bg-white text-black form-control text-right">
                </td>
            </tr>
        </tbody>
    </table>
</template>

<script>
    import ajaxServices from '@/services/index.js'
    import utilJson from '@/utils/utilJson.js'
    import utilMath from '@/utils/utilMath.js'
    import { mapActions, mapGetters } from "vuex";

    export default {
        expose: ['GetDataTrx', 'mstKatalogs','InputBarcodePublic'],
        emits: ['change-katalog'],
        mixins:[ajaxServices, utilJson, utilMath],
        created() {
            this.getSession();
        },
        mounted() {
            this.GetDataMst();
            this.$store.state.gEditMode = true;
            this.$store.state.gWindowHeight = window.innerHeight;
        },
        data() {
            return {
                inputs : {  Barcode : '123', 
                            PelangganId : '081311339813',
                            PelangganNama : 'Sapto Sisworo',
                            PelangganAlamat : 'Rivera Hills'
                },
                dataTrx : {},
                stats: {
                    iEditMode: false,
                },
                trxKatalogs: [
                    {   no_urut: 1, nm_item: "bye bye fever anak", qty: 1,
                        tarif_desc: "5,500", kd_item: "899280712119", jnsitem: "9",
                        no_penjualan: "R01202304280001", tgljam: "230428112204",
                        aturanpakai: [], nilai_hasil_periksa: "",
                        sts_kunci: "0", sts_lunas: "1", sts_paket: "0",
                        stsaturanpakai: "0", stsedit: "1", stshsl: "0", 
                        stskunci: "0", stspaket: "1", stsqty: "1" 
                    },
                ],
                mstKatalogs: [
                    {"key" : "8999999719395", "kode" : "va", "harga" : "        15,000", "harga2" : "             0", "harga3" : "             0", "harga4" : "             0", "hargaqty1" : "             0", "hargaqty2" : "             0", "hargaqty3" : "             0", "hargaqty4" : "             0", "nama" : "vaseline restores", "barcode" : "8999999719395", "stsqty" : "1", "stsqtyadd" : "1", "stspaket" : "0", "stskunci" : "0", "stsedit" : "1", "stshsl" : "0", "stsaturanpakai" : "1", "input_qty" : "1", "inisial" : "vrm", "jnsitem" : 3, "value" : "vaseline restores moisture 100ml"}
                ]
            };
        },
        computed : {
            ...mapGetters(["getToken", "getLogin"]),
            TotalHarga() {
                var vTotalHarga = 0;
                for (var i=0; i < this.trxKatalogs.length; i++) {
                    vTotalHarga = vTotalHarga + parseInt((((this.trxKatalogs[i].tarif_desc).trim()).replaceAll('.','')).replaceAll(',',''));
                };
                return utilMath.fmathNumberWithPoints(vTotalHarga);
            },
            tableBodyHeight() {
                // 1034 - 464 = 570
                var vTableBodyHeight = (window.innerHeight - 464) + 'px';
                return vTableBodyHeight;
            }
        },
        methods : {
            ...mapActions(["getSession"]),
            ShowMessage(message) {
                this.$store.state.gModalMessage = message;
            },
            InputPelanggan() {
                alert(this.inputs.PelangganId);
            },
            InputBarcodePublic(kodeBarcode) {
                this.inputs.Barcode = kodeBarcode;
                this.InputBarcode();
            },
            InputBarcode() {
                var vFindMaster = utilJson.find_in_object(this.mstKatalogs, {key : this.inputs.Barcode});
                if (vFindMaster.length > 0) {
                    var vFindTrx = utilJson.find_in_object(this.trxKatalogs, {kd_item : this.inputs.Barcode});
                    if (vFindTrx.length > 0) {
                        var vFindTrxIndex = utilJson.find_in_object_index(this.trxKatalogs, {kd_item : this.inputs.Barcode});
                        this.trxKatalogs[vFindTrxIndex].qty = this.trxKatalogs[vFindTrxIndex].qty + 1;
                        var vHarga = parseInt((((vFindMaster[0].harga).trim()).replaceAll('.','')).replaceAll(',',''));
                        this.trxKatalogs[vFindTrxIndex].tarif_desc = utilMath.fmathNumberWithPoints(vHarga * this.trxKatalogs[vFindTrxIndex].qty);
                    } else {
                        var vInserted = {   aturanpakai: [], jnsitem: "9", kd_item: "0712119", nilai_hasil_periksa: "",
                                            nm_item: "bye bye", no_penjualan: "R01202304280001", no_urut: 0,
                                            qty: 1, sts_kunci: "0", sts_lunas: "1", sts_paket: "0",
                                            stsaturanpakai: "0", stsedit: "1", stshsl: "0", stskunci: "0",
                                            stspaket: "1", stsqty: "1", tarif_desc: "5,500", tgljam: "230428112204" };
                        vInserted.kd_item = vFindMaster[0].key;
                        vInserted.nm_item = vFindMaster[0].value;
                        vInserted.tarif_desc = vFindMaster[0].harga;
                        this.trxKatalogs.push(vInserted);
                    }
                    this.inputs.Barcode = '';
                    document.getElementById("inputsBarcode").focus();
                } else {
                    this.ShowMessage("Data barcode '" + this.inputs.Barcode + "' tidak ditemukan.");
                }
            },
            ButtonKurang(index) {
                if (this.trxKatalogs[index].qty <= 1) {
                    this.trxKatalogs.splice(index,1);
                } else {
                    this.trxKatalogs[index].qty = this.trxKatalogs[index].qty - 1;
                    var vFindMaster = utilJson.find_in_object(this.mstKatalogs, {key : this.trxKatalogs[index].kd_item});
                    var vHarga = parseInt((((vFindMaster[0].harga).trim()).replaceAll('.','')).replaceAll(',',''));
                    this.trxKatalogs[index].tarif_desc = utilMath.fmathNumberWithPoints(vHarga * this.trxKatalogs[index].qty);
                }
            },
            ButtonTambah(index) {
                this.trxKatalogs[index].qty = this.trxKatalogs[index].qty + 1;
                var vFindMaster = utilJson.find_in_object(this.mstKatalogs, {key : this.trxKatalogs[index].kd_item});
                var vHarga = parseInt((((vFindMaster[0].harga).trim()).replaceAll('.','')).replaceAll(',',''));
                this.trxKatalogs[index].tarif_desc = utilMath.fmathNumberWithPoints(vHarga * this.trxKatalogs[index].qty);
            },
            async GetDataTrx() {
                var vparam    = '?parm0=view.tpelayanan&parm1=' + this.getToken;
                var datajson  = [{"no_penjualan": this.$store.state.gTrxCode }];
                var datajsons = {"method":"loads.tlynapotekpenjualan","data": datajson };
                vparam        = vparam + '&parm2=' + JSON.stringify(datajsons);
                var result    = await ajaxServices.selectPost(this.getToken, vparam );
                this.dataTrx  = result;
                this.$store.state.gErrorCode = parseInt(this.dataTrx.errstat);
                this.$store.state.gErrorMsg  = this.dataTrx.errmsg;
                if (this.$store.state.gErrorCode === 0) {
                    this.trxKatalogs = result.datarinci.rincian_tagihan;
                }
            },
            async GetDataMst() {

                //alert(this.$store.plugins.getState('accessToken'));
                // sessionStorage.setItem("accessToken", result.data[0].accesstoken);

                var vparam    = '?parm0=view.tpelayanan&parm1=' + this.getToken;
                var datajsons = {"method":"apotekpenjualan"};
                vparam        = vparam + '&parm2=' + JSON.stringify(datajsons);
                var result    = await ajaxServices.selectPost(this.getToken, vparam );
                this.dataTrx  = result;
                this.$store.state.gErrorCode = parseInt(this.dataTrx.errstat);
                this.$store.state.gErrorMsg  = this.dataTrx.errmsg;
                if (this.$store.state.gErrorCode === 0) {
                    this.mstKatalogs = result.datadrop.itempelayanan;
                    this.$emit('change-katalog');
                }
            },
        }
    };
</script>
<style scoped>
    table > .scrollable {
        display: flex;
        flex-flow: column;
        width: 100%;
    }
    table tbody > .scrollable {
        /* body takes all the remaining available space */
        flex: 1 1 auto;
        display: block;
        overflow-y: scroll;
    }
    table tbody tr > .scrollable {
        width: 100%;
    }
    table thead, table tbody tr .scrollable {
        display: table;
        table-layout: fixed;
    }
    .theadscroll {
        width: calc(100% - 1.5em);
    }
</style>
