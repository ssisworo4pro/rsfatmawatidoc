<template>
    <main class="main-content mt-0">
        <div
            class="page-header align-items-start min-vh-50 pt-5 pb-11 m-3 border-radius-lg"
            style="background-image: url('https://raw.githubusercontent.com/creativetimofficial/public-assets/master/argon-dashboard-pro/assets/img/signup-cover.jpg'); background-position: top;"
        >
            <span class="mask bg-gradient-dark opacity-6"></span>
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-5 text-center mx-auto">
                        <h1 class="text-white mb-2 mt-5">Selamat Datang !</h1>
                        <p
                          class="text-lead text-white"
                        >Silahkan login aplikasi terlebih dahulu, sesuai username dan password yang diberikan oleh Admin.</p>
                    </div>
                </div>
            </div>
        </div>

        <div class="container">
            <div class="row mt-lg-n10 mt-md-n11 mt-n10 justify-content-center">
                <div class="col-xl-4 col-lg-5 col-md-7 mx-auto">
                    <div class="card z-index-0">
                        <div class="pb-0 card-header text-start">
                            <h4 class="font-weight-bolder">Masuk</h4>
                            <p class="mb-0">Masukkan id pengguna dan kata kunci.</p>
                        </div>
                    <div class="card-body">
                        <form @submit.prevent="loginClick" role="form">
                            <div class="mb-3">
                                <input type="string" v-model="inputs.username" placeholder="id pengguna" class="form-control form-control-lg" />
                            </div>
                            <div class="mb-3">
                                <input type="password" v-model="inputs.password" placeholder="kata kunci" class="form-control form-control-lg" />
                            </div>
                            <div class="text-center">
                                <argon-button
                                  class="mt-4"
                                  variant="outline"
                                  color="success"
                                  fullWidth
                                  size="lg"
                                >Masuk</argon-button>
                            </div>
                        </form>
                    </div>
                    <div class="px-1 pt-0 text-center card-footer px-lg-2">
                    </div>
                </div>
            </div>
          </div>
        </div>
    </main>
    <app-footer />
</template>
  
<script>
    import ajaxServices from '@/services/index.js'
    import AppFooter from "@/layout/Page/footer.vue";
    // import ArgonInput from "@/components/ArgonInput.vue";
    import ArgonButton from "@/components/ArgonButton.vue";
    // const body = document.getElementsByTagName("body")[0];
    import utilCrypt from '@/utils/utilCrypt.js'
    import { mapActions } from "vuex";
  
    export default {
        mixins:[ajaxServices,utilCrypt],
        data() {
            return {
                inputs: {
                    username: '',
                    password: ''
                },
                baseurl : process.env.VUE_APP_AUTH_SERVICE
            };
        },
        components: {
            AppFooter,
            // ArgonInput,
            ArgonButton,
        },
        methods: {
            ...mapActions(["loginSession","getSession"]),
            loginClick() {
                //alert(this.inputs.username);
                //alert(utilCrypt.md5(this.inputs.password));
                this.GetDataTrx();
            },
            async GetDataTrx() {
                var vparam    = '?parm0=user.token&parm1=loginWithoutPref';
                var datajsons = {   "method":"klk_user_login",
                                    "username": this.inputs.username,
                                    "password": utilCrypt.md5(this.inputs.password)
                                };
                vparam        = vparam + '&parm2=' + JSON.stringify(datajsons);
                var result    = await ajaxServices.selectPost(this.$store.state.gToken, vparam );
                this.$store.state.gErrorCode = parseInt(result.errstat);
                this.$store.state.gErrorMsg  = result.errmsg;
                if (this.$store.state.gErrorCode === 0) {
                    sessionStorage.setItem("accessToken", result.data[0].accesstoken);
                    sessionStorage.setItem("refreshToken", result.data[0].refreshtoken);
                    this.loginSession({ accessToken : result.data[0].accesstoken,
                                        username    : 'username',
                                        userdesc    : 'deskripsi',
                                        userrole    : 'admin' });
                    document.location.href="/";
                }
            },
        },
        created() {
            // this.getSession();
            this.$store.state.hideConfigButton  = true;
            this.$store.state.showNavbar        = false;
            this.$store.state.showControl       = false;
            this.$store.state.showSidenav       = false;
            this.$store.state.showFooter        = false;
        },
        beforeUnmount() {
            this.$store.state.hideConfigButton  = true;
            this.$store.state.showNavbar        = true;
            this.$store.state.showControl       = true;
            this.$store.state.showSidenav       = true;
            this.$store.state.showFooter        = true;
            // body.classList.add("bg-gray-100");
        },
    };
</script>
