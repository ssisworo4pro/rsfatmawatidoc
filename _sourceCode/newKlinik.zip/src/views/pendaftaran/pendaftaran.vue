<template>
<div class="wrapper">
    <div class="container-fluid">
        <form id="form_main" action="#">
            <div class="row">
                <div class="col-12" id="errorMessage" style="display: none">
                    <b>
                        <div id="errorMessageText" class="card-body card m-b-20 text-center" style="background-color: aquamarine;">
                            Error Message ... 
                        </div>
                    </b>
                </div>
                <div id="subModulLeft" class="col-lg-8">
                    <div class="card m-b-20">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-lg-12"><h4 class="mt-0 header-title">Pendaftaran</h4></div>
                                <div class="col-lg-6">
                                    <div class="form-group row">
                                        <label for="example-datetime-local-input" class="col-3 col-form-label">Nomor</label>
                                        <div class="col-4">
                                            <input class="form-control form-control" disabled type="text" value="" id="no_pendaftaran_view" name="no_pendaftaran_view">
                                        </div>
                                        <label for="example-datetime-local-input" class="col-2 text-right col-form-label">Urut</label>
                                        <div class="col-3">
                                            <input class="form-control form-control text-center" disabled type="text" value="" id="no_urut" name="no_urut">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="example-datetime-local-input" class="col-3 col-form-label">Tanggal</label>
                                        <div class="col-5">
                                            <input class="form-control form-control" disabled  type="datetime-local" value="" id="tgl_daftar_view" name="tgl_daftar_view">
                                            <input class="form-control form-control" style="display: none;"  type="datetime-local" value="" id="tgl_daftar" name="tgl_daftar">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-3 col-form-label">Tujuan</label>
                                        <div class="col-9">
                                            <select class="form-control form-control"  name="kd_lokasi" id="kd_lokasi">
                                                        <option value="1">lokasi</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-3 col-form-label">Rujukan</label>
                                        <div class="col-9">
                                            <select onchange="" class="form-control form-control" value="" name="kd_caramasuk" id="kd_caramasuk">
                                                        <option value="key">value</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-3 col-form-label">Cara Bayar</label>
                                        <div class="col-9">
                                            <select class="form-control form-control" name="kd_carabayar1" id="kd_carabayar1">
                                                <option value="key">value</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group row">
                                        <label class="col-3 col-form-label">Anamnesa</label>
                                        <div class="col-9">
                                            <textarea id="anamnesa_singkat" :disabled="!this.$store.state.gEditMode" name="anamnesa_singkat" class="form-control form-control" maxlength="225" rows="3" placeholder=""></textarea>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <div class="col-3"></div>
                                        <div class="col-3">
                                            <div class="form-check">
                                                <input type="checkbox" class="form-check-input" value='1' name="anamnesa_panas" id="anamnesa_panas">
                                                <label class="form-check-label" for="anamnesa_panas">Panas</label>
                                            </div>
                                        </div>
                                        <div class="col-3">
                                            <div class="form-check">
                                                <input type="checkbox" class="form-check-input" value='1' name="anamnesa_batuk" id="anamnesa_batuk">
                                                <label class="form-check-label" for="anamnesa_batuk">Batuk</label>
                                            </div>
                                        </div>
                                        <div class="col-3">
                                            <div class="form-check">
                                                <input type="checkbox" class="form-check-input" value='1' name="anamnesa_sesak" id="anamnesa_sesak">
                                                <label class="form-check-label" for="anamnesa_sesak">Sesak</label>
                                            </div>
                                        </div>
                                    </div>
                                    <hr style="margin:2px; border: 0; background-color: transparent;">
                                    <div class="form-group row">
                                        <label class="col-3 col-form-label">Catatan</label>
                                        <div class="col-9">
                                            <textarea id="catatan" name="catatan" class="form-control form-control" maxlength="225" rows="2" placeholder=""></textarea>
                                        </div>
                                    </div>
                                    <hr style="margin:2px; border: 0; background-color: transparent;">
                                    <div class="form-group row">
                                        <label for="example-date-input" class="col-3 col-form-label">Berat Badan</label>
                                        <div class="col-3">
                                            <input class="form-control form-control text-center" type="text" value="0" id="dokter_beratbadan" name="dokter_beratbadan">
                                        </div>
                                        <label class="col-3 col-form-label" style="padding-left: 0px; margin-left: -10px">&nbsp;Kg</label>

                                    </div>
                                    <hr style="margin:0px; border: 0; background-color: transparent;">
                                    <div class="form-group row">
                                        <label for="example-date-input" class="col-3 col-form-label">Tinggi Badan</label>
                                        <div class="col-3">
                                            <span class="input-group-append add-on">
                                                <input class="form-control form-control text-center" type="text" value="0" id="dokter_tinggibadan" name="dokter_tinggibadan">
                                                <i style="margin-top: 4px;">&nbsp;Cm</i>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div> 
</div>
</template>